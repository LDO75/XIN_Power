# XIN Power V5.9.3

本版修改 APP 的风扇迟滞与通讯处理，并完善 Qt 上位机日志页。BL、内部 Flash 分区、OTA 协议、输出控制及校准系数均不变。蓝牙偶发卡死尚未取得实板复现证据，本版针对已发现的通讯调度风险加固，不能将编译通过等同于卡死根因已经消除。

| 目录 | 内容 |
| --- | --- |
| `01_Bootloader` | 独立 BL 工程，未改动；已有已验证 V5.9.x BL 的板子不需重刷。 |
| `02_Application` | V5.9.3 独立应用工程，`MDK-ARM/Objects/XIN_Power.hex` 用于 USB／蓝牙升级。 |
| `03_Factory` | BL＋V5.9.3 应用合并 HEX，仅供空片或完整 SWD 重装。 |
| `04_Recovery` | 旧版恢复参考文件。 |
| `05_PC_Tool` | PySide6／Qt Quick 源码；交付 EXE 可直接双击，不需命令行或另装 Python。常用命令说明在 `COMMANDS.md`。 |
| `tests` | 本版风扇迟滞短测试源码与模拟计时器头文件，不参与 Keil 实机编译。 |

你当前板子若已运行 V5.9.1／V5.9.2，推荐只升级 V5.9.3 **应用 HEX**，不要选 Factory 或 BL HEX。芯片为 PY32F403C1DT6，Keil 配置沿用前版，不改设备／下载算法。操作见 [DOWNLOAD_AND_DEBUG_STEP_BY_STEP.md](DOWNLOAD_AND_DEBUG_STEP_BY_STEP.md)，改动及检查结果见 [V5.9.3_CHANGELOG_AND_TESTS.md](V5.9.3_CHANGELOG_AND_TESTS.md)。

风扇规则：达到 40.0°C 全速开启，降至 35.0°C 或以下关闭；中间区间保持原状态，NTC 失效强制全速。

电压不做“关闭输出就强制显示零”。本次日志的 `vraw=11`、`vgain=999726`、`voff=5` 算出 0.016 V；上位机“精度校准 → 读取校准参数”解释此计算。请先用万用表确认实际端子电压，再判断是真实残压还是测量零点误差。

此包不等于负载、掉电或长期稳定性验收；这些耗时测试留给你。CRC32 只用于检测传输损坏，不是固件签名。
