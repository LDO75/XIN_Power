/**
  ******************************************************************************
  * @file    power_control.c
  * @brief   SC8701输出调压、软件恒流和安全保护业务实现。
  ******************************************************************************
  */

#include "power_control.h"

#include "calibration.h"
#include "debug_console.h"
#include "gpio.h"
#include "i2c.h"
#include "mcp4725.h"
#include "power_config.h"

#include <stddef.h>
#include <stdio.h>
#include <string.h>

#define POWER_CONTROL_START_DELAY_MS                  20U
#define POWER_CONTROL_LOOP_PERIOD_MS                   2U
#define POWER_CONTROL_DAC_RETRY_MS                   1000U
#define POWER_CONTROL_DEBUG_PERIOD_MS                1000U
#define POWER_CONTROL_MONITOR_TIMEOUT_MS               100U
#define POWER_CONTROL_DAC_RISE_STEP_CODE               16U
#define POWER_CONTROL_DAC_FALL_STEP_CODE                4U
#define POWER_CONTROL_CC_ENTER_MARGIN_MA                20U
#define POWER_CONTROL_CC_EXIT_MARGIN_MA                 60U
#define POWER_CONTROL_CC_SATURATION_MARGIN_MA           100U
#define POWER_CONTROL_CC_SATURATION_SAMPLES              10U

typedef enum
{
  POWER_CONTROL_STATE_OFF = 0,
  POWER_CONTROL_STATE_STARTING,
  POWER_CONTROL_STATE_RUNNING,
  POWER_CONTROL_STATE_FAULT
} PowerControl_State_t;

static MCP4725_Device_t s_dac;
static PowerControl_Status_t s_status;
static PowerControl_State_t s_state;
static uint16_t s_nominal_dac_code;
static uint16_t s_applied_dac_code;
static uint16_t s_cc_offset_code;
static uint32_t s_state_start_time_ms;
static uint32_t s_last_dac_retry_time_ms;
static uint32_t s_last_debug_time_ms;
static uint32_t s_last_sample_sequence;
static uint32_t s_last_control_time_ms;
static uint8_t s_cc_saturation_count;
/* 上电后必须先观察到一次明确的关闭请求，才允许接受开启请求。 */
static bool s_output_armed;

static void PowerControl_Trip(PowerControl_Fault_t fault);

/** @brief 判断双路测量是否在线、至少完成一帧且没有超时。 */
static bool PowerControl_IsMeasurementUsable(
  uint32_t system_time_ms,
  const PowerMonitor_Snapshot_t *measurement)
{
  if ((measurement == NULL) ||
      !measurement->input_online ||
      !measurement->output_online ||
      !measurement->data_valid ||
      (measurement->sample_sequence == 0U))
  {
    return false;
  }

  return ((system_time_ms - measurement->last_valid_sample_time_ms) <=
          POWER_CONTROL_MONITOR_TIMEOUT_MS);
}

/** @brief  将SC8701硬件关闭，CE#为高电平时芯片关闭。 */
static void PowerControl_DisableHardware(void)
{
  HAL_GPIO_WritePin(P_EN_Port, P_EN_Pin, GPIO_PIN_SET);
  s_status.output_enabled = false;
}

/** @brief  使能SC8701，CE#为低电平时芯片工作。 */
static void PowerControl_EnableHardware(void)
{
  HAL_GPIO_WritePin(P_EN_Port, P_EN_Pin, GPIO_PIN_RESET);
  s_status.output_enabled = true;
}

/** @brief  将有符号微安测量值转换为非负毫安。 */
static uint16_t PowerControl_CurrentToMa(int32_t current_ua)
{
  uint32_t current_ma;

  if (current_ua <= 0)
  {
    return 0U;
  }
  current_ma = ((uint32_t)current_ua + 500U) / 1000U;
  return (current_ma > UINT16_MAX) ? UINT16_MAX : (uint16_t)current_ma;
}

/** @brief  写入DAC并在连续失败时进入安全故障状态。 */
static bool PowerControl_WriteDac(uint16_t code)
{
  if (!MCP4725_WriteVolatile(&s_dac, code))
  {
    /* DAC控制链一旦写失败就立即关断，不让功率级带着旧设定继续运行。 */
    s_dac.ready = false;
    PowerControl_Trip(POWER_CONTROL_FAULT_DAC_OFFLINE);
    return false;
  }

  s_applied_dac_code = code;
  s_status.dac_code = code;
  return true;
}

/** @brief  锁存故障并立即关闭SC8701。 */
static void PowerControl_Trip(PowerControl_Fault_t fault)
{
  char event[96];

  if (s_state != POWER_CONTROL_STATE_FAULT)
  {
    s_status.fault = fault;
    (void)snprintf(event, sizeof(event),
                   "[FAULT] t=%lu reason=%s output=OFF\r\n",
                   (unsigned long)HAL_GetTick(),
                   PowerControl_GetFaultName(fault));
    DebugConsole_Write(event);
  }
  s_state = POWER_CONTROL_STATE_FAULT;
  s_status.constant_current = false;
  s_cc_offset_code = 0U;
  s_cc_saturation_count = 0U;
  /* 让本轮状态机立即输出故障，而不是等待下一次周期诊断。 */
  s_last_debug_time_ms = HAL_GetTick() - POWER_CONTROL_DEBUG_PERIOD_MS;
  PowerControl_DisableHardware();
}

/** @brief  计算同时满足用户限流、100W和输入4.5A约束的有效限流值。 */
static uint16_t PowerControl_GetEffectiveCurrentLimit(
  const PowerControl_Request_t *request,
  const PowerMonitor_Snapshot_t *measurement)
{
  uint32_t limit_ma = request->current_limit_ma;
  uint32_t power_limit_ma;
  uint32_t input_limit_ma;
  uint32_t target_voltage_mv = request->voltage_setpoint_mv;

  if (target_voltage_mv < POWER_CFG_VOLTAGE_MIN_MV)
  {
    target_voltage_mv = POWER_CFG_VOLTAGE_MIN_MV;
  }
  power_limit_ma = (POWER_CFG_POWER_MAX_MW * 1000UL) / target_voltage_mv;
  if (power_limit_ma < limit_ma)
  {
    limit_ma = power_limit_ma;
  }

  input_limit_ma = (uint32_t)(
    ((uint64_t)measurement->input_voltage_raw_mv *
     POWER_CFG_INPUT_CONTINUOUS_MA *
     POWER_CFG_ESTIMATED_EFFICIENCY_PERMILLE) /
    ((uint64_t)target_voltage_mv * 1000ULL));
  if (input_limit_ma < limit_ma)
  {
    limit_ma = input_limit_ma;
  }
  if (limit_ma < POWER_CFG_CURRENT_MIN_MA)
  {
    limit_ma = POWER_CFG_CURRENT_MIN_MA;
  }
  if (limit_ma > POWER_CFG_CURRENT_MAX_MA)
  {
    limit_ma = POWER_CFG_CURRENT_MAX_MA;
  }
  return (uint16_t)limit_ma;
}

/** @brief  根据快速测量数据更新软件恒流积分补偿量。 */
static void PowerControl_UpdateCurrentLoop(
  const PowerMonitor_Snapshot_t *measurement)
{
  uint16_t output_current_ma =
    PowerControl_CurrentToMa(measurement->output_current_raw_ua);
  uint16_t input_current_ma =
    PowerControl_CurrentToMa(measurement->input_current_raw_ua);
  int32_t current_error_ma =
    (int32_t)output_current_ma - (int32_t)s_status.effective_current_limit_ma;
  uint16_t adjustment;
  uint16_t safe_code = PowerControl_VoltageToDacCode(
    POWER_CFG_VOLTAGE_MIN_MV);
  uint16_t maximum_offset = (safe_code > s_nominal_dac_code) ?
                            (uint16_t)(safe_code - s_nominal_dac_code) : 0U;

  if (input_current_ma > POWER_CFG_INPUT_CONTINUOUS_MA)
  {
    current_error_ma += (int32_t)(input_current_ma -
                                  POWER_CFG_INPUT_CONTINUOUS_MA);
  }
  if (measurement->output_power_raw_mw > POWER_CFG_POWER_MAX_MW)
  {
    current_error_ma += (int32_t)((measurement->output_power_raw_mw -
                                   POWER_CFG_POWER_MAX_MW) / 100U);
  }

  if (current_error_ma > (int32_t)POWER_CONTROL_CC_ENTER_MARGIN_MA)
  {
    adjustment = (uint16_t)(1U + ((uint32_t)current_error_ma / 25U));
    if ((s_cc_offset_code >= maximum_offset) ||
        (adjustment >= (uint16_t)(maximum_offset - s_cc_offset_code)))
    {
      s_cc_offset_code = maximum_offset;
    }
    else
    {
      s_cc_offset_code = (uint16_t)(s_cc_offset_code + adjustment);
    }
    s_status.constant_current = true;
  }
  else if (current_error_ma < -(int32_t)POWER_CONTROL_CC_EXIT_MARGIN_MA)
  {
    adjustment = (uint16_t)(1U + ((uint32_t)(-current_error_ma) / 100U));
    if (adjustment >= s_cc_offset_code)
    {
      s_cc_offset_code = 0U;
      s_status.constant_current = false;
    }
    else
    {
      s_cc_offset_code = (uint16_t)(s_cc_offset_code - adjustment);
    }
  }

  /*
   * SC8701本身最低只能调到约2V。当负载需要低于2V才能维持设定
   * 电流时，单纯调压无法继续降低电流，因此短暂确认后直接关断。
   */
  if ((s_cc_offset_code >= maximum_offset) &&
      (output_current_ma >
       (uint16_t)(s_status.effective_current_limit_ma +
                  POWER_CONTROL_CC_SATURATION_MARGIN_MA)))
  {
    if (s_cc_saturation_count < UINT8_MAX)
    {
      s_cc_saturation_count++;
    }
    if (s_cc_saturation_count >= POWER_CONTROL_CC_SATURATION_SAMPLES)
    {
      PowerControl_Trip(POWER_CONTROL_FAULT_CC_OUT_OF_RANGE);
    }
  }
  else
  {
    s_cc_saturation_count = 0U;
  }
}

/** @brief  平滑追踪目标DAC码值，升压方向采用较慢的变化速度。 */
static bool PowerControl_ApplySlewLimitedCode(uint16_t target_code)
{
  uint16_t next_code = s_applied_dac_code;

  if (target_code > s_applied_dac_code)
  {
    uint16_t difference = (uint16_t)(target_code - s_applied_dac_code);
    next_code = (difference > POWER_CONTROL_DAC_RISE_STEP_CODE) ?
                (uint16_t)(s_applied_dac_code + POWER_CONTROL_DAC_RISE_STEP_CODE) :
                target_code;
  }
  else if (target_code < s_applied_dac_code)
  {
    uint16_t difference = (uint16_t)(s_applied_dac_code - target_code);
    next_code = (difference > POWER_CONTROL_DAC_FALL_STEP_CODE) ?
                (uint16_t)(s_applied_dac_code - POWER_CONTROL_DAC_FALL_STEP_CODE) :
                target_code;
  }

  return (next_code == s_applied_dac_code) ? true :
         PowerControl_WriteDac(next_code);
}

/** @brief  检查必须立即关断的电压、电流和功率异常。 */
static bool PowerControl_CheckEmergencyFault(
  const PowerMonitor_Snapshot_t *measurement)
{
  int32_t protection_output_current_ua = measurement->output_current_raw_ua;
  uint32_t protection_output_power_mw = measurement->output_power_raw_mw;
  uint16_t input_current_ma =
    PowerControl_CurrentToMa(measurement->input_current_raw_ua);
  uint16_t output_current_ma;

  /*
   * 用户校准值可能暂时不准确。紧急过流与过功率保护同时比较
   * INA226未校准值，避免负增益误差使保护阈值被危险地抬高。
   */
  if (measurement->output_current_uncalibrated_ua >
      protection_output_current_ua)
  {
    protection_output_current_ua =
      measurement->output_current_uncalibrated_ua;
  }
  if (measurement->output_current_uncalibrated_ua > 0)
  {
    uint32_t uncalibrated_power_mw = (uint32_t)(
      ((uint64_t)measurement->output_voltage_uncalibrated_mv *
       (uint32_t)measurement->output_current_uncalibrated_ua) / 1000000ULL);
    if (uncalibrated_power_mw > protection_output_power_mw)
    {
      protection_output_power_mw = uncalibrated_power_mw;
    }
  }
  output_current_ma = PowerControl_CurrentToMa(protection_output_current_ua);

  if (measurement->input_voltage_raw_mv > POWER_CFG_INPUT_TRIP_MV)
  {
    PowerControl_Trip(POWER_CONTROL_FAULT_INPUT_OVERVOLTAGE);
  }
  else if (measurement->output_voltage_raw_mv > POWER_CFG_OUTPUT_TRIP_MV)
  {
    PowerControl_Trip(POWER_CONTROL_FAULT_OUTPUT_OVERVOLTAGE);
  }
  else if (input_current_ma > POWER_CFG_INPUT_TRIP_MA)
  {
    PowerControl_Trip(POWER_CONTROL_FAULT_INPUT_OVERCURRENT);
  }
  else if (output_current_ma > POWER_CFG_OUTPUT_TRIP_MA)
  {
    PowerControl_Trip(POWER_CONTROL_FAULT_OUTPUT_OVERCURRENT);
  }
  else if (protection_output_power_mw > POWER_CFG_POWER_TRIP_MW)
  {
    PowerControl_Trip(POWER_CONTROL_FAULT_OVERPOWER);
  }
  return (s_state == POWER_CONTROL_STATE_FAULT);
}

/** @brief 检查NTC传感器状态和功率区温度并在异常时立即关断。 */
static bool PowerControl_CheckTemperatureFault(
  const PowerControl_Request_t *request)
{
  if (!request->temperature_valid)
  {
    PowerControl_Trip(POWER_CONTROL_FAULT_TEMPERATURE_SENSOR);
  }
  else if (request->temperature_decic >= POWER_CFG_TEMPERATURE_TRIP_DECIC)
  {
    PowerControl_Trip(POWER_CONTROL_FAULT_OVERTEMPERATURE);
  }
  return (s_state == POWER_CONTROL_STATE_FAULT);
}

/** @brief  周期输出主电源控制诊断信息。 */
static void PowerControl_PrintDebug(uint32_t system_time_ms,
                                    const PowerMonitor_Snapshot_t *measurement)
{
  char text[192];
  int length;
  uint32_t sample_age_ms = UINT32_MAX;
  bool monitor_usable = false;

  if ((system_time_ms - s_last_debug_time_ms) < POWER_CONTROL_DEBUG_PERIOD_MS)
  {
    return;
  }
  s_last_debug_time_ms = system_time_ms;
  if (measurement != NULL)
  {
    sample_age_ms = system_time_ms - measurement->last_valid_sample_time_ms;
    monitor_usable = PowerControl_IsMeasurementUsable(system_time_ms,
                                                       measurement);
  }
  length = snprintf(text, sizeof(text),
                    "[POWER] state=%u out=%u cc=%u dac=%u ilim=%umA "
                    "mon=%u age=%lums seq=%lu fault=%s\r\n",
                    (unsigned int)s_state,
                    s_status.output_enabled ? 1U : 0U,
                    s_status.constant_current ? 1U : 0U,
                    (unsigned int)s_status.dac_code,
                    (unsigned int)s_status.effective_current_limit_ma,
                    monitor_usable ? 1U : 0U,
                    (unsigned long)sample_age_ms,
                    (unsigned long)((measurement != NULL) ?
                                    measurement->sample_sequence : 0U),
                    PowerControl_GetFaultName(s_status.fault));
  if (length > 0)
  {
    if (length > (int)(sizeof(text) - 1U))
    {
      length = (int)(sizeof(text) - 1U);
    }
    DebugConsole_Write(text);
  }
}

uint16_t PowerControl_VoltageToDacCode(uint16_t voltage_mv)
{
  int64_t dac_voltage_uv;
  uint32_t code;
  uint16_t calibrated_code;

  if (voltage_mv < POWER_CFG_VOLTAGE_MIN_MV)
  {
    voltage_mv = POWER_CFG_VOLTAGE_MIN_MV;
  }
  else if (voltage_mv > POWER_CFG_VOLTAGE_MAX_MV)
  {
    voltage_mv = POWER_CFG_VOLTAGE_MAX_MV;
  }

  if (Calibration_MapDac(voltage_mv, &calibrated_code))
  {
    return calibrated_code;
  }

  dac_voltage_uv = (int64_t)(2UL * POWER_CFG_FB_REFERENCE_UV) -
    (((int64_t)POWER_CFG_FB_LOWER_OHM *
      ((int64_t)voltage_mv * 1000LL - POWER_CFG_FB_REFERENCE_UV)) /
     POWER_CFG_FB_UPPER_OHM);
  if (dac_voltage_uv < 0)
  {
    dac_voltage_uv = 0;
  }
  if (dac_voltage_uv > (int64_t)POWER_CFG_DAC_REFERENCE_UV)
  {
    dac_voltage_uv = POWER_CFG_DAC_REFERENCE_UV;
  }
  code = (uint32_t)((dac_voltage_uv * MCP4725_MAX_CODE +
                     (POWER_CFG_DAC_REFERENCE_UV / 2UL)) /
                    POWER_CFG_DAC_REFERENCE_UV);
  return (code > MCP4725_MAX_CODE) ? MCP4725_MAX_CODE : (uint16_t)code;
}

bool PowerControl_Init(void)
{
  uint32_t now = HAL_GetTick();

  PowerControl_DisableHardware();
  (void)memset(&s_status, 0, sizeof(s_status));
  s_state = POWER_CONTROL_STATE_OFF;
  s_nominal_dac_code = PowerControl_VoltageToDacCode(
    POWER_CFG_VOLTAGE_MIN_MV);
  s_applied_dac_code = s_nominal_dac_code;
  s_cc_offset_code = 0U;
  s_cc_saturation_count = 0U;
  s_output_armed = false;
  s_state_start_time_ms = now;
  s_last_dac_retry_time_ms = now;
  /* 与INA226整秒日志错开半个周期，减少两条阻塞串口输出连续卡住主循环。 */
  s_last_debug_time_ms = now - (POWER_CONTROL_DEBUG_PERIOD_MS / 2U);
  s_last_sample_sequence = 0U;
  s_last_control_time_ms = now;
  s_status.dac_code = s_nominal_dac_code;
  s_status.effective_current_limit_ma = POWER_CFG_CURRENT_MIN_MA;

  if (!MCP4725_Init(&s_dac, &hi2c2, MCP4725_ADDRESS_7BIT) ||
      !PowerControl_WriteDac(s_nominal_dac_code))
  {
    s_dac.ready = false;
    s_status.fault = POWER_CONTROL_FAULT_DAC_OFFLINE;
    s_state = POWER_CONTROL_STATE_FAULT;
    return false;
  }
  return true;
}

void PowerControl_Process(uint32_t system_time_ms,
                          const PowerControl_Request_t *request,
                          const PowerMonitor_Snapshot_t *measurement)
{
  uint16_t target_code;
  uint16_t safe_code;
  bool dac_updated;

  if ((request == NULL) || (measurement == NULL))
  {
    PowerControl_Trip(POWER_CONTROL_FAULT_MONITOR_OFFLINE);
    return;
  }

  if (!s_dac.ready &&
      ((system_time_ms - s_last_dac_retry_time_ms) >=
       POWER_CONTROL_DAC_RETRY_MS))
  {
    s_last_dac_retry_time_ms = system_time_ms;
    if (MCP4725_Init(&s_dac, &hi2c2, MCP4725_ADDRESS_7BIT))
    {
      s_nominal_dac_code = PowerControl_VoltageToDacCode(
        request->voltage_setpoint_mv);
      if (PowerControl_WriteDac(s_nominal_dac_code))
      {
        /* 通讯恢复不代表故障已被用户确认，继续保持故障锁存。 */
      }
    }
  }

  if (!request->output_requested)
  {
    /* 只有主循环明确传入过关闭状态，后续的开启请求才被接受。 */
    s_output_armed = true;
    PowerControl_DisableHardware();
    s_status.constant_current = false;
    s_cc_offset_code = 0U;
    s_cc_saturation_count = 0U;
    if (s_state == POWER_CONTROL_STATE_FAULT)
    {
      PowerControl_PrintDebug(system_time_ms, measurement);
      return;
    }
    if (s_dac.ready &&
        PowerControl_IsMeasurementUsable(system_time_ms, measurement))
    {
      s_status.fault = POWER_CONTROL_FAULT_NONE;
      s_state = POWER_CONTROL_STATE_OFF;
      if ((system_time_ms - s_last_control_time_ms) >=
          POWER_CONTROL_LOOP_PERIOD_MS)
      {
        s_last_control_time_ms = system_time_ms;
        s_nominal_dac_code = PowerControl_VoltageToDacCode(
          request->voltage_setpoint_mv);
        /* CE关闭时可一次预置DAC，避免上电前按4码/周期慢慢走完。 */
        if (s_nominal_dac_code != s_applied_dac_code)
        {
          (void)PowerControl_WriteDac(s_nominal_dac_code);
        }
      }
    }
    PowerControl_PrintDebug(system_time_ms, measurement);
    return;
  }

  if (!s_output_armed)
  {
    PowerControl_DisableHardware();
    PowerControl_PrintDebug(system_time_ms, measurement);
    return;
  }

  if (!PowerControl_IsMeasurementUsable(system_time_ms, measurement))
  {
    PowerControl_Trip(POWER_CONTROL_FAULT_MONITOR_OFFLINE);
  }
  else if (!s_dac.ready)
  {
    PowerControl_Trip(POWER_CONTROL_FAULT_DAC_OFFLINE);
  }
  else if (PowerControl_CheckTemperatureFault(request))
  {
    /* 故障已经锁存并完成硬件关断。 */
  }
  if (s_state == POWER_CONTROL_STATE_FAULT)
  {
    PowerControl_PrintDebug(system_time_ms, measurement);
    return;
  }

  if ((system_time_ms - s_last_control_time_ms) < POWER_CONTROL_LOOP_PERIOD_MS)
  {
    PowerControl_PrintDebug(system_time_ms, measurement);
    return;
  }
  s_last_control_time_ms = system_time_ms;

  s_nominal_dac_code = PowerControl_VoltageToDacCode(
    request->voltage_setpoint_mv);
  s_status.effective_current_limit_ma =
    PowerControl_GetEffectiveCurrentLimit(request, measurement);

  if (measurement->sample_sequence != s_last_sample_sequence)
  {
    s_last_sample_sequence = measurement->sample_sequence;
    if (PowerControl_CheckEmergencyFault(measurement))
    {
      PowerControl_PrintDebug(system_time_ms, measurement);
      return;
    }
    if (s_state == POWER_CONTROL_STATE_RUNNING)
    {
      PowerControl_UpdateCurrentLoop(measurement);
      if (s_state == POWER_CONTROL_STATE_FAULT)
      {
        PowerControl_PrintDebug(system_time_ms, measurement);
        return;
      }
    }
  }

  safe_code = PowerControl_VoltageToDacCode(POWER_CFG_VOLTAGE_MIN_MV);
  target_code = (uint16_t)(s_nominal_dac_code + s_cc_offset_code);
  if (target_code > safe_code)
  {
    target_code = safe_code;
  }
  /* 启动期间CE保持关闭，可直接装载目标值；运行后才限速调压。 */
  if (s_state == POWER_CONTROL_STATE_RUNNING)
  {
    dac_updated = PowerControl_ApplySlewLimitedCode(target_code);
  }
  else
  {
    dac_updated = (target_code == s_applied_dac_code) ||
                  PowerControl_WriteDac(target_code);
  }
  if (!dac_updated)
  {
    PowerControl_PrintDebug(system_time_ms, measurement);
    return;
  }

  if (s_state == POWER_CONTROL_STATE_OFF)
  {
    s_state = POWER_CONTROL_STATE_STARTING;
    s_state_start_time_ms = system_time_ms;
  }
  else if ((s_state == POWER_CONTROL_STATE_STARTING) &&
           (s_applied_dac_code == target_code) &&
           ((system_time_ms - s_state_start_time_ms) >=
            POWER_CONTROL_START_DELAY_MS))
  {
    PowerControl_EnableHardware();
    s_state = POWER_CONTROL_STATE_RUNNING;
  }

  PowerControl_PrintDebug(system_time_ms, measurement);
}

bool PowerControl_ClearFault(void)
{
  PowerControl_DisableHardware();
  s_status.constant_current = false;
  s_cc_offset_code = 0U;
  s_cc_saturation_count = 0U;
  s_output_armed = true;

  if (!s_dac.ready)
  {
    return false;
  }

  s_status.fault = POWER_CONTROL_FAULT_NONE;
  s_state = POWER_CONTROL_STATE_OFF;
  DebugConsole_Write("[FAULT] cleared; output remains OFF\r\n");
  return true;
}

void PowerControl_GetStatus(PowerControl_Status_t *status)
{
  if (status != NULL)
  {
    *status = s_status;
  }
}

const char *PowerControl_GetFaultName(PowerControl_Fault_t fault)
{
  static const char *const names[] =
  {
    "NONE", "MONITOR", "DAC", "VIN_OV", "VOUT_OV",
    "IIN_OC", "IOUT_OC", "POWER", "CC_RANGE", "NTC", "OVER_TEMP"
  };

  if ((unsigned int)fault >= (sizeof(names) / sizeof(names[0])))
  {
    return "UNKNOWN";
  }
  return names[(unsigned int)fault];
}
