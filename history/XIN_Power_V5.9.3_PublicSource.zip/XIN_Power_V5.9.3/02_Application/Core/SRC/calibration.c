/**
  ******************************************************************************
  * @file    calibration.c
  * @brief   输出测量与DAC两点校准、W25Q256双备份持久化实现。
  ******************************************************************************
  */

#include "calibration.h"

#include "power_config.h"
#include "w25q256.h"

#include <stddef.h>
#include <string.h>

#define CALIBRATION_MAGIC                 0x5843414CUL /* XCAL */
#define CALIBRATION_SCHEMA_VERSION             2U
#define CALIBRATION_SCHEMA_VERSION_LEGACY      1U
#define CALIBRATION_VALID_VOLTAGE_MASK       0x01U
#define CALIBRATION_VALID_CURRENT_MASK       0x02U
#define CALIBRATION_SLOT_0_ADDRESS        0x01FFE000UL
#define CALIBRATION_SLOT_1_ADDRESS        0x01FFF000UL
#define CALIBRATION_GAIN_MIN_PPM           700000L
#define CALIBRATION_GAIN_MAX_PPM          1300000L
#define CALIBRATION_VOLTAGE_OFFSET_MAX_MV    1500L
#define CALIBRATION_CURRENT_OFFSET_MAX_UA  500000L
#define CALIBRATION_DAC_CODE_MAX              4095U

typedef struct
{
  uint32_t magic;
  uint16_t schema_version;
  uint16_t size;
  uint32_t sequence;
  int32_t voltage_gain_ppm;
  int32_t voltage_offset_mv;
  int32_t current_gain_ppm;
  int32_t current_offset_ua;
  uint16_t dac_voltage_1_mv;
  uint16_t dac_code_1;
  uint16_t dac_voltage_2_mv;
  uint16_t dac_code_2;
  uint8_t measurement_valid;
  uint8_t dac_valid;
  uint16_t reserved;
  uint32_t crc32;
} Calibration_Record_t;

static Calibration_Data_t s_data;
static uint32_t s_sequence;
static int8_t s_active_slot = -1;

static uint32_t Calibration_Crc32(const void *data, size_t length)
{
  const uint8_t *bytes = (const uint8_t *)data;
  uint32_t crc = 0xFFFFFFFFUL;
  size_t index;
  uint8_t bit;

  for (index = 0U; index < length; index++)
  {
    crc ^= bytes[index];
    for (bit = 0U; bit < 8U; bit++)
    {
      crc = (crc >> 1U) ^ ((crc & 1U) ? 0xEDB88320UL : 0UL);
    }
  }
  return ~crc;
}

static void Calibration_SetDefaultsInternal(void)
{
  (void)memset(&s_data, 0, sizeof(s_data));
  s_data.voltage_gain_ppm = 1000000L;
  s_data.current_gain_ppm = 1000000L;
}

static bool Calibration_RecordValid(const Calibration_Record_t *record)
{
  Calibration_Record_t copy;
  uint32_t expected_crc;

  if ((record == NULL) ||
      (record->magic != CALIBRATION_MAGIC) ||
      ((record->schema_version != CALIBRATION_SCHEMA_VERSION) &&
       (record->schema_version != CALIBRATION_SCHEMA_VERSION_LEGACY)) ||
      (record->size != sizeof(Calibration_Record_t)))
  {
    return false;
  }
  copy = *record;
  expected_crc = copy.crc32;
  copy.crc32 = 0U;
  return Calibration_Crc32(&copy, sizeof(copy)) == expected_crc;
}

/**
 * @brief  判断序号a是否比序号b更新，兼容32位序号回绕。
 */
static bool Calibration_SequenceNewer(uint32_t a, uint32_t b)
{
  return (int32_t)(a - b) > 0;
}

/**
 * @brief  将有效记录装载到运行参数。
 */
static void Calibration_LoadRecord(const Calibration_Record_t *record,
                                   int8_t slot)
{
  s_sequence = record->sequence;
  s_active_slot = slot;
  s_data.voltage_gain_ppm = record->voltage_gain_ppm;
  s_data.voltage_offset_mv = record->voltage_offset_mv;
  s_data.current_gain_ppm = record->current_gain_ppm;
  s_data.current_offset_ua = record->current_offset_ua;
  s_data.dac_voltage_1_mv = record->dac_voltage_1_mv;
  s_data.dac_code_1 = record->dac_code_1;
  s_data.dac_voltage_2_mv = record->dac_voltage_2_mv;
  s_data.dac_code_2 = record->dac_code_2;
  if (record->schema_version == CALIBRATION_SCHEMA_VERSION_LEGACY)
  {
    /*
     * V5.8.1的电流LSB为0.2mA/bit，不能沿用到8A量程。
     * 旧记录只迁移电压和DAC校准，电流恢复默认增益并等待重新校准。
     */
    s_data.voltage_valid = record->measurement_valid != 0U;
    s_data.current_gain_ppm = 1000000L;
    s_data.current_offset_ua = 0L;
    s_data.current_valid = false;
  }
  else
  {
    s_data.voltage_valid =
      (record->measurement_valid & CALIBRATION_VALID_VOLTAGE_MASK) != 0U;
    s_data.current_valid =
      (record->measurement_valid & CALIBRATION_VALID_CURRENT_MASK) != 0U;
  }
  s_data.measurement_valid = s_data.voltage_valid && s_data.current_valid;
  s_data.dac_valid = record->dac_valid != 0U;
  s_data.loaded_from_flash = true;
}

void Calibration_Init(void)
{
  Calibration_Record_t slot_0;
  Calibration_Record_t slot_1;
  bool slot_0_valid;
  bool slot_1_valid;

  Calibration_SetDefaultsInternal();
  s_sequence = 0U;
  s_active_slot = -1;
  if (!W25Q256_Init())
  {
    return;
  }

  slot_0_valid = W25Q256_Read(CALIBRATION_SLOT_0_ADDRESS,
                              &slot_0,
                              sizeof(slot_0)) &&
                 Calibration_RecordValid(&slot_0);
  slot_1_valid = W25Q256_Read(CALIBRATION_SLOT_1_ADDRESS,
                              &slot_1,
                              sizeof(slot_1)) &&
                 Calibration_RecordValid(&slot_1);

  if (slot_0_valid && slot_1_valid)
  {
    if (Calibration_SequenceNewer(slot_1.sequence, slot_0.sequence))
    {
      Calibration_LoadRecord(&slot_1, 1);
    }
    else
    {
      Calibration_LoadRecord(&slot_0, 0);
    }
  }
  else if (slot_0_valid)
  {
    Calibration_LoadRecord(&slot_0, 0);
  }
  else if (slot_1_valid)
  {
    Calibration_LoadRecord(&slot_1, 1);
  }
}

void Calibration_Get(Calibration_Data_t *data)
{
  if (data != NULL)
  {
    *data = s_data;
  }
}

void Calibration_ResetDefaults(void)
{
  Calibration_SetDefaultsInternal();
}

bool Calibration_SetVoltage(int32_t gain_ppm, int32_t offset_mv)
{
  if ((gain_ppm < CALIBRATION_GAIN_MIN_PPM) ||
      (gain_ppm > CALIBRATION_GAIN_MAX_PPM) ||
      (offset_mv < -CALIBRATION_VOLTAGE_OFFSET_MAX_MV) ||
      (offset_mv > CALIBRATION_VOLTAGE_OFFSET_MAX_MV))
  {
    return false;
  }
  s_data.voltage_gain_ppm = gain_ppm;
  s_data.voltage_offset_mv = offset_mv;
  s_data.voltage_valid = true;
  s_data.measurement_valid = s_data.current_valid;
  s_data.loaded_from_flash = false;
  return true;
}

bool Calibration_SetCurrent(int32_t gain_ppm, int32_t offset_ua)
{
  if ((gain_ppm < CALIBRATION_GAIN_MIN_PPM) ||
      (gain_ppm > CALIBRATION_GAIN_MAX_PPM) ||
      (offset_ua < -CALIBRATION_CURRENT_OFFSET_MAX_UA) ||
      (offset_ua > CALIBRATION_CURRENT_OFFSET_MAX_UA))
  {
    return false;
  }
  s_data.current_gain_ppm = gain_ppm;
  s_data.current_offset_ua = offset_ua;
  s_data.current_valid = true;
  s_data.measurement_valid = s_data.voltage_valid;
  s_data.loaded_from_flash = false;
  return true;
}

bool Calibration_SetCurrentZero(int32_t raw_zero_ua)
{
  int64_t offset_ua = -(((int64_t)raw_zero_ua *
                         s_data.current_gain_ppm) / 1000000LL);

  if ((offset_ua < -CALIBRATION_CURRENT_OFFSET_MAX_UA) ||
      (offset_ua > CALIBRATION_CURRENT_OFFSET_MAX_UA))
  {
    return false;
  }
  return Calibration_SetCurrent(s_data.current_gain_ppm, (int32_t)offset_ua);
}

bool Calibration_SaveCurrentZero(int32_t raw_zero_ua)
{
  Calibration_Data_t previous_data = s_data;
  uint32_t previous_sequence = s_sequence;
  int8_t previous_slot = s_active_slot;

  if (Calibration_SetCurrentZero(raw_zero_ua) && Calibration_Save())
  {
    return true;
  }

  /* Flash失败时不要出现“显示失败但运行参数已经变化”的半提交状态。 */
  s_data = previous_data;
  s_sequence = previous_sequence;
  s_active_slot = previous_slot;
  return false;
}

bool Calibration_SetDac(uint16_t voltage_1_mv,
                        uint16_t code_1,
                        uint16_t voltage_2_mv,
                        uint16_t code_2)
{
  if ((voltage_1_mv < POWER_CFG_VOLTAGE_MIN_MV) ||
      (voltage_2_mv > POWER_CFG_VOLTAGE_MAX_MV) ||
      (voltage_1_mv >= voltage_2_mv) ||
      (code_1 > CALIBRATION_DAC_CODE_MAX) ||
      (code_2 > CALIBRATION_DAC_CODE_MAX) ||
      (code_1 <= code_2))
  {
    return false;
  }
  s_data.dac_voltage_1_mv = voltage_1_mv;
  s_data.dac_code_1 = code_1;
  s_data.dac_voltage_2_mv = voltage_2_mv;
  s_data.dac_code_2 = code_2;
  s_data.dac_valid = true;
  s_data.loaded_from_flash = false;
  return true;
}

bool Calibration_Save(void)
{
  Calibration_Record_t record;
  Calibration_Record_t verify;
  uint32_t target_address;
  int8_t target_slot;

  (void)memset(&record, 0, sizeof(record));
  record.magic = CALIBRATION_MAGIC;
  record.schema_version = CALIBRATION_SCHEMA_VERSION;
  record.size = sizeof(record);
  record.sequence = s_sequence + 1U;
  record.voltage_gain_ppm = s_data.voltage_gain_ppm;
  record.voltage_offset_mv = s_data.voltage_offset_mv;
  record.current_gain_ppm = s_data.current_gain_ppm;
  record.current_offset_ua = s_data.current_offset_ua;
  record.dac_voltage_1_mv = s_data.dac_voltage_1_mv;
  record.dac_code_1 = s_data.dac_code_1;
  record.dac_voltage_2_mv = s_data.dac_voltage_2_mv;
  record.dac_code_2 = s_data.dac_code_2;
  record.measurement_valid =
    (uint8_t)((s_data.voltage_valid ? CALIBRATION_VALID_VOLTAGE_MASK : 0U) |
              (s_data.current_valid ? CALIBRATION_VALID_CURRENT_MASK : 0U));
  record.dac_valid = s_data.dac_valid ? 1U : 0U;
  record.crc32 = 0U;
  record.crc32 = Calibration_Crc32(&record, sizeof(record));

  if (!W25Q256_IsReady() && !W25Q256_Init())
  {
    return false;
  }

  target_slot = (s_active_slot == 0) ? 1 : 0;
  target_address = (target_slot == 0) ? CALIBRATION_SLOT_0_ADDRESS :
                                        CALIBRATION_SLOT_1_ADDRESS;
  if (!W25Q256_EraseSector(target_address) ||
      !W25Q256_Write(target_address, &record, sizeof(record)) ||
      !W25Q256_Read(target_address, &verify, sizeof(verify)) ||
      !Calibration_RecordValid(&verify) ||
      (memcmp(&record, &verify, sizeof(record)) != 0))
  {
    return false;
  }

  s_active_slot = target_slot;
  s_sequence = record.sequence;
  s_data.loaded_from_flash = true;
  return true;
}

uint16_t Calibration_ApplyVoltage(uint16_t raw_mv)
{
  int64_t result;

  if (!s_data.voltage_valid)
  {
    return raw_mv;
  }
  result = ((int64_t)raw_mv * s_data.voltage_gain_ppm + 500000LL) /
           1000000LL + s_data.voltage_offset_mv;
  if (result < 0)
  {
    return 0U;
  }
  return (result > UINT16_MAX) ? UINT16_MAX : (uint16_t)result;
}

int32_t Calibration_ApplyCurrent(int32_t raw_ua)
{
  int64_t result;

  if (!s_data.current_valid)
  {
    return raw_ua;
  }
  result = ((int64_t)raw_ua * s_data.current_gain_ppm) / 1000000LL +
           s_data.current_offset_ua;
  if (result > INT32_MAX)
  {
    return INT32_MAX;
  }
  if (result < INT32_MIN)
  {
    return INT32_MIN;
  }
  return (int32_t)result;
}

bool Calibration_MapDac(uint16_t voltage_mv, uint16_t *code)
{
  int64_t numerator;
  int64_t result;
  int32_t voltage_span;

  if ((code == NULL) || !s_data.dac_valid)
  {
    return false;
  }
  voltage_span = (int32_t)s_data.dac_voltage_2_mv -
                 (int32_t)s_data.dac_voltage_1_mv;
  numerator = (int64_t)((int32_t)voltage_mv -
                        (int32_t)s_data.dac_voltage_1_mv) *
              ((int32_t)s_data.dac_code_2 - (int32_t)s_data.dac_code_1);
  result = (int64_t)s_data.dac_code_1 + numerator / voltage_span;
  if (result < 0)
  {
    result = 0;
  }
  else if (result > CALIBRATION_DAC_CODE_MAX)
  {
    result = CALIBRATION_DAC_CODE_MAX;
  }
  *code = (uint16_t)result;
  return true;
}
