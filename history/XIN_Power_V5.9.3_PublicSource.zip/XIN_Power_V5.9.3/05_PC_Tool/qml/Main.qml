import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

ApplicationWindow {
    id: root
    width: 1320
    height: 850
    minimumWidth: 1050
    minimumHeight: 700
    visible: true
    title: "XIN Power  ·  Studio 5.9.3"
    color: "#0A1018"
    property int activePage: 0
    property color mint: "#3DE2B4"
    property color textMain: "#F1F6FA"
    property color textDim: "#8C9BAC"
    property color cardColor: "#151E29"
    property color borderColor: "#273644"

    component Panel: Rectangle {
        color: root.cardColor
        radius: 20
        border.width: 1
        border.color: root.borderColor
    }

    component ActionButton: Button {
        id: action
        property color fillColor: root.mint
        property color inkColor: "#081B19"
        implicitHeight: 44
        implicitWidth: 130
        font.pixelSize: 15
        font.weight: Font.DemiBold
        background: Rectangle {
            radius: 11
            color: action.enabled ? (action.down ? Qt.darker(action.fillColor, 1.18) : action.fillColor) : "#263544"
            border.color: action.enabled ? action.fillColor : "#425366"
            border.width: 1
        }
        contentItem: Text {
            text: action.text
            color: action.enabled ? action.inkColor : "#B5C2CE"
            font: action.font
            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
        }
    }

    component Field: TextField {
        implicitHeight: 47
        color: root.textMain
        placeholderTextColor: "#8191A2"
        selectionColor: "#276D62"
        selectedTextColor: "#FFFFFF"
        font.pixelSize: 18
        leftPadding: 14
        rightPadding: 14
        verticalAlignment: TextInput.AlignVCenter
        selectByMouse: true
        background: Rectangle {
            radius: 11
            color: "#101B27"
            border.width: 1
            border.color: parent.activeFocus ? root.mint : "#344555"
        }
    }

    component StudioScrollBar: ScrollBar {
        id: bar
        minimumSize: 0.10
        padding: 2
        policy: ScrollBar.AlwaysOn
        contentItem: Rectangle {
            implicitWidth: 14
            implicitHeight: 14
            radius: 6
            color: bar.pressed ? root.mint : (bar.hovered ? "#7BA596" : "#5E7C91")
        }
        background: Rectangle { color: "#0D1722"; radius: 7; border.color: "#304252" }
    }

    component StudioCombo: ComboBox {
        id: combo
        implicitHeight: 42
        font.pixelSize: 14
        contentItem: Text {
            text: combo.displayText
            color: combo.enabled ? root.textMain : root.textDim
            font: combo.font
            verticalAlignment: Text.AlignVCenter
            elide: Text.ElideRight
            leftPadding: 12
            rightPadding: 28
        }
        indicator: Text { text: "⌄"; color: root.mint; font.pixelSize: 18; anchors.right: parent.right; anchors.rightMargin: 10; anchors.verticalCenter: parent.verticalCenter }
        background: Rectangle { radius: 10; color: "#101B27"; border.color: combo.activeFocus ? root.mint : "#344555" }
        delegate: ItemDelegate {
            width: combo.popup.width - 10
            height: 38
            highlighted: combo.highlightedIndex === index
            contentItem: Text { text: modelData; color: root.textMain; font.pixelSize: 14; verticalAlignment: Text.AlignVCenter; leftPadding: 8; elide: Text.ElideRight }
            background: Rectangle { radius: 7; color: parent.highlighted ? "#1C5652" : (parent.hovered ? "#223241" : "transparent") }
        }
        popup: Popup {
            y: combo.height + 4
            width: combo.width
            implicitHeight: Math.min(contentItem.implicitHeight + 10, 340)
            padding: 5
            contentItem: ListView { clip: true; implicitHeight: contentHeight; model: combo.popup.visible ? combo.delegateModel : null; currentIndex: combo.highlightedIndex; ScrollBar.vertical: StudioScrollBar { } }
            background: Rectangle { radius: 11; color: "#172330"; border.color: root.borderColor }
        }
    }

    component NavButton: Rectangle {
        id: nav
        property int page: 0
        property string caption: ""
        property string glyph: "•"
        Layout.fillWidth: true
        height: 49
        radius: 11
        color: root.activePage === page ? "#193E3E" : (mouse.containsMouse ? "#1A2734" : "transparent")
        border.color: root.activePage === page ? "#2B8A78" : "transparent"
        border.width: 1
        Row {
            anchors.verticalCenter: parent.verticalCenter
            anchors.left: parent.left
            anchors.leftMargin: 19
            spacing: 16
            Text { text: nav.glyph; color: root.activePage === nav.page ? root.mint : root.textDim; font.pixelSize: 20; width: 24 }
            Text { text: nav.caption; color: root.activePage === nav.page ? root.textMain : root.textDim; font.pixelSize: 15; font.weight: root.activePage === nav.page ? Font.DemiBold : Font.Normal }
        }
        MouseArea { id: mouse; anchors.fill: parent; hoverEnabled: true; onClicked: root.activePage = nav.page }
    }

    header: Rectangle {
        height: 78
        color: "#0F1822"
        border.color: root.borderColor
        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: 30
            anchors.rightMargin: 28
            spacing: 16
            Rectangle { width: 37; height: 37; radius: 10; color: "#1B5D54"; Text { anchors.centerIn: parent; text: "X"; color: root.mint; font.pixelSize: 27; font.bold: true } }
            Column {
                spacing: 1
                Text { text: "XIN Power"; color: root.textMain; font.pixelSize: 21; font.bold: true }
                Text { text: "POWER CONTROL STUDIO"; color: root.textDim; font.pixelSize: 10; font.letterSpacing: 2 }
            }
            Item { Layout.fillWidth: true }
            Rectangle {
                width: 300; height: 37; radius: 18
                color: bridge.connected ? "#173C35" : "#25303A"
                border.color: bridge.connected ? "#33876D" : "#374756"
                Row { anchors.centerIn: parent; spacing: 9
                    Rectangle { width: 8; height: 8; radius: 4; anchors.verticalCenter: parent.verticalCenter; color: bridge.connected ? root.mint : "#8C9BAC" }
                    Text { text: bridge.connectionText; color: bridge.connected ? root.mint : root.textDim; font.pixelSize: 13; elide: Text.ElideRight; width: 253 }
                }
            }
            Text { text: "FW " + bridge.firmware; color: root.textDim; font.pixelSize: 13 }
        }
    }

    RowLayout {
        anchors.fill: parent
        spacing: 0
        Rectangle {
            Layout.preferredWidth: 270
            Layout.fillHeight: true
            color: "#101A25"
            border.color: root.borderColor
            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 17
                spacing: 8
                Text { text: "工作区"; color: "#64798B"; font.pixelSize: 12; font.letterSpacing: 2; Layout.leftMargin: 14; Layout.topMargin: 19; Layout.bottomMargin: 10 }
                NavButton { page: 0; glyph: "◉"; caption: "设备概览" }
                NavButton { page: 1; glyph: "⌁"; caption: "实时趋势" }
                NavButton { page: 2; glyph: "◇"; caption: "精度校准" }
                NavButton { page: 3; glyph: "↑"; caption: "固件升级" }
                NavButton { page: 4; glyph: "≡"; caption: "通讯日志" }
                Item { Layout.fillHeight: true }
                Panel {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 224
                    ColumnLayout {
                        anchors.fill: parent
                        anchors.margins: 14
                        spacing: 10
                        Text { text: "连接设备"; color: root.textMain; font.pixelSize: 15; font.weight: Font.DemiBold }
                        ComboBox {
                            id: portCombo
                            Layout.fillWidth: true
                            implicitHeight: 44
                            model: bridge.ports
                            enabled: !bridge.connected && !bridge.updating && !bridge.scanning
                            font.pixelSize: 13
                            onActivated: bridge.selectPort(currentText)
                            function syncSelection() {
                                if (count > 0) {
                                    let choice = 0
                                    for (let i = 0; i < count; i++) {
                                        if (textAt(i).indexOf(bridge.selectedPort + "  ·") === 0) {
                                            choice = i
                                            break
                                        }
                                    }
                                    currentIndex = choice
                                    bridge.selectPort(currentText)
                                }
                            }
                            onCountChanged: Qt.callLater(syncSelection)
                            onModelChanged: Qt.callLater(syncSelection)
                            contentItem: Text {
                                leftPadding: 12
                                rightPadding: 31
                                text: portCombo.displayText || "选择 USB / 蓝牙串口"
                                color: portCombo.count ? root.textMain : root.textDim
                                font.pixelSize: 13
                                verticalAlignment: Text.AlignVCenter
                                elide: Text.ElideRight
                            }
                            indicator: Text {
                                text: "⌄"
                                color: root.mint
                                font.pixelSize: 19
                                anchors.right: parent.right
                                anchors.rightMargin: 12
                                anchors.verticalCenter: parent.verticalCenter
                            }
                            background: Rectangle {
                                radius: 10
                                color: "#101B27"
                                border.width: 1
                                border.color: portCombo.activeFocus ? root.mint : "#344555"
                            }
                            delegate: ItemDelegate {
                                width: portCombo.popup.width - 10
                                height: 42
                                text: modelData
                                contentItem: Text {
                                    text: modelData
                                    color: root.textMain
                                    font.pixelSize: 13
                                    verticalAlignment: Text.AlignVCenter
                                    elide: Text.ElideRight
                                    leftPadding: 11
                                    rightPadding: 11
                                }
                                background: Rectangle {
                                    radius: 7
                                    color: highlighted ? "#1C5652" : (hovered ? "#223241" : "transparent")
                                }
                            }
                            popup: Popup {
                                y: portCombo.height + 4
                                width: Math.max(portCombo.width, 420)
                                implicitHeight: Math.min(contentItem.implicitHeight + 10, 240)
                                padding: 5
                                contentItem: ListView {
                                    clip: true
                                    implicitHeight: contentHeight
                                    model: portCombo.popup.visible ? portCombo.delegateModel : null
                                    currentIndex: portCombo.highlightedIndex
                                    ScrollIndicator.vertical: ScrollIndicator { }
                                }
                                background: Rectangle {
                                    radius: 11
                                    color: "#172330"
                                    border.width: 1
                                    border.color: root.borderColor
                                }
                            }
                        }
                        RowLayout {
                            Layout.fillWidth: true
                            spacing: 8
                            ActionButton { text: bridge.scanning ? "识别中" : "扫描识别"; enabled: !bridge.scanning && !bridge.updating; Layout.fillWidth: true; fillColor: "#273B4D"; inkColor: root.textMain; onClicked: bridge.scanPorts() }
                            ActionButton { text: bridge.connected ? "断开" : "连接"; enabled: !bridge.updating && !bridge.scanning && bridge.selectedPort !== ""; Layout.fillWidth: true; onClicked: bridge.connected ? bridge.disconnectDevice() : bridge.connectDevice() }
                        }
                        Text { text: bridge.scanText; color: root.textDim; font.pixelSize: 12; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                        Text { text: bridge.selectedPort ? "当前选择 " + bridge.selectedPort + "  ·  " + bridge.selectedTransport : "尚未选择端口"; color: root.mint; font.pixelSize: 12 }
                    }
                }
            }
        }

        StackLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            currentIndex: root.activePage

            // Dashboard
            Flickable {
                contentWidth: width
                contentHeight: overviewColumn.implicitHeight + 60
                clip: true
                ScrollBar.vertical: ScrollBar { }
                ColumnLayout {
                    id: overviewColumn
                    width: parent.width - 72
                    x: 36; y: 30
                    spacing: 21
                    RowLayout {
                        Layout.fillWidth: true
                        ColumnLayout { spacing: 3
                            Text { text: "设备概览"; color: root.textMain; font.pixelSize: 29; font.bold: true }
                            Text { text: "实时监测和输出控制集中在一处"; color: root.textDim; font.pixelSize: 14 }
                        }
                        Item { Layout.fillWidth: true }
                        Text { text: "遥测  " + bridge.telemetryRateText; color: root.textDim; font.pixelSize: 13 }
                        Text { text: bridge.hardware; color: root.mint; font.pixelSize: 13 }
                    }
                    RowLayout {
                        Layout.fillWidth: true; spacing: 18
                        Panel { Layout.fillWidth: true; Layout.preferredHeight: 220
                            Column { anchors.fill: parent; anchors.margins: 24; spacing: 17
                                Text { text: "OUTPUT VOLTAGE"; color: root.textDim; font.pixelSize: 12; font.letterSpacing: 2 }
                                Row { spacing: 9
                                    Text { text: bridge.voltage; color: root.mint; font.pixelSize: 71; font.weight: Font.Medium }
                                    Text { text: "V"; color: root.mint; font.pixelSize: 25; anchors.bottom: parent.bottom; anchors.bottomMargin: 11 }
                                }
                                Text { text: "设定  " + bridge.setVoltage + " V"; color: root.textDim; font.pixelSize: 15 }
                            }
                        }
                        Panel { Layout.fillWidth: true; Layout.preferredHeight: 220
                            Column { anchors.fill: parent; anchors.margins: 24; spacing: 17
                                Text { text: "OUTPUT CURRENT"; color: root.textDim; font.pixelSize: 12; font.letterSpacing: 2 }
                                Row { spacing: 9
                                    Text { text: bridge.current; color: "#87B8FF"; font.pixelSize: 71; font.weight: Font.Medium }
                                    Text { text: "A"; color: "#87B8FF"; font.pixelSize: 25; anchors.bottom: parent.bottom; anchors.bottomMargin: 11 }
                                }
                                Text { text: "限流  " + bridge.setCurrent + " A"; color: root.textDim; font.pixelSize: 15 }
                            }
                        }
                    }
                    RowLayout {
                        Layout.fillWidth: true; spacing: 18
                        Panel { Layout.fillWidth: true; Layout.preferredHeight: 112
                            Column { anchors.fill: parent; anchors.margins: 20; spacing: 9
                                Text { text: "输入电压"; color: root.textDim; font.pixelSize: 13 }
                                Text { text: bridge.inputVoltage + " V"; color: root.textMain; font.pixelSize: 25; font.weight: Font.DemiBold }
                            }
                        }
                        Panel { Layout.fillWidth: true; Layout.preferredHeight: 112
                            Column { anchors.fill: parent; anchors.margins: 20; spacing: 9
                                Text { text: "输出功率"; color: root.textDim; font.pixelSize: 13 }
                                Text { text: bridge.power + " W"; color: root.textMain; font.pixelSize: 25; font.weight: Font.DemiBold }
                            }
                        }
                        Panel { Layout.fillWidth: true; Layout.preferredHeight: 112
                            Column { anchors.fill: parent; anchors.margins: 20; spacing: 9
                                Text { text: "温度 / 保护"; color: root.textDim; font.pixelSize: 13 }
                                Text { text: bridge.temperature + " °C"; color: root.textMain; font.pixelSize: 25; font.weight: Font.DemiBold }
                            }
                        }
                    }
                    Panel {
                        Layout.fillWidth: true; Layout.preferredHeight: 200
                        RowLayout { anchors.fill: parent; anchors.margins: 24; spacing: 20
                            ColumnLayout { Layout.fillWidth: true; spacing: 10
                                Text { text: "输出设定"; color: root.textMain; font.pixelSize: 19; font.weight: Font.DemiBold }
                                RowLayout { spacing: 11
                                    Field { id: voltageField; Layout.preferredWidth: 146; placeholderText: "电压 V"; Component.onCompleted: text = bridge.setVoltage }
                                    Text { text: "V"; color: root.textDim; font.pixelSize: 17 }
                                    Field { id: currentField; Layout.preferredWidth: 146; placeholderText: "电流 A"; Component.onCompleted: text = bridge.setCurrent }
                                    Text { text: "A"; color: root.textDim; font.pixelSize: 17 }
                                    ActionButton { text: "应用设定"; enabled: bridge.connected; onClicked: bridge.applySetpoints(voltageField.text, currentField.text) }
                                }
                                Text { text: "电压 2–32 V  ·  电流 0.1–8 A  ·  断开后设定由设备保存"; color: root.textDim; font.pixelSize: 12 }
                            }
                            Rectangle { width: 1; Layout.fillHeight: true; color: root.borderColor }
                            ColumnLayout { Layout.preferredWidth: 175; spacing: 12
                                Text { text: bridge.fault === "NONE" ? "保护状态正常" : "故障: " + bridge.fault; color: bridge.fault === "NONE" ? root.textDim : "#FF7A80"; font.pixelSize: 12 }
                                ActionButton { Layout.fillWidth: true; text: bridge.outputOn ? "关闭输出" : "开启输出"; fillColor: bridge.outputOn ? "#DA4C58" : root.mint; inkColor: "#0A1720"; enabled: bridge.connected; onClicked: bridge.toggleOutput() }
                                ActionButton { Layout.fillWidth: true; text: "清除故障"; fillColor: "#263747"; inkColor: root.textMain; enabled: bridge.connected; onClicked: bridge.clearFault() }
                            }
                        }
                    }
                }
            }

            // Trends
            Item {
                ColumnLayout { anchors.fill: parent; anchors.margins: 36; spacing: 21
                    Text { text: "实时趋势"; color: root.textMain; font.pixelSize: 29; font.bold: true }
                    Text { text: "最近 140 帧 · 实际回传 " + bridge.telemetryRateText + "；完整记录可导出为 CSV"; color: root.textDim; font.pixelSize: 14 }
                    Panel { Layout.fillWidth: true; Layout.fillHeight: true
                        ColumnLayout { anchors.fill: parent; anchors.margins: 24; spacing: 12
                            Text { text: "输出电压  ·  V"; color: root.mint; font.pixelSize: 16; font.bold: true }
                            Canvas { id: voltageChart; Layout.fillWidth: true; Layout.fillHeight: true
                                onPaint: drawSeries(getContext("2d"), bridge.historyVoltage, root.mint, width, height)
                            }
                        }
                    }
                    Panel { Layout.fillWidth: true; Layout.fillHeight: true
                        ColumnLayout { anchors.fill: parent; anchors.margins: 24; spacing: 12
                            Text { text: "输出电流  ·  A"; color: "#87B8FF"; font.pixelSize: 16; font.bold: true }
                            Canvas { id: currentChart; Layout.fillWidth: true; Layout.fillHeight: true
                                onPaint: drawSeries(getContext("2d"), bridge.historyCurrent, "#87B8FF", width, height)
                            }
                        }
                    }
                    ActionButton { text: "导出 CSV"; fillColor: "#263747"; inkColor: root.textMain; onClicked: bridge.exportCsv() }
                }
            }

            // Calibration
            Flickable { contentWidth: width; contentHeight: calibrationColumn.implicitHeight + 70; clip: true; ScrollBar.vertical: ScrollBar { }
                ColumnLayout { id: calibrationColumn; width: parent.width - 72; x: 36; y: 30; spacing: 18
                    Text { text: "高精度电压校准"; color: root.textMain; font.pixelSize: 29; font.bold: true }
                    Text { text: "保留 5 V / 20 V 两点校准。请使用可信万用表，确保输出端接线正确。"; color: root.textDim; font.pixelSize: 14 }
                    Panel { Layout.fillWidth: true; Layout.preferredHeight: 100
                        RowLayout { anchors.fill: parent; anchors.margins: 22
                            Text { text: bridge.calibrationStatus; color: root.mint; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                            ActionButton { text: "开始 5 V 校准"; enabled: bridge.connected; onClicked: bridge.prepareCalibration() }
                        }
                    }
                    RowLayout { Layout.fillWidth: true; spacing: 18
                        Panel { Layout.fillWidth: true; Layout.preferredHeight: 200
                            ColumnLayout { anchors.fill: parent; anchors.margins: 22; spacing: 12
                                Text { text: "01  /  5 V 采集点"; color: root.textMain; font.pixelSize: 19; font.bold: true }
                                Text { text: "等待电压稳定后，输入万用表的实际读数"; color: root.textDim; font.pixelSize: 13 }
                                RowLayout { Field { id: actual5; text: "5.000"; Layout.fillWidth: true }
                                    Text { text: "V"; color: root.textDim }
                                }
                                ActionButton { text: "采集 5 V 原始值"; enabled: bridge.connected; onClicked: bridge.captureCalibration(1, actual5.text) }
                            }
                        }
                        Panel { Layout.fillWidth: true; Layout.preferredHeight: 200
                            ColumnLayout { anchors.fill: parent; anchors.margins: 22; spacing: 12
                                Text { text: "02  /  20 V 采集点"; color: root.textMain; font.pixelSize: 19; font.bold: true }
                                Text { text: "第 1 点完成后设备自动设为 20 V"; color: root.textDim; font.pixelSize: 13 }
                                RowLayout { Field { id: actual20; text: "20.000"; Layout.fillWidth: true }
                                    Text { text: "V"; color: root.textDim }
                                }
                                ActionButton { text: "采集 20 V 原始值"; enabled: bridge.connected; onClicked: bridge.captureCalibration(2, actual20.text) }
                            }
                        }
                    }
                    Panel { Layout.fillWidth: true; Layout.preferredHeight: 104
                        RowLayout { anchors.fill: parent; anchors.margins: 22
                            Text { text: "保存时先关闭输出，再写入 W25Q256 的校准备份区。"; color: root.textDim; font.pixelSize: 14; Layout.fillWidth: true }
                            ActionButton { text: "计算并保存校准"; enabled: bridge.connected; onClicked: bridge.saveVoltageCalibration() }
                        }
                    }
                    Text { text: "电流零点和 DAC 深度校准仍可通过原版工具完成；本页专注 0.001 V 电压两点校准。"; color: root.textDim; font.pixelSize: 12 }
                    Panel { Layout.fillWidth: true; Layout.preferredHeight: 118
                        RowLayout { anchors.fill: parent; anchors.margins: 22; spacing: 18
                            Text { text: bridge.voltageDiagnostic; color: root.textDim; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                            ActionButton { text: "读取校准参数"; enabled: bridge.connected && !bridge.updating; onClicked: bridge.runQuickCommand("CAL GET") }
                        }
                    }
                }
            }

            // Firmware update
            Flickable { contentWidth: width; contentHeight: updateColumn.implicitHeight + 70; clip: true; ScrollBar.vertical: ScrollBar { }
                ColumnLayout { id: updateColumn; width: parent.width - 72; x: 36; y: 30; spacing: 20
                    Text { text: "固件升级"; color: root.textMain; font.pixelSize: 29; font.bold: true }
                    Text { text: "USB / 蓝牙 SPP 上传至 W25Q256 · BL 校验刷写 · 失败自动回退"; color: root.textDim; font.pixelSize: 14 }
                    Panel { Layout.fillWidth: true; Layout.preferredHeight: 110
                        RowLayout { anchors.fill: parent; anchors.margins: 22; spacing: 18
                            Rectangle { width: 43; height: 43; radius: 11; color: "#1B5D54"; Text { anchors.centerIn: parent; text: "✓"; color: root.mint; font.pixelSize: 23 } }
                            ColumnLayout { Layout.fillWidth: true; spacing: 4
                                Text { text: "安全检查"; color: root.textMain; font.pixelSize: 17; font.bold: true }
                            Text { text: "请先扫描识别并连接 XIN Power。上传使用当前连接；只有执行刷写重启时才暂时断开，随后自动恢复。"; color: root.textDim; font.pixelSize: 13; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                            }
                        }
                    }
                    Panel { Layout.fillWidth: true; Layout.preferredHeight: 225
                        ColumnLayout { anchors.fill: parent; anchors.margins: 24; spacing: 16
                            Text { text: "01  选择应用固件"; color: root.textMain; font.pixelSize: 18; font.bold: true }
                            RowLayout { Layout.fillWidth: true; spacing: 14
                                Field { text: bridge.imagePath; readOnly: true; placeholderText: "选择 Keil 生成的 .hex 文件"; Layout.fillWidth: true }
                                ActionButton { text: "浏览文件"; fillColor: "#263747"; inkColor: root.textMain; onClicked: bridge.chooseFirmware() }
                            }
                            RowLayout { spacing: 14
                                Text { text: "目标版本"; color: root.textDim; font.pixelSize: 14 }
                                Field { id: targetVersion; text: "5.9.3"; Layout.preferredWidth: 130 }
                                Text { text: "设备版本  V" + bridge.firmware + "  ·  " + bridge.hardware; color: root.textDim; font.pixelSize: 13 }
                                Text { text: "当前链路  " + bridge.selectedTransport; color: root.mint; font.pixelSize: 13 }
                            }
                        }
                    }
                    Panel { Layout.fillWidth: true; Layout.preferredHeight: 206
                        ColumnLayout { anchors.fill: parent; anchors.margins: 24; spacing: 18
                            Text { text: "02  传输和刷写"; color: root.textMain; font.pixelSize: 18; font.bold: true }
                            Text { text: bridge.updateStatus; color: root.textDim; font.pixelSize: 14; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                            ProgressBar { from: 0; to: 100; value: bridge.updateProgress; Layout.fillWidth: true; implicitHeight: 14 }
                            RowLayout { Layout.fillWidth: true
                                Text { text: bridge.updateProgress + "%"; color: root.mint; font.pixelSize: 15; font.bold: true }
                                Item { Layout.fillWidth: true }
                                ActionButton { text: "取消上传"; fillColor: "#263747"; inkColor: root.textMain; enabled: bridge.updating && bridge.updateProgress < 82; onClicked: bridge.cancelUpgrade() }
                                ActionButton { text: bridge.updating ? "升级进行中" : "开始升级"; enabled: !bridge.updating && bridge.connected && bridge.imagePath !== ""; onClicked: bridge.startUpgrade(targetVersion.text) }
                            }
                        }
                    }
                    Text { text: "在 BL 刷写阶段取消不可用。若升级失败，请勿带载，先查看设备版本或使用 SWD 恢复。"; color: "#F3B783"; font.pixelSize: 12 }
                }
            }

            // Logs
            Item {
                ColumnLayout { anchors.fill: parent; anchors.margins: 36; spacing: 17
                    RowLayout { Layout.fillWidth: true
                        ColumnLayout { spacing: 3
                            Text { text: "通讯日志"; color: root.textMain; font.pixelSize: 29; font.bold: true }
                            Text { text: "设备响应、告警和操作记录"; color: root.textDim; font.pixelSize: 14 }
                        }
                        Item { Layout.fillWidth: true }
                        Text { text: "实际回传  " + bridge.telemetryRateText; color: root.mint; font.pixelSize: 13 }
                    }
                    Flow { Layout.fillWidth: true; Layout.preferredHeight: implicitHeight; spacing: 8
                        ActionButton { text: bridge.logPaused ? "继续刷新" : "暂停刷新"; implicitWidth: 110; fillColor: bridge.logPaused ? root.mint : "#263747"; inkColor: bridge.logPaused ? "#081B19" : root.textMain; onClicked: bridge.toggleLogPause() }
                        ActionButton { text: "回到最新"; implicitWidth: 110; fillColor: "#263747"; inkColor: root.textMain; onClicked: { if (bridge.logPaused) bridge.toggleLogPause(); logScroll.followTail = true; Qt.callLater(logScroll.scrollToEnd) } }
                        ActionButton { text: "清空日志"; implicitWidth: 110; fillColor: "#263747"; inkColor: root.textMain; onClicked: { bridge.clearLog(); logScroll.followTail = true; Qt.callLater(logScroll.scrollToEnd) } }
                        ActionButton { text: "导出日志"; implicitWidth: 110; fillColor: "#263747"; inkColor: root.textMain; onClicked: bridge.exportLog() }
                        ActionButton { text: "导出 CSV"; implicitWidth: 110; fillColor: "#263747"; inkColor: root.textMain; onClicked: bridge.exportCsv() }
                    }
                    Text { Layout.fillWidth: true; wrapMode: Text.WordWrap; font.pixelSize: 12
                        text: bridge.logPaused ? "显示已暂停 · 新到 " + bridge.pendingLogCount + " 条；接收和 CSV 记录继续，日志保留最近 1000 条。" : "日志保留最近 1000 条 · 上翻浏览历史，回到最新恢复跟随；清空日志不删除 CSV 数据。"
                        color: bridge.logPaused ? "#F3B783" : root.textDim
                    }
                    RowLayout { Layout.fillWidth: true; spacing: 9
                        StudioCombo { id: quickCommand; Layout.fillWidth: true
                            model: ["连接测试 · PING", "设备信息 · INFO", "当前状态 · STATUS", "校准参数 · CAL GET", "原始测量 · CAL RAW", "通讯诊断 · DIAG", "升级状态 · FW STATUS", "命令帮助 · HELP", "开启设备回传 · LOG ON", "停止设备回传 · LOG OFF"]
                            property var commands: ["PING", "INFO", "STATUS", "CAL GET", "CAL RAW", "DIAG", "FW STATUS", "HELP", "LOG ON", "LOG OFF"]
                        }
                        ActionButton { text: "执行"; implicitWidth: 70; enabled: bridge.connected && !bridge.updating; onClicked: bridge.runQuickCommand(quickCommand.commands[quickCommand.currentIndex]) }
                        StudioCombo { id: rateChoice; Layout.preferredWidth: 157; model: ["2 Hz / 500 ms", "5 Hz / 200 ms", "10 Hz / 100 ms", "1 Hz / 1000 ms", "0.5 Hz / 2000 ms", "0.2 Hz / 5000 ms"]; property var intervals: [500, 200, 100, 1000, 2000, 5000] }
                        ActionButton { text: "应用速率"; implicitWidth: 100; enabled: bridge.connected && !bridge.updating; onClicked: bridge.setTelemetryInterval(rateChoice.intervals[rateChoice.currentIndex]) }
                    }
                    Panel { Layout.fillWidth: true; Layout.fillHeight: true
                        ScrollView { id: logScroll; objectName: "logScroll"; anchors.fill: parent; anchors.margins: 14
                            rightPadding: 18
                            bottomPadding: 18
                            property bool followTail: true
                            property real preservedY: 0
                            function scrollToEnd() {
                                contentItem.contentY = Math.max(0, contentItem.contentHeight - contentItem.height)
                            }
                            ScrollBar.vertical: StudioScrollBar {
                                objectName: "logVerticalBar"
                                parent: logScroll
                                x: logScroll.width - width
                                y: 0
                                height: logScroll.availableHeight
                                onPressedChanged: {
                                    if (pressed) logScroll.followTail = false
                                    else if (position + size >= 0.98) logScroll.followTail = true
                                }
                            }
                            ScrollBar.horizontal: StudioScrollBar {
                                objectName: "logHorizontalBar"
                                parent: logScroll
                                x: 0
                                y: logScroll.height - height
                                width: logScroll.availableWidth
                            }
                            TextArea { id: logArea; objectName: "logArea"; readOnly: true; wrapMode: TextEdit.NoWrap; color: "#CAD7E3"; font.family: "Consolas"; font.pixelSize: 13; selectionColor: "#276D62"; selectedTextColor: "#FFFFFF"; background: Rectangle { color: "transparent" }
                                Component.onCompleted: {
                                    text = bridge.logText
                                    Qt.callLater(logScroll.scrollToEnd)
                                }
                            }
                            Connections {
                                target: bridge
                                function onLogsChanged() {
                                    if (!logScroll.followTail) logScroll.preservedY = logScroll.contentItem.contentY
                                    logArea.text = bridge.logText
                                    Qt.callLater(function() {
                                        if (logScroll.followTail) logScroll.scrollToEnd()
                                        else logScroll.contentItem.contentY = Math.min(
                                            logScroll.preservedY,
                                            Math.max(0, logScroll.contentItem.contentHeight - logScroll.contentItem.height))
                                    })
                                }
                            }
                            Connections {
                                target: logScroll.contentItem
                                function onMovementStarted() { logScroll.followTail = false }
                                function onMovementEnded() {
                                    if (logScroll.contentItem.contentY >=
                                            logScroll.contentItem.contentHeight - logScroll.contentItem.height - 8)
                                        logScroll.followTail = true
                                }
                            }
                        }
                    }
                    RowLayout { Layout.fillWidth: true; spacing: 12
                        Field { id: commandField; Layout.fillWidth: true; enabled: bridge.connected && !bridge.updating; placeholderText: "高级命令：确认含义后发送（HELP 查看命令）"; onAccepted: { bridge.sendCommand(text); text = "" } }
                        ActionButton { text: "发送命令"; enabled: bridge.connected && !bridge.updating; onClicked: { bridge.sendCommand(commandField.text); commandField.text = "" } }
                    }
                }
            }
        }
    }

    function drawSeries(ctx, series, stroke, w, h) {
        ctx.clearRect(0, 0, w, h)
        ctx.strokeStyle = "#2A3948"
        ctx.lineWidth = 1
        for (var grid = 1; grid < 4; grid++) {
            var y = h * grid / 4
            ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke()
        }
        if (series.length < 2) return
        var lowest = Math.min.apply(null, series)
        var highest = Math.max.apply(null, series)
        var span = Math.max(0.1, highest - lowest)
        ctx.strokeStyle = stroke
        ctx.lineWidth = 2.5
        ctx.beginPath()
        for (var i = 0; i < series.length; i++) {
            var px = 8 + i * (w - 16) / Math.max(139, series.length - 1)
            var py = h - 10 - ((series[i] - lowest) / span) * (h - 20)
            if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py)
        }
        ctx.stroke()
    }
    Connections {
        target: bridge
        function onTelemetryChanged() {
            voltageChart.requestPaint()
            currentChart.requestPaint()
        }
    }
}
