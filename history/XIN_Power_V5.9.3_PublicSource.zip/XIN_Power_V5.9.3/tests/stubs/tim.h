#ifndef TEST_TIM_H
#define TEST_TIM_H
#include <stdint.h>
typedef struct { uint32_t period; uint32_t compare; } TIM_HandleTypeDef;
typedef enum { HAL_OK = 0, HAL_ERROR = 1 } HAL_StatusTypeDef;
extern TIM_HandleTypeDef htim3;
#define TIM_CHANNEL_1 0U
#define __HAL_TIM_SET_COMPARE(timer, channel, value) ((timer)->compare = (value))
#define __HAL_TIM_GET_AUTORELOAD(timer) ((timer)->period)
HAL_StatusTypeDef HAL_TIM_PWM_Start(TIM_HandleTypeDef *timer, uint32_t channel);
#endif
