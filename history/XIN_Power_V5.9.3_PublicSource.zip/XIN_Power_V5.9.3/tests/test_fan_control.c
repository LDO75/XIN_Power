#include "fan_control.h"
#include "tim.h"
#include <assert.h>
#include <stdio.h>
TIM_HandleTypeDef htim3 = {999, 0};
HAL_StatusTypeDef HAL_TIM_PWM_Start(TIM_HandleTypeDef *timer, uint32_t channel)
{ (void)timer; (void)channel; return HAL_OK; }
int main(void)
{
  assert(FanControl_Init());
  FanControl_Update(399, true);
  assert(FanControl_GetDutyPercent() == 0U);
  FanControl_Update(400, true);
  assert(FanControl_GetDutyPercent() == 100U && htim3.compare == 1000U);
  FanControl_Update(399, true);
  assert(FanControl_GetDutyPercent() == 100U);
  FanControl_Update(351, true);
  assert(FanControl_GetDutyPercent() == 100U);
  FanControl_Update(350, true);
  assert(FanControl_GetDutyPercent() == 0U && htim3.compare == 0U);
  FanControl_Update(399, true);
  assert(FanControl_GetDutyPercent() == 0U);
  FanControl_Update(750, true);
  assert(FanControl_GetDutyPercent() == 100U);
  FanControl_Update(250, false);
  assert(FanControl_GetDutyPercent() == 100U);
  FanControl_Update(375, true);
  assert(FanControl_GetDutyPercent() == 100U);
  FanControl_Update(349, true);
  assert(FanControl_GetDutyPercent() == 0U);
  assert(FanControl_Init());
  assert(FanControl_CalculateDuty(375, true) == 0U);
  puts("5.9.3 fan hysteresis PASS");
  return 0;
}
