#include "ina226.h"
#include "power_monitor.h"
#include "i2c.h"
#include "calibration.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define CHECK(x) do { if(!(x)){fprintf(stderr,"FAIL %u: %s\n",__LINE__,#x);exit(1);} }while(0)
I2C_HandleTypeDef hi2c1,hi2c2;
static uint32_t tick,reads;
static uint16_t cfg[2],cal[2],bus[2]={9600,2400};
static int16_t current[2]={500,250};
static bool ready[2]={true,true};
static int fail_reg=-1,fail_device=-1;
static char rate_line[200];
uint32_t HAL_GetTick(void){return tick;}
uint16_t Calibration_ApplyVoltage(uint16_t x){return x;}
int32_t Calibration_ApplyCurrent(int32_t x){return x;}
void DebugConsole_Write(const char *s){if(strncmp(s,"@SAMPLE,",8)==0) snprintf(rate_line,sizeof(rate_line),"%s",s);}
HAL_StatusTypeDef HAL_I2C_IsDeviceReady(I2C_HandleTypeDef *i,uint16_t a,uint32_t n,uint32_t t)
{(void)i;(void)a;(void)n;(void)t;return HAL_OK;}
HAL_StatusTypeDef HAL_I2C_Mem_Write(I2C_HandleTypeDef *i,uint16_t a,uint16_t reg,uint16_t rsize,uint8_t *p,uint16_t n,uint32_t timeout)
{(void)i;(void)rsize;(void)timeout;CHECK(n==2);int d=a==(0x40<<1)?0:1;uint16_t value=(p[0]<<8)|p[1];if(reg==0)cfg[d]=value;else if(reg==5)cal[d]=value;else CHECK(0);return HAL_OK;}
HAL_StatusTypeDef HAL_I2C_Mem_Read(I2C_HandleTypeDef *i,uint16_t a,uint16_t reg,uint16_t rsize,uint8_t *p,uint16_t n,uint32_t timeout)
{
 (void)i;(void)rsize;(void)timeout;CHECK(n==2);int d=a==(0x40<<1)?0:1;reads++;
 if((int)reg==fail_reg && d==fail_device)return HAL_ERROR;
 uint16_t value=0;
 switch(reg){case 0:value=cfg[d];break;case 5:value=cal[d];break;case 0xfe:value=0x5449;break;case 0xff:value=0x2260;break;
 case 6:value=ready[d]?8:0;break;case 2:value=bus[d];break;case 4:value=(uint16_t)current[d];break;
 default:CHECK(0); /* No redundant shunt/power read on the fast path. */}
 p[0]=value>>8;p[1]=value;return HAL_OK;
}
static PowerMonitor_Snapshot_t Snapshot(void){PowerMonitor_Snapshot_t s;PowerMonitor_GetSnapshot(&s);return s;}
int main(void)
{
 CHECK(INA226_CONFIGURATION_VALUE==0x4097);CHECK(PowerMonitor_GetSamplePeriod()==1);
 CHECK(!PowerMonitor_SetSamplePeriod(0));CHECK(!PowerMonitor_SetSamplePeriod(2001));
 CHECK(PowerMonitor_Init());Snapshot();reads=0;
 for(tick=1;tick<=1000;tick++) {
  PowerMonitor_Process(tick);PowerMonitor_Snapshot_t s=Snapshot();
  CHECK(s.sample_sequence==tick && s.last_valid_sample_time_ms==tick && s.data_valid);
  uint32_t before=reads;PowerMonitor_Process(tick);CHECK(reads==before);
 }
 CHECK(reads==6000);CHECK(strstr(rate_line,"period_ms=1,hz=1000,maxgap_ms=1"));
 PowerMonitor_Snapshot_t old=Snapshot();ready[1]=false;
 for(tick=1001;tick<=1010;tick++)PowerMonitor_Process(tick);
 PowerMonitor_Snapshot_t s=Snapshot();CHECK(s.sample_sequence==old.sample_sequence);
 CHECK(s.last_valid_sample_time_ms==old.last_valid_sample_time_ms && s.output_online && s.output_error_count==0);
 ready[1]=true;tick=1011;PowerMonitor_Process(tick);s=Snapshot();CHECK(s.sample_sequence==1001);
 old=s;bus[1]=4000;fail_reg=4;fail_device=1;tick=1012;PowerMonitor_Process(tick);s=Snapshot();
 CHECK(s.sample_sequence==old.sample_sequence && s.output_voltage_raw_mv==old.output_voltage_raw_mv && s.output_error_count==1);
 fail_reg=-1;tick=1013;PowerMonitor_Process(tick);s=Snapshot();CHECK(s.sample_sequence==1002 && s.output_voltage_raw_mv==5000);
 /* Raw path updates at 1ms, display smoothing stays at the original 20ms. */
 old=s;current[1]=500;tick=1014;PowerMonitor_Process(tick);s=Snapshot();
 CHECK(s.output_current_uncalibrated_ua==200000 && s.output_current_ua==old.output_current_ua);
 current[0]=current[1]=-1;tick=1015;PowerMonitor_Process(tick);s=Snapshot();
 CHECK(s.input_current_raw_ua==-200 && s.output_current_uncalibrated_ua==-400);
 CHECK(s.input_power_raw_mw==0 && s.output_power_raw_mw==0);
 /* Wrap and slower configuration must retain genuine freshness semantics. */
 tick=0xfffffffcU;CHECK(PowerMonitor_Init());Snapshot();
 for(unsigned n=0;n<8;n++){tick++;PowerMonitor_Process(tick);s=Snapshot();CHECK(s.sample_sequence==n+1);}
 CHECK(PowerMonitor_SetSamplePeriod(20));old=s;tick+=19;PowerMonitor_Process(tick);CHECK(Snapshot().sample_sequence==old.sample_sequence);
 tick++;PowerMonitor_Process(tick);CHECK(Snapshot().sample_sequence==old.sample_sequence+1);
 puts("PASS: 1ms schedule, 6-register budget, CVRF freshness, signed current/software power, atomic errors, display cadence and tick wrap");
 return 0;
}
