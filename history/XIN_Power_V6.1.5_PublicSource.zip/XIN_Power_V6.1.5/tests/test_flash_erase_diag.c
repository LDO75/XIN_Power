#include "w25q256.h"
#include "spi.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define CHECK(x) do {if(!(x)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x);exit(1);}}while(0)
SPI_HandleTypeDef hspi2;
static unsigned mode; static uint8_t command; static bool erased; static uint32_t tick;
uint32_t HAL_GetTick(void){return tick++;}
void HAL_Delay(uint32_t n){tick+=n;}
void HAL_GPIO_WritePin(GPIO_TypeDef *p,uint16_t pin,GPIO_PinState v){(void)p;(void)pin;(void)v;}
HAL_StatusTypeDef HAL_SPI_Transmit(SPI_HandleTypeDef *h,uint8_t *d,uint16_t n,uint32_t t)
{
 (void)t; command=d[0];
 if((mode==1&&command==0x05)||(mode==3&&command==0x06)||(mode==4&&command==0x21))
 {h->ErrorCode=HAL_SPI_ERROR_FLAG;return HAL_TIMEOUT;}
 if(command==0x21){CHECK(n==5);CHECK(d[1]==1&&d[2]==0xFF&&d[3]==0xE0&&d[4]==0);erased=true;}
 return HAL_OK;
}
HAL_StatusTypeDef HAL_SPI_Receive(SPI_HandleTypeDef *h,uint8_t *d,uint16_t n,uint32_t t)
{
 (void)t;
 if(command==0x9F){CHECK(n==3);d[0]=0xEF;d[1]=0x40;d[2]=0x19;return HAL_OK;}
 CHECK(command==5&&n==1);
 if(mode==5&&erased){h->ErrorCode=HAL_SPI_ERROR_OVR;return HAL_ERROR;}
 d[0]=(mode==2||(mode==6&&erased))?1:0;return HAL_OK;
}
int main(void)
{
 const char *stages[]={"","PRE_WAIT","PRE_WAIT","WREN_TX","ERASE_TX","ERASE_WAIT","ERASE_WAIT"};
 for(mode=1;mode<=6;mode++){
  unsigned chosen=mode;mode=0;tick=0;erased=false;hspi2.ErrorCode=0;CHECK(W25Q256_Init());mode=chosen;
  CHECK(!W25Q256_EraseSector(0x01FFE023));
  const char *d=W25Q256_GetEraseDiagnostic();CHECK(strstr(d,stages[mode]));CHECK(strstr(d,"jedec=EF4019"));
  if(mode==5)CHECK(strstr(d,"hal=00000004"));
  puts(d);
 }
 mode=0;erased=false;CHECK(W25Q256_EraseSector(0x01FFE000));CHECK(!W25Q256_GetEraseDiagnostic()[0]);
 puts("PASS: real Flash driver erase diagnostics, SPI errors, busy timeouts, 4-byte address and successful erase");return 0;
}
