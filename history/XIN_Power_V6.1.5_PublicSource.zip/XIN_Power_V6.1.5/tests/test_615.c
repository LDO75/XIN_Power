/* Short host checks using the REAL calibration and output-control sources.
 * Fake measurements do not verify physical overshoot or load regulation. */
#include "power_control.h"
#include "calibration.h"
#include "w25q256.h"
#include "i2c.h"
#include "usart.h"
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#define CHECK(c) do { if (!(c)) { fprintf(stderr,"FAIL %u: %s\n",(unsigned)__LINE__,#c); exit(1); } } while(0)
#define BASE 0x01FFE000UL
I2C_HandleTypeDef hi2c1, hi2c2;
UART_HandleTypeDef husart1, husart2;
static uint8_t flash[8192];
static uint32_t tick;
static uint16_t dac;
static GPIO_PinState ce;
static unsigned writes;
static uint32_t sample_period=20;
uint32_t PowerMonitor_GetSamplePeriod(void) { return sample_period; }
static bool fail_dac, fail_commit;
static unsigned fail_stage;
bool W25Q256_Init(void) { return true; }
bool W25Q256_IsReady(void) { return true; }
bool W25Q256_Read(uint32_t a, void *p, uint32_t n)
{ CHECK(a>=BASE && a+n<=BASE+sizeof(flash)); if ((fail_stage==3 && (a-BASE)%4096==256) || (fail_stage==6 && (a-BASE)%4096==0)) return false; memcpy(p,flash+a-BASE,n); if ((fail_stage==4 && (a-BASE)%4096==256) || (fail_stage==7 && (a-BASE)%4096==0)) ((uint8_t *)p)[0]^=1; return true; }
bool W25Q256_EraseSector(uint32_t a)
{ CHECK(a>=BASE && a<BASE+sizeof(flash)); if (fail_stage==1) return false; memset(flash+((a-BASE)&~4095UL),255,4096); return true; }
bool W25Q256_Write(uint32_t a, const void *p, uint32_t n)
{
  CHECK(a>=BASE && a+n<=BASE+sizeof(flash));
  if ((fail_commit || fail_stage==5) && ((a-BASE)%4096==0)) { return false; }
  if (fail_stage==2 && ((a-BASE)%4096==256)) return false;
  const uint8_t *q=p; for(uint32_t i=0;i<n;i++) { flash[a-BASE+i]&=q[i]; } return true;
}
uint32_t HAL_GetTick(void) { return tick; }
void HAL_GPIO_WritePin(GPIO_TypeDef *p, uint16_t pin, GPIO_PinState value)
{ (void)p; (void)pin; ce=value; }
HAL_StatusTypeDef HAL_I2C_IsDeviceReady(I2C_HandleTypeDef *i,uint16_t a,uint32_t n,uint32_t t)
{ (void)i; (void)a; (void)n; (void)t; return HAL_OK; }
HAL_StatusTypeDef HAL_I2C_Master_Transmit(I2C_HandleTypeDef *i,uint16_t a,uint8_t *b,uint16_t n,uint32_t t)
{ (void)i; (void)a; (void)t; CHECK(n==3); if(fail_dac) return HAL_ERROR;
  dac=((uint16_t)b[1]<<4)|(b[2]>>4); writes++; return HAL_OK; }
GPIO_PinState HAL_GPIO_ReadPin(GPIO_TypeDef *p, uint16_t pin)
{ (void)p; (void)pin; return ce; }
void DebugConsole_Write(const char *p) { if(strstr(p,"[FAULT]")) CHECK(ce==GPIO_PIN_SET); }
static Calibration_Data_t Data(void) { Calibration_Data_t d; Calibration_Get(&d); return d; }
static PowerControl_Status_t Status(void) { PowerControl_Status_t s; PowerControl_GetStatus(&s); return s; }
static void Curves(void)
{
  memset(flash,255,sizeof(flash)); Calibration_Init(); CHECK(!Data().loaded_from_flash);
  CHECK(Calibration_SetVoltage(999800,3)); CHECK(Calibration_SetCurrent(1002915,407));
  CHECK(Calibration_SetDac(4637,2937,19251,1377)); CHECK(Calibration_Save());
  /* Read the unchanged legacy record with an erased extension. */
  memset(flash+256,255,256); Calibration_Init(); CHECK(Data().dac_valid && Data().point_mask==0);
  CHECK(Data().voltage_gain_ppm==999800 && Data().current_offset_ua==407);
  CHECK(Calibration_SavePoint(0,2995,3065)); CHECK(Calibration_SavePoint(1,3295,3034));
  Calibration_Init(); CHECK(Data().point_mask==3);
  uint16_t code; CHECK(Calibration_MapDac(2995,&code) && code==3065);
  CHECK(Calibration_MapDac(3295,&code) && code==3034);
  CHECK(Calibration_MapDac(3145,&code) && code==3049); /* nearest-code tie */
  CHECK(Calibration_SavePoint(1,3295,3066)); CHECK(Data().points[1].dac_code==3066);
  CHECK(Calibration_SavePoint(1,3295,3034));
  CHECK(!Calibration_SavePoint(1,2995,3034)); CHECK(strcmp(Calibration_GetSaveError(),"POINT_ORDER_OR_VALUE")==0); /* duplicate voltage is not an interval */
  CHECK(Calibration_SavePoint(12,3500,3000)); CHECK(Calibration_SavePoint(2,5100,2800));
  CHECK(Calibration_SavePoint(2,4995,2898));
  /* Reset the two added records for the commit/CRC test below. */
  memset(flash,255,sizeof(flash)); Calibration_Init();
  CHECK(Calibration_SetVoltage(999800,3)); CHECK(Calibration_SetCurrent(1002915,407));
  CHECK(Calibration_SetDac(4637,2937,19251,1377)); CHECK(Calibration_Save());
  CHECK(Calibration_SavePoint(0,2995,3065)); CHECK(Calibration_SavePoint(1,3295,3034));
  fail_commit=true; CHECK(!Calibration_SavePoint(2,4995,2898)); CHECK(strcmp(Calibration_GetSaveError(),"FLASH_RECORD_WRITE_FAILED")==0); fail_commit=false;
  CHECK(Data().point_mask==3); Calibration_Init(); CHECK(Data().point_mask==3);
  CHECK(Calibration_SavePoint(2,4995,2898)); CHECK(Data().point_mask==7);
  /* seq4/current slot1: corrupt its curve CRC and fall back to seq3/slot0. */
  flash[4096+256+20]^=1; Calibration_Init(); CHECK(Data().point_mask==3);
  const uint16_t codes[]={3065,3034,2898,2660,2532,2468,2148,1508,1294,868,441,14,3002,2980,2970,2930};
  for(unsigned i=0;i<16;i++) CHECK(Calibration_SavePoint(i,Calibration_PointTarget(i)-5,codes[i]));
  Calibration_Init(); CHECK(Data().point_mask==65535 && Data().loaded_from_flash);
  for(unsigned i=0;i<16;i++) CHECK(Calibration_MapDac(Calibration_PointTarget(i)-5,&code)&&code==codes[i]);
  uint16_t previous=4095;
  for(unsigned mv=3000;mv<=32000;mv++)
  { CHECK(Calibration_MapDac(mv,&code)); CHECK(code<=previous); previous=code; }
  /* Positive measurement quantum must not cause a preset-boundary jump. */
  CHECK(Calibration_SavePoint(1,3310,3034)); previous=4095;
  for(unsigned mv=3000;mv<=5000;mv++)
  { CHECK(Calibration_MapDac(mv,&code)); CHECK(code<=previous); previous=code; }
  CHECK(Calibration_SavePoint(1,3295,3034));
  CHECK(Data().voltage_gain_ppm==999800 && Data().current_offset_ua==407);
  puts("PASS: 16 points, full-span monotonic interpolation, failed commit, CRC fallback");
}
static void Init(PowerControl_Request_t *r,PowerMonitor_Snapshot_t *m,uint16_t target,uint32_t now)
{
  memset(r,0,sizeof(*r)); memset(m,0,sizeof(*m)); tick=now; sample_period=20; ce=GPIO_PIN_SET; dac=0; writes=0; fail_dac=false;
  r->voltage_setpoint_mv=target; r->current_limit_ma=1500; r->temperature_valid=true; r->temperature_decic=300;
  m->input_online=m->output_online=m->data_valid=true; m->input_voltage_raw_mv=27882;
  m->sample_sequence=1; m->last_valid_sample_time_ms=tick;
  CHECK(PowerControl_Init()); PowerControl_Process(tick,r,m);
}
static void Fresh(PowerControl_Request_t *r,PowerMonitor_Snapshot_t *m,uint32_t now,uint16_t actual)
{ tick=now; m->last_valid_sample_time_ms=tick; m->sample_sequence++;
  m->output_voltage_raw_mv=m->output_voltage_uncalibrated_mv=actual; PowerControl_Process(tick,r,m); }
static void Run(PowerControl_Request_t *r,PowerMonitor_Snapshot_t *m,uint16_t actual,unsigned length)
{ uint32_t origin=tick; for(unsigned dt=20;dt<=length;dt+=20) Fresh(r,m,origin+dt,actual); }
static uint32_t Crc(const uint8_t *bytes,unsigned n)
{
  uint32_t crc=UINT32_MAX;
  for(unsigned i=0;i<n;i++) { crc^=bytes[i]; for(unsigned j=0;j<8;j++) crc=(crc>>1)^((crc&1)?0xEDB88320UL:0); }
  return ~crc;
}
static void Migration(void)
{
  /* Turn the two valid new records into pre-resistor-change records. */
  for(unsigned slot=0;slot<2;slot++) {
    uint8_t *record=flash+slot*4096;
    record[38]=record[39]=0; memset(record+40,0,4);
    uint32_t crc=Crc(record,44); memcpy(record+40,&crc,4);
    uint8_t *curve=record+256; curve[4]=2;curve[5]=0;
  }
  Calibration_Init(); CHECK(Data().loaded_from_flash);
  CHECK(Data().voltage_gain_ppm==999800 && Data().current_offset_ua==407);
  CHECK(Data().voltage_valid && Data().current_valid);
  CHECK(Data().point_mask==0 && !Data().dac_valid);
  CHECK(Calibration_SavePoint(0,3000,2659));
  CHECK(Calibration_SavePoint(1,3300,2638));
  Calibration_Init(); CHECK(Data().point_mask==3);
  CHECK(Data().points[0].dac_code==2659 && Data().points[1].dac_code==2638);
  CHECK(Data().voltage_gain_ppm==999800 && Data().current_offset_ua==407);
  /* Another boot must keep only the new-resistor points. */
  Calibration_Init();CHECK(Data().point_mask==3);
  puts("PASS: old DAC curves invalidated, ADC calibration retained, new hardware points persist");
}
static void NewResistorFormula(void)
{
  Calibration_ResetDefaults();
  unsigned previous=4095;
  for(unsigned target=2000;target<=32000;target++) {
    unsigned code=PowerControl_VoltageToDacCode(target);
    double buf=3.0*code/4096.0;
    double voltage=1.22*(1+100000.0/7620+100000.0/5110)-100000.0/5110*buf;
    CHECK(code<=previous && fabs(voltage*1000-target)<7.18);previous=code;
  }
  CHECK(PowerControl_VoltageToDacCode(0)==2728 && PowerControl_VoltageToDacCode(65535)==635);
  puts("PASS: independent KCL 2..32V sweep, <7.18mV quantization/arithmetic error, 5.11k injection and 4096 DAC scale");
}

static void Overcurrent(void)
{
  PowerControl_Request_t r; PowerMonitor_Snapshot_t m;
  Init(&r,&m,5000,0); r.output_requested=true;
  m.output_current_raw_ua=m.output_current_uncalibrated_ua=1500000;
  Fresh(&r,&m,2,5000); CHECK(ce==GPIO_PIN_RESET);
  m.output_current_raw_ua=m.output_current_uncalibrated_ua=1500001;
  Fresh(&r,&m,3,5000); CHECK(ce==GPIO_PIN_SET && dac==0);
  CHECK(Status().fault==POWER_CONTROL_FAULT_OUTPUT_OVERCURRENT && !Status().constant_current);
  CHECK(strstr(PowerControl_GetFaultContext(),"reason=IOUT_OC")!=NULL);
  m.output_current_raw_ua=m.output_current_uncalibrated_ua=0;
  Fresh(&r,&m,4,0); CHECK(ce==GPIO_PIN_SET); /* latched */
  CHECK(PowerControl_ClearFault()); CHECK(ce==GPIO_PIN_SET);
  r.output_requested=false; Fresh(&r,&m,5,0); CHECK(Status().fault==POWER_CONTROL_FAULT_NONE);
  Init(&r,&m,5000,0); r.output_requested=true; m.input_current_raw_ua=4800001;
  Fresh(&r,&m,2,5000); CHECK(Status().fault==POWER_CONTROL_FAULT_INPUT_OVERCURRENT && ce==GPIO_PIN_SET);
  Init(&r,&m,5000,0); r.output_requested=true; r.current_limit_ma=8000;
  m.output_current_raw_ua=0; m.output_current_uncalibrated_ua=8000001;
  Fresh(&r,&m,2,5000); CHECK(Status().fault==POWER_CONTROL_FAULT_OUTPUT_OVERCURRENT);
  Init(&r,&m,3600,UINT32_MAX-100); r.output_requested=true;
  CHECK(PowerControl_BeginDacCalibration(3600)); Fresh(&r,&m,UINT32_MAX-98,3002);
  CHECK(PowerControl_StepDacCalibration(-5,&m)); Run(&r,&m,2975,12000);
  CHECK(ce==GPIO_PIN_RESET && PowerControl_DacCalibrationReady(&m));
  m.output_current_uncalibrated_ua=1500001; Fresh(&r,&m,tick+1,2975);
  CHECK(ce==GPIO_PIN_SET && !PowerControl_IsDacCalibrationActive());
  puts("PASS: IIN/IOUT overcurrent, setting boundary, raw/corrected current, fault latch, calibration OCP and tick wrap");
}
static void DacBounds(void)
{
  Calibration_ResetDefaults(); CHECK(Calibration_SetDac(3000,4095,32000,0));
  CHECK(Calibration_SavePoint(0,3000,4095)); CHECK(Calibration_SavePoint(11,32000,0));
  uint16_t code; CHECK(Calibration_MapDac(32000,&code) && code==0);
  PowerControl_Request_t r; PowerMonitor_Snapshot_t m; Init(&r,&m,32000,0);
  CHECK(PowerControl_BeginDacCalibration(32000)); r.output_requested=true;
  Fresh(&r,&m,2,32000); CHECK(dac==0 && ce==GPIO_PIN_RESET);
  CHECK(PowerControl_DacCalibrationReady(&m)); CHECK(!PowerControl_StepDacCalibration(-1,&m));
  CHECK(PowerControl_StepDacCalibration(5,&m) && dac==5); PowerControl_EndDacCalibration();
  Init(&r,&m,3000,0); CHECK(PowerControl_BeginDacCalibration(3000));
  r.output_requested=true; Fresh(&r,&m,2,3000); CHECK(dac==4095);
  CHECK(!PowerControl_StepDacCalibration(1,&m)); CHECK(PowerControl_StepDacCalibration(-5,&m));
  PowerControl_EndDacCalibration(); CHECK(ce==GPIO_PIN_SET && dac==0);
  puts("PASS: full 12-bit DAC including 0/4095; only numeric bounds reject a step");
}

static void User3600Capture(void)
{
  /* Exact 15 stored pairs and new capture from the 19:14-19:16 user log. */
  const uint16_t mv[16]={2998,3298,5003,7209,8405,8999,11999,17998,
    20002,23997,27998,31996,0,3904,3993,4505};
  const uint16_t codes[16]={3068,3038,2905,2668,2541,2478,2157,1516,
    1300,873,441,13,0,3021,3011,2955};
  memset(flash,255,sizeof(flash)); Calibration_Init();
  CHECK(Calibration_SetVoltage(999800,3)); CHECK(Calibration_SetCurrent(1002915,407));
  for(unsigned i=0;i<16;i++) if(i!=12) CHECK(Calibration_SavePoint(i,mv[i],codes[i]));
  Calibration_Data_t before=Data(); CHECK(before.point_mask==61439);
  CHECK(Calibration_SavePoint(12,3597,3052));
  Calibration_Init(); Calibration_Data_t after=Data();
  CHECK(after.point_mask==65535 && after.points[12].actual_mv==3597 && after.points[12].dac_code==3052);
  for(unsigned i=0;i<16;i++) if(i!=12) CHECK(memcmp(&after.points[i],&before.points[i],sizeof(after.points[i]))==0);
  CHECK(after.voltage_gain_ppm==999800 && after.current_offset_ua==407);
  uint16_t code;
  CHECK(Calibration_MapDac(3298,&code) && code==3038);
  CHECK(Calibration_MapDac(3447,&code) && code==3045); /* positive DAC slope */
  CHECK(Calibration_MapDac(3597,&code) && code==3052);
  CHECK(Calibration_MapDac(3750,&code) && code==3037); /* negative DAC slope */
  CHECK(Calibration_MapDac(3904,&code) && code==3021);
  CHECK(Calibration_SavePoint(12,3597,3038)); /* a flat DAC segment is representable */
  CHECK(Calibration_MapDac(3447,&code) && code==3038);
  CHECK(Calibration_SavePoint(12,3597,3052));
  puts("PASS: user 3597mV/DAC3052 saves and reloads, all other points unchanged; positive/negative/flat interval slopes");
}

static void SaveDiagnostics(void)
{
  const char *errors[]={"NONE","FLASH_ERASE_FAILED","FLASH_CURVE_WRITE_FAILED",
    "FLASH_CURVE_READ_FAILED","FLASH_CURVE_READBACK_MISMATCH",
    "FLASH_RECORD_WRITE_FAILED","FLASH_RECORD_READ_FAILED","FLASH_RECORD_READBACK_MISMATCH"};
  for (unsigned stage=1;stage<=7;stage++) {
    fail_stage=0; memset(flash,255,sizeof(flash)); Calibration_Init();
    CHECK(Calibration_SavePoint(0,3000,2659));
    fail_stage=stage; CHECK(!Calibration_SavePoint(13,3898,2563));
    CHECK(strcmp(Calibration_GetSaveError(),errors[stage])==0);
    CHECK(Data().point_mask==1); fail_stage=0; Calibration_Init();
    CHECK(Data().point_mask==(stage<=5 ? 1U : (1U|(1U<<13)))); /* final verification can fail after a complete physical commit */
    CHECK(Calibration_SavePoint(13,3898,2563));
    CHECK(strcmp(Calibration_GetSaveError(),"NONE")==0);
    Calibration_Init(); CHECK(Data().point_mask==(1U|(1U<<13)));
  }
  puts("PASS: 7 injected Flash failure stages, exact diagnosis, rollback, retry and reboot");
}

static void UserPatchedHardware(void)
{
  const uint16_t mv[16]={3008,3297,5001,7199,8401,9002,11998,17995,
    20003,23997,27998,31994,3598,3899,4006,4502};
  const uint16_t codes[16]={3113,3080,2900,2662,2535,2471,2150,1511,
    1295,869,443,12,3048,3017,3006,2953};
  memset(flash,255,sizeof(flash)); Calibration_Init();
  for(unsigned i=0;i<16;i++) CHECK(Calibration_SavePoint(i,mv[i],codes[i]));
  Calibration_Init(); CHECK(Data().point_mask==65535);
  for(unsigned i=0;i<16;i++) {
    uint16_t code; CHECK(Calibration_MapDac(mv[i],&code) && code==codes[i]);
  }
  const unsigned order[16]={0,1,12,13,14,15,2,3,4,5,6,7,8,9,10,11};
  for(unsigned j=0;j<15;j++) {
    unsigned a=order[j], b=order[j+1];
    for(unsigned v=mv[a];v<=mv[b];v++) {
      uint16_t code; CHECK(Calibration_MapDac(v,&code));
      double exact=codes[a]+((double)v-mv[a])*(codes[b]- (double)codes[a])/(mv[b]-mv[a]);
      CHECK(fabs(code-exact)<=0.5000001);
    }
  }
  PowerControl_Request_t r; PowerMonitor_Snapshot_t m;
  Init(&r,&m,3200,0); r.output_requested=true; Fresh(&r,&m,1,3200);
  unsigned before=writes; CHECK(!Status().ce_gpio_high);
  for(unsigned i=0;i<200;i++) Fresh(&r,&m,tick+20,3130+i%127);
  CHECK(writes==before && Status().dac_write_count==writes);
  r.output_requested=false; Fresh(&r,&m,tick+1,300);
  CHECK(Status().ce_gpio_high && dac==0);
  before=writes;
  for(unsigned i=0;i<200;i++) Fresh(&r,&m,tick+20,i%537);
  CHECK(writes==before && Status().ce_gpio_high);
  CHECK(Status().fault==POWER_CONTROL_FAULT_NONE);
  puts("PASS: actual patched-hardware 16 points persist; nearest-code sweep; fixed DAC under ripple; OFF has no periodic DAC/CE pulse");
}

static void ExpectFault(PowerControl_Fault_t fault)
{
  CHECK(Status().fault==fault && ce==GPIO_PIN_SET && !Status().output_enabled && dac==0);
  CHECK(strstr(PowerControl_GetFaultContext(), PowerControl_GetFaultName(fault)));
}
static void Protections(void)
{
  PowerControl_Request_t r; PowerMonitor_Snapshot_t m;
  Init(&r,&m,2000,0); r.output_requested=true; Fresh(&r,&m,1,2000);
  unsigned before=writes; Run(&r,&m,2000,2000);
  CHECK(Status().fault==0 && writes==before); /* fixed DAC at valid 2V */
  r.output_requested=false; m.input_voltage_raw_mv=0; r.temperature_decic=1000;
  Run(&r,&m,200,2000); CHECK(Status().fault==0 && ce==GPIO_PIN_SET);

  Init(&r,&m,2000,0); r.output_requested=true; Fresh(&r,&m,1,2000);
  m.input_voltage_raw_mv=3999; Fresh(&r,&m,20,2000); Fresh(&r,&m,219,2000);
  CHECK(Status().fault==0); Fresh(&r,&m,220,2000); ExpectFault(POWER_CONTROL_FAULT_INPUT_UNDERVOLTAGE);
  m.input_voltage_raw_mv=28000; Fresh(&r,&m,240,2000); ExpectFault(POWER_CONTROL_FAULT_INPUT_UNDERVOLTAGE);
  CHECK(PowerControl_ClearFault()); r.output_requested=false; Fresh(&r,&m,260,0); CHECK(Status().fault==0 && ce==GPIO_PIN_SET);

  Init(&r,&m,2000,0); r.output_requested=true; m.input_voltage_raw_mv=3999;
  Fresh(&r,&m,1,2000); m.input_voltage_raw_mv=4000; Fresh(&r,&m,200,2000);
  m.input_voltage_raw_mv=3999; Fresh(&r,&m,210,2000); Fresh(&r,&m,409,2000); CHECK(Status().fault==0);
  Fresh(&r,&m,410,2000); ExpectFault(POWER_CONTROL_FAULT_INPUT_UNDERVOLTAGE);

  Init(&r,&m,2000,0); r.output_requested=true; Fresh(&r,&m,1,2300);
  Run(&r,&m,2300,200); CHECK(Status().fault==0); /* max(300mV,10%) boundary */
  Fresh(&r,&m,220,2301); Fresh(&r,&m,319,2301); CHECK(Status().fault==0);
  Fresh(&r,&m,320,2301); ExpectFault(POWER_CONTROL_FAULT_OUTPUT_OVERVOLTAGE);

  Init(&r,&m,32000,0); r.output_requested=true; Fresh(&r,&m,1,32000);
  r.voltage_setpoint_mv=2000; Fresh(&r,&m,20,32000);
  Run(&r,&m,28000,400); Run(&r,&m,20000,400); Run(&r,&m,2000,400);
  CHECK(Status().fault==0 && dac==PowerControl_VoltageToDacCode(2000));
  Run(&r,&m,2500,120); ExpectFault(POWER_CONTROL_FAULT_OUTPUT_OVERVOLTAGE);

  Init(&r,&m,2000,0); r.output_requested=true; Fresh(&r,&m,1,2000);
  CHECK(PowerControl_BeginDacCalibration(2000)); Fresh(&r,&m,2,2000);
  CHECK(PowerControl_StepDacCalibration(-5,&m)); before=writes;
  Run(&r,&m,5000,2000); CHECK(Status().fault==0 && writes==before && PowerControl_DacCalibrationReady(&m));
  Fresh(&r,&m,tick+20,33000); CHECK(Status().fault==0);
  Fresh(&r,&m,tick+20,33001); ExpectFault(POWER_CONTROL_FAULT_OUTPUT_OVERVOLTAGE);
  CHECK(!PowerControl_IsDacCalibrationActive() && !PowerControl_StepDacCalibration(-1,&m));

  Init(&r,&m,2000,0); r.output_requested=true; r.temperature_decic=799;
  Fresh(&r,&m,1,2000); CHECK(Status().fault==0); r.temperature_decic=800;
  PowerControl_Process(2,&r,NULL); ExpectFault(POWER_CONTROL_FAULT_OVERTEMPERATURE);

  /* Low voltage, including 0V, never starts an independent short timer. */
  Init(&r,&m,2000,0); r.output_requested=true; Fresh(&r,&m,1,0);
  Run(&r,&m,0,2000); CHECK(Status().fault==0);

  Init(&r,&m,2000,0); r.output_requested=true; Fresh(&r,&m,1,2000);
  PowerControl_Process(500,&r,&m); CHECK(Status().fault==0);
  PowerControl_Process(501,&r,&m); ExpectFault(POWER_CONTROL_FAULT_MONITOR_OFFLINE); /* frozen valid frame */
  Init(&r,&m,2000,0); r.output_requested=true; Fresh(&r,&m,1,2000);
  PowerControl_Process(500,&r,NULL); CHECK(Status().fault==0);
  PowerControl_Process(501,&r,NULL); ExpectFault(POWER_CONTROL_FAULT_MONITOR_OFFLINE);
  CHECK(strstr(PowerControl_GetFaultContext(), "valid=0"));
  Init(&r,&m,2000,0); r.output_requested=true; Fresh(&r,&m,1,2000);
  /* A new valid conversion clears missing-frame qualification at its boundary. */
  Fresh(&r,&m,501,2000); CHECK(Status().fault==0);
  m.output_online=false; PowerControl_Process(1000,&r,&m); CHECK(Status().fault==0);
  PowerControl_Process(1001,&r,&m); ExpectFault(POWER_CONTROL_FAULT_MONITOR_OFFLINE);
  /* Old samples cannot be made recent merely by reading them after OUT ON. */
  Init(&r,&m,2000,0);r.output_requested=true; tick=400;
  m.output_voltage_raw_mv=2000;PowerControl_Process(400,&r,&m);
  PowerControl_Process(499,&r,&m); CHECK(Status().fault==0);
  PowerControl_Process(500,&r,&m); ExpectFault(POWER_CONTROL_FAULT_MONITOR_OFFLINE);
  /* Disconnected voltage observations do not qualify as continuous UV. */
  Init(&r,&m,2000,0);r.output_requested=true;m.input_voltage_raw_mv=3999;
  Fresh(&r,&m,1,2000);m.data_valid=false;PowerControl_Process(190,&r,&m);
  m.data_valid=true;Fresh(&r,&m,210,2000);Fresh(&r,&m,409,2000);CHECK(Status().fault==0);
  Fresh(&r,&m,410,2000);ExpectFault(POWER_CONTROL_FAULT_INPUT_UNDERVOLTAGE);
  Init(&r,&m,2000,0); r.output_requested=true; Fresh(&r,&m,1,2000);
  sample_period=2000; Fresh(&r,&m,2001,2000); Fresh(&r,&m,4001,2000); CHECK(Status().fault==0);
  m.data_valid=false; PowerControl_Process(10000,&r,&m); CHECK(Status().fault==0);
  PowerControl_Process(10001,&r,&m); ExpectFault(POWER_CONTROL_FAULT_MONITOR_OFFLINE);

  Init(&r,&m,2000,UINT32_MAX-100); r.output_requested=true; m.input_voltage_raw_mv=3999;
  Fresh(&r,&m,UINT32_MAX-99,2000); Fresh(&r,&m,99,2000); CHECK(Status().fault==0);
  Fresh(&r,&m,100,2000); ExpectFault(POWER_CONTROL_FAULT_INPUT_UNDERVOLTAGE);
  puts("PASS: current-based short shutdown and other basic protections, thresholds/delays, latch, manual calibration, 32->2V discharge, 2V normal, OFF residual, stalled/missing frames, adaptive sampling and tick wrap");
}

static void Legacy16Migration(void)
{
  UserPatchedHardware(); Calibration_Data_t before=Data();
  typedef struct { uint32_t magic; uint16_t schema,size; uint32_t sequence; uint16_t mask,tag; Calibration_Point_t points[16]; uint32_t crc; } OldCurve;
  CHECK(sizeof(OldCurve)==84);
  for(unsigned slot=0;slot<2;slot++) {
    uint8_t *rec=flash+slot*4096; uint16_t tag=0x4991;
    memcpy(rec+38,&tag,2); memset(rec+40,0,4); uint32_t crc=Crc(rec,44); memcpy(rec+40,&crc,4);
    OldCurve curve={0}; curve.magic=0x58435552; curve.schema=3; curve.size=sizeof(curve);
    memcpy(&curve.sequence,rec+8,4); curve.mask=65535;curve.tag=0x4991;
    memcpy(curve.points,before.points,sizeof(curve.points));curve.crc=Crc((uint8_t*)&curve,sizeof(curve));
    memset(rec+256,255,128);memcpy(rec+256,&curve,sizeof(curve));
  }
  Calibration_Init(); CHECK(Data().point_mask==65535);
  CHECK(memcmp(Data().points,before.points,sizeof(OldCurve)-20)==0);
  uint8_t old_flash[8192];memcpy(old_flash,flash,sizeof(flash));
  CHECK(Calibration_SavePoint(16,1998,3220));Calibration_Init();CHECK(Data().point_mask==131071);
  Calibration_Data_t after=Data();CHECK(memcmp(after.points,before.points,16*sizeof(Calibration_Point_t))==0);
  uint16_t code;CHECK(Calibration_MapDac(1998,&code) && code==3220);
  memcpy(flash,old_flash,sizeof(flash)); Calibration_Init(); fail_commit=true;
  CHECK(!Calibration_SavePoint(16,1998,3220)); fail_commit=false;Calibration_Init();CHECK(Data().point_mask==65535);
  CHECK(Calibration_SavePoint(16,1998,3220));Calibration_Init();CHECK(Data().point_mask==131071);
  puts("PASS: exact same-profile schema-3 16-point migration, 17th point bit, original point IDs/data retained, failed first schema-4 commit fallback");
}

static void UserShortRegression(void)
{
  UserPatchedHardware();
  PowerControl_Request_t r;PowerMonitor_Snapshot_t m;
  Init(&r,&m,2000,0);r.current_limit_ma=100;r.temperature_decic=283;
  m.input_voltage_raw_mv=27906;m.output_current_uncalibrated_ua=-400;
  CHECK(PowerControl_BeginDacCalibration(2000));r.output_requested=true;
  Fresh(&r,&m,1,360);CHECK(dac==3228);
  unsigned before=writes;Run(&r,&m,173,2000);
  CHECK(Status().fault==0 && writes==before && PowerControl_DacCalibrationReady(&m));
  CHECK(PowerControl_StepDacCalibration(-1,&m) && dac==3227);
  /* Remove 6.1.2's arbitrary 50mA rule: every current through the limit
   * stays on even with persistent 0..499mV output. */
  const int32_t currents[]={0,49999,50000,75000,99999,100000};
  for(unsigned i=0;i<sizeof(currents)/sizeof(*currents);i++) {
    m.output_current_raw_ua=m.output_current_uncalibrated_ua=currents[i];
    for(unsigned j=0;j<100;j++) {
      Fresh(&r,&m,tick+20,(uint16_t)(j%2 ? 0 : 499));CHECK(Status().fault==0);
    }
  }
  m.output_current_uncalibrated_ua=100001;Fresh(&r,&m,tick+1,173);
  ExpectFault(POWER_CONTROL_FAULT_OUTPUT_OVERCURRENT);
  /* First over-limit sample immediately trips during startup as well. */
  Init(&r,&m,2000,0);r.output_requested=true;r.current_limit_ma=100;
  Fresh(&r,&m,1,173);m.output_current_raw_ua=5000000;
  Fresh(&r,&m,2,0);ExpectFault(POWER_CONTROL_FAULT_OUTPUT_OVERCURRENT);
  CHECK(strstr(PowerControl_GetFaultContext(),"t=2,"));
  Init(&r,&m,2000,0);r.output_requested=true;Fresh(&r,&m,1,173);
  m.input_current_raw_ua=4800001;Fresh(&r,&m,2,0);
  ExpectFault(POWER_CONTROL_FAULT_INPUT_OVERCURRENT);
  puts("PASS: empty-load user trace, no low-voltage/50mA short fault, inclusive current boundary, first-sample short overcurrent shutdown without startup delay");
}

static void BackgroundProtection(void)
{
  PowerControl_Request_t r;PowerMonitor_Snapshot_t m;
  Init(&r,&m,3000,0);sample_period=1;
  unsigned before=writes;
  m.output_current_raw_ua=5000000;
  PowerControl_ServiceProtections(tick,&r,&m);
  CHECK(writes==before && !Status().output_enabled && Status().fault==0);
  m.output_current_raw_ua=0;r.output_requested=true;r.current_limit_ma=100;
  Fresh(&r,&m,1,3000);before=writes;
  for(unsigned t=2;t<100;t++) {
    tick=t;m.sample_sequence++;m.last_valid_sample_time_ms=t;
    PowerControl_ServiceProtections(t,&r,&m);
    CHECK(Status().fault==0 && writes==before);
  }
  tick=100;m.sample_sequence++;m.last_valid_sample_time_ms=tick;
  m.output_current_raw_ua=100001;
  PowerControl_ServiceProtections(tick,&r,&m);
  ExpectFault(POWER_CONTROL_FAULT_OUTPUT_OVERCURRENT);
  CHECK(strstr(PowerControl_GetFaultContext(),"t=100,"));
  CHECK(PowerControl_ClearFault());before=writes;
  PowerControl_ServiceProtections(101,&r,&m);
  CHECK(writes==before && !Status().output_enabled && Status().fault==0);
  sample_period=20;
  puts("PASS: 1ms foreground protection hook trips first over-limit frame; OFF/clear stays OFF; normal hook never changes DAC");
}

static void ResistorProfileMigration(void)
{
  for(unsigned pass=0;pass<2;pass++) {
    memset(flash,255,sizeof(flash));Calibration_Init();
    CHECK(Calibration_SetVoltage(999800,3));CHECK(Calibration_SetCurrent(1002915,407));
    CHECK(Calibration_SetDac(3008,3113,31994,12));
    CHECK(Calibration_SavePoint(0,3008,3113));CHECK(Calibration_SavePoint(11,31994,12));
    /* Convert valid stored records to either historically ambiguous profile. */
    for(unsigned slot=0;slot<2;slot++) {
      uint8_t *rec=flash+slot*4096;uint16_t tag=pass?5110:7620;
      memcpy(rec+38,&tag,2);memset(rec+40,0,4);uint32_t crc=Crc(rec,44);memcpy(rec+40,&crc,4);
    }
    uint8_t saved[8192];memcpy(saved,flash,sizeof(flash));
    Calibration_Init();CHECK(Data().loaded_from_flash && Data().voltage_valid && Data().current_valid);
    CHECK(Data().voltage_gain_ppm==999800 && Data().current_offset_ua==407);
    CHECK(!Data().dac_valid && Data().point_mask==0);
    CHECK(memcmp(saved,flash,sizeof(flash))==0); /* no destructive reset on boot */
    CHECK(PowerControl_VoltageToDacCode(2000)==2728);
    CHECK(PowerControl_VoltageToDacCode(3000)==2659);
    CHECK(PowerControl_VoltageToDacCode(32000)==635);
    PowerControl_Request_t r;PowerMonitor_Snapshot_t m;Init(&r,&m,3000,0);
    r.output_requested=true;Fresh(&r,&m,1,3000);CHECK(dac==2659 && ce==GPIO_PIN_RESET);
    r.output_requested=false;Fresh(&r,&m,2,3000);CHECK(dac==0 && ce==GPIO_PIN_SET);
    CHECK(Calibration_SavePoint(16,2000,2728));Calibration_Init();
    CHECK(Data().point_mask==(1U<<16) && Data().points[16].dac_code==2728);
    CHECK(Data().voltage_gain_ppm==999800 && Data().current_offset_ua==407);
  }
  puts("PASS: reject 7620/ambiguous5110 DAC curves, retain ADC coefficients/flash, matched 2/3/32V startup codes, OFF still gates before DAC0, new profile persists");
}

int main(void) { ResistorProfileMigration(); UserShortRegression(); BackgroundProtection(); SaveDiagnostics(); Curves(); Migration(); NewResistorFormula(); Protections(); Overcurrent(); DacBounds(); User3600Capture(); Legacy16Migration(); puts("V6.1.5 host checks passed (not hardware tests)."); return 0; }
