"""Short protocol/Qt checks, no serial port or physical device opened."""
from pathlib import Path
import sys
import unittest
from unittest.mock import Mock
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from PySide6.QtCore import QEventLoop, QTimer, QUrl, QObject
from PySide6.QtQml import QQmlApplicationEngine
from PySide6.QtQuickControls2 import QQuickStyle
from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QFontDatabase, QFont
from dac_calibration import CurveCalibration, TARGETS_MV, meter_millivolts
from protocol import parse_line, voltage_command
from xin_power_qt import Bridge

QQuickStyle.setStyle("Basic")
APP = QApplication.instance() or QApplication([])
for filename in ("msyh.ttc", "segoeui.ttf", "consola.ttf"):
    QFontDatabase.addApplicationFont(f"C:/Windows/Fonts/{filename}")
APP.setFont(QFont("Microsoft YaHei"))


class CurveTests(unittest.TestCase):
    def setUp(self):
        self.sent = []
        self.curve = CurveCalibration(self.sent.append, lambda: True)

    def tearDown(self):
        self.curve._timer.stop()
        self.curve.deleteLater()

    def frame(self, line):
        self.curve.on_frame(parse_line(line))

    def read_table(self, mask=0, overrides=None):
        self.frame(f"@CURVE,schema=2,mask={mask},saved=1,total=16")
        for i, mv in enumerate(TARGETS_MV[:16]):
            actual, dac = (overrides or {}).get(i, (mv, 3300-i*200))
            self.frame(f"@CPOINT,id={i},target={mv},valid={int(bool(mask & 1 << i))},actual={actual},dac={dac},saved=1")

    def begin(self):
        self.curve.connection_changed(True, "6.0.3")
        self.read_table()
        self.curve.start(1)
        self.frame("@ACK,cmd=CAL_POINT_START,detail=DIRECT_DAC")
        self.frame("@CSTATE,active=1,id=1,target=3300,dac=3034,vout=3294,ready=1,fault=NONE")

    def test_meter_and_minimum_voltage(self):
        self.assertEqual(meter_millivolts("3.294", 1), 3294)
        for value in ("nan", "inf", "-inf", "0", "65.536", "oops"):
            with self.assertRaises(ValueError):
                meter_millivolts(value, 0)
        with self.assertRaises(ValueError):
            voltage_command(1.999)

    def test_table_read_is_sequential_and_no_output_command(self):
        self.curve.connection_changed(True, "5.9.9")
        self.assertEqual(self.sent, [])
        self.curve.connection_changed(True, "6.0.0")
        self.assertEqual(self.sent, [])
        self.curve.connection_changed(True, "6.0.1")
        self.assertEqual(self.sent, [])
        self.curve.connection_changed(True, "6.0.2")
        self.assertEqual(self.sent, [])
        self.curve.connection_changed(True, "6.0.3")
        self.read_table(0xFFF)
        self.assertEqual(self.curve.completed, 12)
        self.assertFalse(self.curve.busy)
        self.assertEqual(self.sent, ["CAL POINT GET"] + [f"CAL POINT GET {i}" for i in range(16)])
        self.assertEqual([row["label"] for row in self.curve.pointRows[:7]],
                         ["3 V", "3.3 V", "3.6 V", "3.9 V", "4 V", "4.5 V", "5 V"])

    def test_capture_requires_ready_and_save_ack(self):
        self.begin()
        self.curve.capture("2.568")
        self.assertEqual(self.sent[-1], "CAL POINT CAPTURE 2568")
        self.assertEqual(self.sent[-1], "CAL POINT CAPTURE 2568")
        self.assertEqual(self.curve.completed, 0)
        self.curve.step(-1)
        self.assertEqual(self.sent[-1], "CAL POINT CAPTURE 2568")
        self.frame("@ACK,cmd=CAL_POINT_CAPTURE,detail=SAVED_OUTPUT_OFF")
        self.assertFalse(self.curve.active)
        self.assertTrue(self.curve.busy)  # Readback, not optimistic success.
        self.read_table(2, {1: (2568, 3034)})
        self.assertEqual(self.curve.completed, 1)
        self.assertIn("读回核对成功", self.curve.status)

    def test_save_ack_readback_mismatch_is_not_success(self):
        self.begin()
        self.curve.capture("3.294")
        self.frame("@ACK,cmd=CAL_POINT_CAPTURE,detail=SAVED_OUTPUT_OFF")
        self.read_table(2, {1: (3300, 3034)})
        self.assertIn("不一致", self.curve.status)
        self.assertNotIn("核对成功", self.curve.status)

    def test_save_readback_matches_exact_pair(self):
        self.begin()
        self.curve.capture("3.294")
        self.frame("@ACK,cmd=CAL_POINT_CAPTURE,detail=SAVED_OUTPUT_OFF")
        self.read_table(2, {1: (3294, 3034)})
        self.assertIn("读回核对成功", self.curve.status)

    def test_step_ack_waits_for_current_dac_state(self):
        self.begin()
        self.curve.step(1)
        self.frame("@ACK,cmd=CAL_POINT_STEP,detail=DAC_APPLIED")
        count = len(self.sent)
        self.curve.capture("3.280")
        self.assertEqual(count, len(self.sent))
        self.frame("@CSTATE,active=1,id=1,target=3300,dac=3035,vout=3280,ready=1,fault=NONE")
        self.curve.capture("3.280")
        self.assertEqual(self.curve._capture_expected, (1, 3280, 3035))

    def test_capture_deadline_covers_firmware_save_budget(self):
        import time
        self.begin()
        now = time.monotonic()
        self.curve.capture("3.294")
        self.assertGreaterEqual(self.curve._deadline - now, 7.9)

    def test_lost_capture_ack_resolves_by_table_readback(self):
        self.begin()
        self.curve.capture("3.294")
        self.curve._deadline = 0
        self.curve._poll()
        self.frame("@CSTATE,active=0,id=1,target=3300,dac=0,vout=0,ready=0,fault=NONE")
        self.assertEqual(self.sent[-1], "CAL POINT GET")
        self.read_table(2, {1: (3294, 3034)})
        self.assertIn("读回核对成功", self.curve.status)

    def test_real_log_flash_diagnosis_and_failed_save(self):
        self.begin()
        self.curve.capture("4.994")
        self.frame("@CSAVE,ok=0,id=2,actual=4994,dac=2486,reason=FLASH_ERASE_FAILED")
        self.frame("@FLASH,op=CAL_ERASE,stage=ERASE_WAIT,addr=01FFF000,elapsed=3486003375,io=0,hal=00000000,spi_state=1,sr1_valid=1,sr1=03,jedec=EF4019")
        self.frame("@ERR,cmd=CAL_POINT_CAPTURE,reason=FLASH_ERASE_FAILED")
        self.frame("@CSTATE,active=0,id=1,target=3300,dac=0,vout=0,ready=0,fault=NONE")
        self.assertIn("ERASE_WAIT", self.curve.status)
        self.assertFalse(self.curve.active)
        self.assertEqual(self.curve.completed, 0)
        self.assertIsNone(self.curve._capture_expected)

    def test_failed_save_not_counted_and_fault_stops_adjustment(self):
        self.begin()
        self.curve.capture("3.294")
        self.frame("@ERR,cmd=CAL_POINT_CAPTURE,reason=ORDER_OR_FLASH_FAILED_OUTPUT_OFF")
        self.assertEqual(self.curve.completed, 0)
        self.frame("@CSTATE,active=0,id=1,target=3300,dac=0,vout=0,ready=0,fault=IOUT_OC")
        self.assertFalse(self.curve.ready)
        count = len(self.sent)
        self.curve.step(-5)
        self.assertEqual(count, len(self.sent))
        self.curve.connection_changed(False, "")
        self.assertFalse(self.curve.supported)

    def test_old_timestamp_does_not_block_and_command_timeout_only_queries(self):
        self.begin()
        self.curve._last_state = 0
        self.curve._poll()
        self.assertTrue(self.curve.ready)
        self.curve._pending = "CAL_POINT_START"
        self.curve._deadline = 0
        self.curve._active = False
        self.curve._poll()
        self.assertEqual(self.sent[-1], "CAL POINT STATUS")
        self.curve.connection_changed(False, "")
        self.frame("@CSTATE,active=1,id=1,target=3300,dac=3034,vout=3294,ready=1,fault=NONE")
        self.assertFalse(self.curve.active)
        self.assertFalse(self.curve.ready)

    def test_disconnect_waits_for_stop_ack_and_upgrade_is_blocked(self):
        b = Bridge()
        b._worker = Mock()
        b._connected = True
        b._firmware = "6.0.3"
        b.curve._supported = b.curve._active = True
        b.curve._device_version = "6.0.3"
        b.disconnectDevice()
        b._worker.stop.assert_not_called()
        b._worker.send.assert_called_with("CAL POINT STOP")
        b.startUpgrade("6.0.3")
        self.assertFalse(b._updating)
        b.curve.connection_changed(False, "")
        b._log_timer.stop()
        b.curve._timer.stop()
        b.deleteLater()

    def test_read_only_disconnect_does_not_switch_output_off(self):
        b = Bridge()
        worker = Mock()
        worker.isRunning.return_value = False
        b._worker = worker
        b._connected = True
        b.curve.connection_changed(True, "6.0.3")
        self.assertTrue(b.curve.busy)
        self.assertFalse(b.curve.requiresStop)
        b.disconnectDevice()
        worker.stop.assert_called_once()
        self.assertNotIn("CAL POINT STOP", [x.args[0] for x in worker.send.call_args_list])
        b._log_timer.stop()
        b.curve._timer.stop()
        b.deleteLater()

    def test_unacknowledged_start_still_requires_stop(self):
        self.curve.connection_changed(True, "6.0.3")
        self.read_table()
        self.curve.start(0)
        self.curve._deadline = 0
        self.curve._poll()
        self.assertFalse(self.curve.active)
        self.assertTrue(self.curve.requiresStop)

    def test_five_codes_immediate_ack_and_no_state_age_gate(self):
        self.begin()
        self.frame("@CSTATE,active=1,id=12,target=3600,dac=3023,vout=3438,ready=1,fault=NONE")
        self.curve.step(-5)
        self.assertEqual(self.sent[-1], "CAL POINT STEP -5")
        self.assertFalse(self.curve.ready)  # Only the command ACK is pending.
        self.frame("@ACK,cmd=CAL_POINT_STEP,detail=DAC_APPLIED")
        self.assertFalse(self.curve.ready)
        self.frame("@CSTATE,active=1,id=12,target=3600,dac=3018,vout=3500,ready=1,fault=NONE")
        self.assertTrue(self.curve.ready)
        self.curve._last_state = 0
        self.curve.step(-1)
        self.assertEqual(self.sent[-1], "CAL POINT STEP -1")
        self.frame("@ACK,cmd=CAL_POINT_STEP,detail=DAC_APPLIED")
        self.frame("@CSTATE,active=1,id=12,target=3600,dac=3017,vout=3514,ready=1,fault=NONE")
        self.curve.capture("2.975")
        self.assertEqual(self.sent[-1], "CAL POINT CAPTURE 2975")

    def test_overcurrent_fault_disables_calibration(self):
        self.begin()
        self.frame("@CSTATE,active=0,id=12,target=3600,dac=3022,vout=3570,ready=0,fault=IOUT_OC")
        self.assertFalse(self.curve.ready)
        count = len(self.sent)
        self.curve.step(-1)
        self.curve.capture("3.600")
        self.assertEqual(len(self.sent), count)

    def test_qml_calibration_page_and_minimum_width(self):
        b = Bridge()
        b.curve._supported = True
        b.curve._status = "空载校准：选择电压点，微调后输入万用表实测值。"
        warnings = []
        engine = QQmlApplicationEngine()
        engine.warnings.connect(lambda items: warnings.extend(str(x) for x in items))
        engine.rootContext().setContextProperty("bridge", b)
        engine.rootContext().setContextProperty("curve", b.curve)
        engine.load(QUrl.fromLocalFile(str(Path(__file__).resolve().parents[1] / "qml/Main.qml")))
        self.assertTrue(engine.rootObjects())
        root = engine.rootObjects()[0]
        root.setProperty("activePage", 2)
        root.setProperty("width", 1050)
        loop = QEventLoop()
        QTimer.singleShot(200, loop.quit)
        loop.exec()
        self.assertIsNotNone(root.findChild(QObject, "curvePointGrid"))
        self.assertEqual(warnings, [])
        source = (Path(__file__).resolve().parents[1] / "qml/Main.qml").read_text(encoding="utf-8")
        self.assertNotIn("id: actual5", source)
        self.assertNotIn("id: actual20", source)
        root.grabWindow().save(str(Path(__file__).with_name("calibration_603.png")))
        scroll = root.findChild(QObject, "calibrationScroll")
        scroll.setProperty("contentY", 410)
        APP.processEvents()
        root.grabWindow().save(str(Path(__file__).with_name("calibration_controls_603.png")))
        root.close()
        engine.deleteLater()
        b._log_timer.stop()
        b.curve._timer.stop()
        b.deleteLater()


if __name__ == "__main__":
    unittest.main()
