import json
from pathlib import Path
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import Mock
from urllib.request import Request,urlopen
from urllib.error import HTTPError
from PySide6.QtWidgets import QApplication
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from xin_power_qt import Bridge
from live_control import LiveControl

APP=QApplication.instance() or QApplication([])
PARAMS='@PID,kp=150,ki=1000,kd=1,period=20,deadband=10,nearstep=1,farstep=32,nearband=500,rev=1'
TEL='@TEL,t=1000,vin=27900,vout=3601,setv=3600,seti=100,out=1,dac=3053,pid=1,err=-1,delta=0,updates=49,vfb=3601,pidrev=1,valid=1,seq=50,samplet=998,pdt=20,fault=NONE'

class ApiTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.b=Bridge();self.b._worker=Mock()
        root=Path(self.temp.name)
        self.api=LiveControl(self.b,root/'api.json',root/'rx.jsonl')
        self.b.live_api=self.api
        self.b._on_line('@INFO,fw=6.0.6,hw=PY32F403_V2')
        self.b._on_line(PARAMS);self.b._on_line(TEL);self.api.refresh()
        self.url=json.loads((root/'api.json').read_text())['url']
    def tearDown(self):
        self.api.close();self.b._log_timer.stop();self.b.curve._timer.stop();self.b.deleteLater();self.temp.cleanup()
    def request(self,path,body=None,token=True):
        result=[]
        def run():
            req=Request(self.url+path,data=json.dumps(body).encode() if body is not None else None,
                        headers={'Authorization':'Bearer '+(self.api.token if token else 'wrong'),'Content-Type':'application/json'})
            try:
                with urlopen(req,timeout=5) as r: result.append((r.status,json.load(r)))
            except HTTPError as r: result.append((r.code,json.load(r)))
        thread=threading.Thread(target=run);thread.start()
        deadline=time.monotonic()+6
        while thread.is_alive() and time.monotonic()<deadline: APP.processEvents();time.sleep(.001)
        thread.join(.1);self.assertTrue(result)
        return result[0]
    def test_auth_snapshot_events_and_revision_echo(self):
        self.assertEqual(self.request('/v1/state',token=False)[0],401)
        code,state=self.request('/v1/state');self.assertEqual(state['telemetry']['vfb'],'3601')
        self.assertEqual(state['pid_revision'],1);self.assertEqual(state['epoch'],1)
        params={'kp':'.15','ki':'.2','kd':'.001','period':20,'deadband':5,'nearstep':1,'farstep':32,'nearband':500}
        code,r=self.request('/v1/pid',{'epoch':1,'revision':1,'parameters':params})
        self.assertEqual(code,202);self.assertFalse(r['confirmed'])
        self.b._worker.send.assert_called_with('PID SET 150 200 1 20 5 1 32 500')
        self.b._on_line('@ACK,cmd=PID_SET,detail=RAM_APPLIED')
        self.b._on_line(PARAMS.replace('ki=1000','ki=200').replace('deadband=10','deadband=5').replace('rev=1','rev=2'))
        self.api.refresh();self.assertEqual(self.request('/v1/state')[1]['pid_revision'],2)
        _,events=self.request('/v1/events?after=3');self.assertEqual(events['events'][-1]['kind'],'pid_config')
    def test_reboot_invalidates_same_revision_and_stale_commands(self):
        self.b._on_line(TEL.replace('t=1000','t=10'));self.api.refresh()
        state=self.request('/v1/state')[1];self.assertEqual(state['epoch'],2);self.assertIsNone(state['pid_revision'])
        self.b._worker.send.reset_mock()
        self.assertEqual(self.request('/v1/output',{'epoch':1,'on':True})[0],409)
        self.b._worker.send.assert_not_called()
    def test_bounds_and_no_extra_control_commands(self):
        self.b._worker.send.reset_mock()
        for path,body in [('/v1/voltage',{'epoch':1,'mv':3500.5}),('/v1/output',{'epoch':1,'on':'true'}),
                          ('/v1/command',{'epoch':1,'command':'CAL RESET'}),('/v1/telemetry-rate',{'epoch':1,'ms':20})]:
            self.assertEqual(self.request(path,body)[0],409)
        self.b._worker.send.assert_not_called()
        self.assertEqual(self.request('/v1/voltage',{'epoch':1,'mv':3300})[0],202)
        self.b._worker.send.assert_called_with('SET V 3300')
        self.assertEqual(self.request('/v1/voltage',{'epoch':1,'mv':2000})[0],202)
        self.b._worker.send.assert_called_with('SET V 2000')
        for value in (1999, 32001):
            self.assertEqual(self.request('/v1/voltage',{'epoch':1,'mv':value})[0],409)

    def test_608_dac_mode_never_sends_pid_commands(self):
        self.b._worker.send.reset_mock()
        self.b._on_line('@INFO,fw=6.0.8,control=DAC,rup=100000,rgnd=7620,rinj=5110')
        self.b._on_line(TEL.replace('pid=1','pid=0').replace('t=1000','t=2000'))
        self.api.refresh()
        self.assertFalse(self.b.pid.supported)
        self.assertEqual(self.request('/v1/state')[1]['device_info']['rinj'],'5110')
        self.assertFalse(any(str(call.args[0]).startswith('PID') for call in self.b._worker.send.call_args_list))
        self.b._worker.send.reset_mock()
        self.assertEqual(self.request('/v1/pid-read',{'epoch':2})[0],409)
        params={'kp':'.15','ki':'4','kd':'.001','period':20,'deadband':5,'nearstep':1,'farstep':1,'nearband':500}
        self.assertEqual(self.request('/v1/pid',{'epoch':2,'revision':None,'parameters':params})[0],409)
        self.b._worker.send.assert_not_called()
        self.assertEqual(self.request('/v1/voltage',{'epoch':2,'mv':3600})[0],202)
        self.b._worker.send.assert_called_with('SET V 3600')

if __name__=='__main__':unittest.main()
