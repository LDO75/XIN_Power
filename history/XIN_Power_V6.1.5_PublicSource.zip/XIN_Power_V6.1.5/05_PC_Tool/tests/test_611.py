"""Offline 17-point and 2V integration checks; never opens hardware."""
from pathlib import Path
import sys, unittest
from unittest.mock import Mock
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PySide6.QtWidgets import QApplication
from dac_calibration import CurveCalibration, TARGETS_MV
from protocol import parse_line, voltage_command
from xin_power_qt import Bridge
APP=QApplication.instance() or QApplication([])
class ProtectionUiTests(unittest.TestCase):
    def setUp(self):
        self.sent=[];self.c=CurveCalibration(self.sent.append, lambda:True)
    def tearDown(self): self.c._timer.stop();self.c.deleteLater()
    def frame(self,line): self.c.on_frame(parse_line(line))
    def table(self,count=17,mask=65535):
        self.frame(f'@CURVE,schema=2,mask={mask},saved=1,total={count}')
        for i,mv in enumerate(TARGETS_MV[:count]):
            self.frame(f'@CPOINT,id={i},target={mv},valid={int(bool(mask&(1<<i)))},actual={1998 if i==16 else mv},dac={3220 if i==16 else 1000},saved=1')
    def test_17th_point_capture_ack_and_readback(self):
        self.c.connection_changed(True,'6.1.1');self.table()
        self.assertEqual((self.c.total,self.c.completed),(17,16))
        self.assertEqual(self.c.pointRows[0]['label'],'2 V')
        self.assertEqual(self.sent[-1],'CAL POINT GET 16')
        self.c.start(16);self.assertEqual(self.sent[-1],'CAL POINT START 16')
        self.frame('@ACK,cmd=CAL_POINT_START,detail=DIRECT_DAC')
        self.frame('@CSTATE,active=1,id=16,target=2000,dac=3220,vout=1998,ready=1,fault=NONE')
        self.c.capture('1.998');self.assertEqual(self.sent[-1],'CAL POINT CAPTURE 1998')
        self.frame('@ACK,cmd=CAL_POINT_CAPTURE,detail=SAVED_OUTPUT_OFF');self.table(mask=131071)
        self.assertEqual(self.c.completed,17);self.assertIn('核对成功',self.c.status)
    def test_legacy_16_does_not_offer_invalid_point(self):
        self.c.connection_changed(True,'6.1.0');self.table(count=16)
        self.assertEqual(self.c.total,16);self.assertEqual(len(self.c.pointRows),16)
        count=len(self.sent);self.c.start(16);self.assertEqual(len(self.sent),count)
        self.assertIn('6.1.1',self.c.status)
    def test_every_fault_disables_calibration_capture(self):
        self.c.connection_changed(True,'6.1.1');self.table()
        for reason in ('MON_OFFLINE','VIN_UV','VOUT_OV','OTP','SHORT','IOUT_OC','IIN_OC'):
            self.frame(f'@CSTATE,active=0,id=16,target=2000,dac=0,vout=200,ready=0,fault={reason}')
            count=len(self.sent);self.c.step(-1);self.c.capture('2.000')
            self.assertEqual(len(self.sent),count);self.assertFalse(self.c.ready)
    def test_version_change_refreshes_legacy_16_table(self):
        self.c.connection_changed(True,'6.1.0');self.table(count=16)
        self.c.connection_changed(True,'6.1.1');self.assertEqual(self.sent[-1],'CAL POINT GET')
        self.table();self.assertEqual(self.c.total,17);self.assertEqual(len(self.c.pointRows),17)
    def test_voltage_range_both_protocol_and_gui(self):
        self.assertEqual(voltage_command(2.0),('SET V 2000',2000))
        self.assertEqual(voltage_command(32.0),('SET V 32000',32000))
        for v in (1.999,32.001):
            with self.assertRaises(ValueError): voltage_command(v)
        b=Bridge();b._worker=Mock();b.applySetpoints('2.000','0.100')
        self.assertEqual([c.args[0] for c in b._worker.send.call_args_list],['SET V 2000','SET I 100'])
        b._worker.send.reset_mock();b.applySetpoints('1.999','0.100');b._worker.send.assert_not_called()
        b._log_timer.stop();b.curve._timer.stop();b.deleteLater()
if __name__=='__main__':unittest.main()
