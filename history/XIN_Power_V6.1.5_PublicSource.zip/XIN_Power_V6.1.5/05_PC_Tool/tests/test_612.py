"""User SHORT trace and its UI recovery guidance; offline only."""
from pathlib import Path
import sys,unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PySide6.QtWidgets import QApplication
from dac_calibration import CurveCalibration,TARGETS_MV
from protocol import parse_line
from xin_power_qt import Bridge
APP=QApplication.instance() or QApplication([])
class ShortTraceTests(unittest.TestCase):
    def setUp(self):self.sent=[];self.c=CurveCalibration(self.sent.append,lambda:True)
    def tearDown(self):self.c._timer.stop();self.c.deleteLater()
    def frame(self,line):self.c.on_frame(parse_line(line))
    def begin(self):
        self.c.connection_changed(True,'6.1.2')
        self.frame('@CURVE,schema=2,mask=65535,saved=1,total=17')
        for i,mv in enumerate(TARGETS_MV):
            self.frame(f'@CPOINT,id={i},target={mv},valid={int(i<16)},actual={mv if i<16 else 0},dac=1000,saved=1')
        self.c.start(16);self.frame('@ACK,cmd=CAL_POINT_START,detail=DIRECT_DAC')
    def test_low_voltage_state_is_reported_without_blocking_manual_step(self):
        self.begin();self.frame('@CSTATE,active=1,id=16,target=2000,dac=3228,vout=173,ready=1,fault=NONE')
        self.assertTrue(self.c.ready);self.assertIn('低于 0.5V',self.c.status)
        self.c.step(-1);self.assertEqual(self.sent[-1],'CAL POINT STEP -1')
    def test_latched_fault_explains_clear_and_keeps_output_off(self):
        self.begin();self.frame('@CSTATE,active=0,id=16,target=2000,dac=0,vout=148,ready=0,fault=SHORT')
        self.assertIn('SHORT',self.c.status);self.assertIn('清除故障',self.c.status)
        self.c.start(16);self.frame('@ERR,cmd=CAL_POINT_START,reason=FAULT_ACTIVE_USE_CLEAR')
        self.assertIn('故障仍锁存',self.c.status);self.assertIn('保持关闭',self.c.status)
        self.assertFalse(self.c.ready);self.assertNotIn('CLEAR',self.sent)
    def test_fault_name_and_raw_log_code_both_available(self):
        b=Bridge();b._on_line('@TEL,t=36595,vin=27906,vout=173,temp=283,out=0,fault=SHORT')
        self.assertEqual(b.fault,'SHORT');self.assertIn('短路保护',b.faultText)
        b._log_timer.stop();b.curve._timer.stop();b.deleteLater()
if __name__=='__main__':unittest.main()
