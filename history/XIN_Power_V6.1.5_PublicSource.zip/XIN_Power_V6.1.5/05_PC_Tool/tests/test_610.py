"""Offline replay of patch-board telemetry; no serial ports are opened."""
from pathlib import Path
import csv
import sys
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PySide6.QtCore import QObject, QTimer, QEventLoop, QUrl
from PySide6.QtWidgets import QApplication, QFileDialog
from PySide6.QtQml import QQmlApplicationEngine
from PySide6.QtQuickControls2 import QQuickStyle
from PySide6.QtGui import QFontDatabase, QFont
from xin_power_qt import Bridge

QQuickStyle.setStyle('Basic')
APP=QApplication.instance() or QApplication([])
for filename in ('msyh.ttc','segoeui.ttf','consola.ttf'):
    QFontDatabase.addApplicationFont(f'C:/Windows/Fonts/{filename}')
APP.setFont(QFont('Microsoft YaHei'))
class PatchBoardTests(unittest.TestCase):
    def setUp(self): self.b=Bridge()
    def tearDown(self):
        self.b._log_timer.stop();self.b.curve._timer.stop();self.b.deleteLater()
    def tel(self,fast,out=1,setv=3200,dac=3091):
        self.b._on_line(f'@TEL,t=1000,vin=27900,vout=3200,vfast={fast},iout=0,pout=0,temp=300,setv={setv},seti=100,req={out},out={out},dac={dac},cegpio={1-out},dw=3,dwt=900,valid=1,fault=NONE')
    def test_raw_ripple_residual_and_transition_window(self):
        self.tel(3130);self.tel(3256)
        self.assertEqual(self.b.historyVoltage,[3.130,3.256])
        self.assertIn('126.0 mV',self.b.voltageWindowText)
        self.tel(8,0,dac=0);self.tel(536,0,dac=0)
        self.assertEqual(self.b.historyVoltage,[.008,.536])
        self.assertIn('528.0 mV',self.b.voltageWindowText)
        self.assertIn('残余实测电压',self.b.controlDiagnostic)
        self.assertIn('CE GPIO 1',self.b.controlDiagnostic)
        self.assertEqual(len(self.b._telemetry_rows),4)
        self.tel(3100,setv=3100)
        self.assertEqual(self.b.historyVoltage,[3.1])
    def test_csv_extra_control_columns(self):
        self.tel(3130)
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'samples.csv'
            with patch.object(QFileDialog,'getSaveFileName',return_value=(str(path),'')):
                self.b.exportCsv()
            with path.open(encoding='utf-8-sig',newline='') as f:
                rows=list(csv.reader(f))
            self.assertEqual(len(rows[0]),len(rows[1]))
            self.assertEqual(rows[1][-5:],['1','0','3','900','3130'])
    def test_version_and_trend_qml_render(self):
        self.b._on_line('@INFO,fw=6.1.1,control=DAC,hw=PY32F403_V2,src=INPUT')
        self.assertTrue(self.b.curve.supported)
        warnings=[];engine=QQmlApplicationEngine()
        engine.warnings.connect(lambda items:warnings.extend(str(x) for x in items))
        engine.rootContext().setContextProperty('bridge',self.b)
        engine.rootContext().setContextProperty('curve',self.b.curve)
        engine.rootContext().setContextProperty('pid',self.b.pid)
        engine.load(QUrl.fromLocalFile(str(Path(__file__).resolve().parents[1]/'qml/Main.qml')))
        self.assertTrue(engine.rootObjects());root=engine.rootObjects()[0]
        root.setProperty('activePage',1);root.setProperty('width',1050);root.setProperty('height',760)
        for i in range(140): self.tel(20+(i%10)*35,0,dac=0)
        loop=QEventLoop();QTimer.singleShot(250,loop.quit);loop.exec()
        self.assertEqual(warnings,[])
        self.assertTrue(root.grabWindow().save(str(Path(__file__).with_name('trend_610.png'))))
        root.close();engine.deleteLater()
if __name__=='__main__':unittest.main()
