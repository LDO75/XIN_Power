"""Run current offline checks. Set QT_QPA_PLATFORM=offscreen for headless use."""
import sys,unittest
suite=unittest.TestSuite();loader=unittest.TestLoader()
for name in ('test_603','test_610','test_611','test_612','test_live_control'):
    suite.addTests(loader.loadTestsFromName(name))
result=unittest.TextTestRunner(verbosity=1).run(suite)
sys.exit(0 if result.wasSuccessful() else 1)
