# XIN Power Studio V6.1.5

量程2–32V。17点DAC校准，兼容旧16点。说明见根目录README_下载与校准.md。
