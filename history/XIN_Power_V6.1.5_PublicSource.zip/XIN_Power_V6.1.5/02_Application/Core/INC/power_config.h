/**
  ******************************************************************************
  * @file    power_config.h
  * @brief   数控电源量程、保护阈值和FB调压参数集中配置。
  ******************************************************************************
  */

#ifndef __POWER_CONFIG_H__
#define __POWER_CONFIG_H__

/* 用户可调范围。 */
#define POWER_CFG_VOLTAGE_MIN_MV              2000U
#define POWER_CFG_VOLTAGE_MAX_MV             32000U
#define POWER_CFG_CURRENT_MIN_MA                100U
#define POWER_CFG_CURRENT_MAX_MA               8000U

/* Short-circuit overcurrent uses these SAME immediate current trips.
 * No independent low-voltage, small-current or startup-delay short detector. */
#define POWER_CFG_INPUT_TRIP_MA                 4800U
#define POWER_CFG_OUTPUT_TRIP_MA                8500U

/* 功率区NTC与风扇。 */
#define POWER_CFG_FAN_START_DEFAULT_C                40U
#define POWER_CFG_FAN_STOP_C                         35U
#define POWER_CFG_OUTPUT_BLEEDER_OHM               1800U
#define POWER_CFG_FAN_START_MIN_C                    30U
#define POWER_CFG_FAN_START_MAX_C                    65U
#define POWER_CFG_FAN_START_STEP_C                    1U

/* SC8701 FB网络和MCP4725参考电压。 */
#define POWER_CFG_FB_REFERENCE_UV            1220000UL
#define POWER_CFG_DAC_REFERENCE_UV           3000000UL
#define POWER_CFG_FB_UPPER_OHM                100000UL
#define POWER_CFG_FB_LOWER_OHM                  7620UL

/* R274=100k, R314+R315=7.62k, R316+R317=4.99k+120=5.11k. */
#define POWER_CFG_FB_INJECTION_OHM              5110UL
#define POWER_CFG_DAC_SCALE_CODES               4096UL
#define POWER_CFG_SAMPLE_PERIOD_MS                1U
#define POWER_CFG_DAC_HARDWARE_TAG             0x4991U

#define POWER_CFG_INPUT_UV_MV                   4000U
#define POWER_CFG_INPUT_UV_DELAY_MS               200U
#define POWER_CFG_OUTPUT_ABSOLUTE_OV_MV         33000U
#define POWER_CFG_OUTPUT_OV_MARGIN_MV             300U
#define POWER_CFG_OUTPUT_OV_PERMILLE              100U
#define POWER_CFG_OUTPUT_OV_DELAY_MS              100U
#define POWER_CFG_OVER_TEMPERATURE_DECIC          800
#define POWER_CFG_MONITOR_LOSS_MIN_MS             500U
#define POWER_CFG_MONITOR_LOSS_PERIODS              3U

#endif /* __POWER_CONFIG_H__ */
