# XIN Power Studio V6.0.4

配套 APP 6.0.4，双击成品 EXE 运行。源码入口 `xin_power_qt.py`，打包脚本 `build_windows.bat`。

校准：选点、手动 ±1/±5 调 DAC、输入万用表实测值、采集并保存。直接写码，无稳定/漂移/时间/接近目标限制；收到 DAC 写入 ACK 即可继续。保存实测电压与 DAC，其他电压用实测区间映射。电流设定为过流关断阈值，不进行软件恒流调码。校准沿用用户电流设定。

16 点，原 12 点保留。直接校准协议兼容 APP >=6.0.3；3.6 V 保存修复需要 APP 6.0.4。旧 APP 可连接监控并升级，现有 Studio 6.0.3 也能安装和使用 APP 6.0.4。USB/经典蓝牙 SPP 升级沿用既有串口。根目录 `README_下载与校准.md` 和 `修改清单.md` 说明操作与全部删除条件。

短检查：`python -m unittest discover -s tests -p "test_*.py" -v`。不打开真实串口。`xin_power_console.py` 与 `README_V5.8.6_LEGACY.md` 是旧 Tk 工具及历史说明，本版入口为 Qt 工具。
