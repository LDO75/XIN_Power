/**
 * @file power_control.c
 * @brief Direct calibrated DAC output; only overcurrent latches a power fault.
 */
#include "power_control.h"
#include "calibration.h"
#include "debug_console.h"
#include "gpio.h"
#include "i2c.h"
#include "mcp4725.h"
#include "power_config.h"
#include <stddef.h>
#include <stdio.h>
#include <string.h>

#define POWER_CONTROL_DAC_RETRY_MS 1000U
#define POWER_CONTROL_DEBUG_PERIOD_MS 1000U

static MCP4725_Device_t s_dac;
static PowerControl_Status_t s_status;
static uint16_t s_applied_dac_code;
static uint16_t s_setpoint_mv;
static uint16_t s_calibration_code;
static bool s_calibration_active;
static uint32_t s_last_sample_sequence;
static uint32_t s_last_dac_retry_time_ms;
static uint32_t s_last_debug_time_ms;
static char s_fault_context[256];

static void PowerControl_DisableHardware(void)
{
  HAL_GPIO_WritePin(P_EN_Port, P_EN_Pin, GPIO_PIN_SET);
  s_status.output_enabled = false;
}

/* Write errors are command errors, not an extra automatic power fault. */
static bool PowerControl_WriteDac(uint16_t code)
{
  if (!s_dac.ready) { return false; }
  if (!MCP4725_WriteVolatile(&s_dac, code))
  {
    DebugConsole_Write("[DAC] write failed; previous applied code retained\r\n");
    return false;
  }
  s_applied_dac_code = code;
  s_status.dac_code = code;
  return true;
}

static void PowerControl_ParkDac(void)
{
  /* DAC=0 can command high voltage: close CE before OFF parking. */
  PowerControl_DisableHardware();
  if (s_applied_dac_code != 0U) { (void)PowerControl_WriteDac(0U); }
}

static void PowerControl_TripOvercurrent(uint32_t now,
  PowerControl_Fault_t fault, const PowerControl_Request_t *request,
  const PowerMonitor_Snapshot_t *measurement)
{
  unsigned int phase = s_status.output_enabled ? 2U : 0U;
  uint16_t fault_dac = s_applied_dac_code;
  PowerControl_DisableHardware();
  if (s_status.fault == POWER_CONTROL_FAULT_NONE)
  {
    char event[96];
    s_status.fault = fault;
    (void)snprintf(event, sizeof(event),
      "[FAULT] t=%lu reason=%s output=OFF\r\n",
      (unsigned long)now, PowerControl_GetFaultName(fault));
    (void)snprintf(s_fault_context, sizeof(s_fault_context),
      "@FAULT,t=%lu,reason=%s,phase=%u,coarse=0,pid=0,set=%u,dac=%u,vout=%u,vuncal=%u,"
      "vin=%u,iin=%ld,iout=%ld,pout=%lu,temp=%d,valid=%u,age=%lu,seq=%lu\r\n",
      (unsigned long)now, PowerControl_GetFaultName(fault), phase,
      request->voltage_setpoint_mv, fault_dac,
      measurement->output_voltage_raw_mv, measurement->output_voltage_uncalibrated_mv,
      measurement->input_voltage_raw_mv, (long)measurement->input_current_raw_ua,
      (long)measurement->output_current_uncalibrated_ua,
      (unsigned long)measurement->output_power_raw_mw, request->temperature_decic,
      measurement->data_valid ? 1U : 0U,
      (unsigned long)(now - measurement->last_valid_sample_time_ms),
      (unsigned long)measurement->sample_sequence);
    DebugConsole_Write(event);
    DebugConsole_Write(s_fault_context);
  }
  s_calibration_active = false;
  s_last_debug_time_ms = now - POWER_CONTROL_DEBUG_PERIOD_MS;
  PowerControl_ParkDac();
}

/* No voltage, temperature, power, age, drift or startup-trip logic exists here. */
static void PowerControl_CheckOvercurrent(uint32_t now,
  const PowerControl_Request_t *request,
  const PowerMonitor_Snapshot_t *measurement)
{
  if (measurement == NULL || !measurement->data_valid ||
      measurement->sample_sequence == s_last_sample_sequence) { return; }
  s_last_sample_sequence = measurement->sample_sequence;
  int32_t output_ua = measurement->output_current_raw_ua;
  if (measurement->output_current_uncalibrated_ua > output_ua)
  { output_ua = measurement->output_current_uncalibrated_ua; }
  if (measurement->input_current_raw_ua > (int32_t)POWER_CFG_INPUT_TRIP_MA * 1000L)
  {
    PowerControl_TripOvercurrent(now, POWER_CONTROL_FAULT_INPUT_OVERCURRENT,
                                 request, measurement);
  }
  else if (output_ua > (int32_t)s_status.effective_current_limit_ma * 1000L ||
           output_ua > (int32_t)POWER_CFG_OUTPUT_TRIP_MA * 1000L)
  {
    PowerControl_TripOvercurrent(now, POWER_CONTROL_FAULT_OUTPUT_OVERCURRENT,
                                 request, measurement);
  }
}

static void PowerControl_PrintDebug(uint32_t now,
  const PowerMonitor_Snapshot_t *measurement)
{
  if (now - s_last_debug_time_ms < POWER_CONTROL_DEBUG_PERIOD_MS) { return; }
  s_last_debug_time_ms = now;
  char text[224];
  unsigned int phase = s_status.fault != POWER_CONTROL_FAULT_NONE ? 3U :
                       (s_status.output_enabled ? 2U : 0U);
  (void)snprintf(text, sizeof(text),
    "[POWER] state=%u out=%u cc=0 dac=%u cv=0 set=%umV pid=0 low=%u ilim=%umA "
    "mon=%u age=%lums seq=%lu fault=%s\r\n",
    phase, s_status.output_enabled ? 1U : 0U, s_status.dac_code, s_setpoint_mv,
    s_setpoint_mv < 4000U ? 1U : 0U, s_status.effective_current_limit_ma,
    measurement != NULL && measurement->data_valid ? 1U : 0U,
    (unsigned long)(measurement == NULL ? UINT32_MAX : now - measurement->last_valid_sample_time_ms),
    (unsigned long)(measurement == NULL ? 0U : measurement->sample_sequence),
    PowerControl_GetFaultName(s_status.fault));
  DebugConsole_Write(text);
  if (s_status.fault != POWER_CONTROL_FAULT_NONE) { DebugConsole_Write(s_fault_context); }
}

uint16_t PowerControl_VoltageToDacCode(uint16_t voltage_mv)
{
  int64_t dac_voltage_uv;
  uint32_t code;
  uint16_t calibrated_code;

  if (voltage_mv < POWER_CFG_VOLTAGE_MIN_MV)
  {
    voltage_mv = POWER_CFG_VOLTAGE_MIN_MV;
  }
  else if (voltage_mv > POWER_CFG_VOLTAGE_MAX_MV)
  {
    voltage_mv = POWER_CFG_VOLTAGE_MAX_MV;
  }

  if (Calibration_MapDac(voltage_mv, &calibrated_code))
  {
    return calibrated_code;
  }

  dac_voltage_uv = (int64_t)(2UL * POWER_CFG_FB_REFERENCE_UV) -
    (((int64_t)POWER_CFG_FB_LOWER_OHM *
      ((int64_t)voltage_mv * 1000LL - POWER_CFG_FB_REFERENCE_UV)) /
     POWER_CFG_FB_UPPER_OHM);
  if (dac_voltage_uv < 0)
  {
    dac_voltage_uv = 0;
  }
  if (dac_voltage_uv > (int64_t)POWER_CFG_DAC_REFERENCE_UV)
  {
    dac_voltage_uv = POWER_CFG_DAC_REFERENCE_UV;
  }
  code = (uint32_t)((dac_voltage_uv * MCP4725_MAX_CODE +
                     (POWER_CFG_DAC_REFERENCE_UV / 2UL)) /
                    POWER_CFG_DAC_REFERENCE_UV);
  return (code > MCP4725_MAX_CODE) ? MCP4725_MAX_CODE : (uint16_t)code;
}


bool PowerControl_Init(void)
{
  uint32_t now = HAL_GetTick();
  PowerControl_DisableHardware();
  (void)memset(&s_status, 0, sizeof(s_status));
  s_applied_dac_code = 0U;
  s_setpoint_mv = 0U;
  s_calibration_active = false;
  s_last_sample_sequence = 0U;
  s_last_dac_retry_time_ms = now;
  s_last_debug_time_ms = now - POWER_CONTROL_DEBUG_PERIOD_MS / 2U;
  s_fault_context[0] = '\0';
  s_status.effective_current_limit_ma = POWER_CFG_CURRENT_MIN_MA;
  return MCP4725_Init(&s_dac, &hi2c2, MCP4725_ADDRESS_7BIT) &&
         PowerControl_WriteDac(0U);
}

void PowerControl_Process(uint32_t now, const PowerControl_Request_t *request,
  const PowerMonitor_Snapshot_t *measurement)
{
  if (request == NULL) { return; }
  s_setpoint_mv = request->voltage_setpoint_mv;
  s_status.effective_current_limit_ma = request->current_limit_ma;
  s_status.constant_current = false;
  if (!s_dac.ready && now - s_last_dac_retry_time_ms >= POWER_CONTROL_DAC_RETRY_MS)
  {
    s_last_dac_retry_time_ms = now;
    (void)MCP4725_Init(&s_dac, &hi2c2, MCP4725_ADDRESS_7BIT);
  }
  if (!request->output_requested)
  {
    s_calibration_active = false;
    PowerControl_ParkDac();
    PowerControl_PrintDebug(now, measurement);
    return;
  }
  if (s_status.fault != POWER_CONTROL_FAULT_NONE)
  {
    PowerControl_ParkDac();
    PowerControl_PrintDebug(now, measurement);
    return;
  }
  PowerControl_CheckOvercurrent(now, request, measurement);
  if (s_status.fault == POWER_CONTROL_FAULT_NONE)
  {
    uint16_t target = s_calibration_active ? s_calibration_code :
                      PowerControl_VoltageToDacCode(request->voltage_setpoint_mv);
    /* Exactly one requested code. No ramp, trim, learning or voltage feedback. */
    if (!s_status.output_enabled || target != s_applied_dac_code)
    {
      if (PowerControl_WriteDac(target))
      {
        HAL_GPIO_WritePin(P_EN_Port, P_EN_Pin, GPIO_PIN_RESET);
        s_status.output_enabled = true;
      }
    }
  }
  PowerControl_PrintDebug(now, measurement);
}

void PowerControl_ResetVoltageLearning(void)
{
  /* Compatibility API: V6.0.3 has no learned state or automatic voltage trim. */
}

bool PowerControl_BeginDacCalibration(uint16_t target_mv)
{
  if (s_calibration_active || s_status.fault != POWER_CONTROL_FAULT_NONE ||
      target_mv < POWER_CFG_VOLTAGE_MIN_MV || target_mv > POWER_CFG_VOLTAGE_MAX_MV)
  { return false; }
  s_calibration_code = PowerControl_VoltageToDacCode(target_mv);
  Calibration_Data_t data; Calibration_Get(&data);
  for (unsigned int i = 0U; i < CALIBRATION_POINT_COUNT; i++)
  {
    if (Calibration_PointTarget(i) == target_mv && (data.point_mask & (1U << i)) != 0U)
    { s_calibration_code = data.points[i].dac_code; break; }
  }
  s_calibration_active = true;
  return true;
}

bool PowerControl_IsDacCalibrationActive(void) { return s_calibration_active; }

bool PowerControl_DacCalibrationReady(const PowerMonitor_Snapshot_t *measurement)
{
  (void)measurement;
  /* ready means the selected code has been written, not analogue stability. */
  return s_calibration_active && s_status.output_enabled &&
         s_status.fault == POWER_CONTROL_FAULT_NONE &&
         s_applied_dac_code == s_calibration_code;
}

bool PowerControl_StepDacCalibration(int16_t delta,
  const PowerMonitor_Snapshot_t *measurement)
{
  if ((delta != -5 && delta != -1 && delta != 1 && delta != 5) ||
      !PowerControl_DacCalibrationReady(measurement)) { return false; }
  int32_t next = (int32_t)s_calibration_code + delta;
  if (next < 0 || next > MCP4725_MAX_CODE) { return false; }
  if (!PowerControl_WriteDac((uint16_t)next)) { return false; }
  s_calibration_code = (uint16_t)next;
  return true;
}

void PowerControl_EndDacCalibration(void)
{
  PowerControl_ParkDac();
  s_calibration_active = false;
}

bool PowerControl_ClearFault(void)
{
  PowerControl_ParkDac();
  s_status.fault = POWER_CONTROL_FAULT_NONE;
  s_fault_context[0] = '\0';
  s_calibration_active = false;
  DebugConsole_Write("[FAULT] cleared; output remains OFF\r\n");
  return true;
}

void PowerControl_GetStatus(PowerControl_Status_t *status)
{
  if (status != NULL) { *status = s_status; }
}
const char *PowerControl_GetFaultContext(void) { return s_fault_context; }
const char *PowerControl_GetFaultName(PowerControl_Fault_t fault)
{
  switch (fault)
  {
    case POWER_CONTROL_FAULT_NONE: return "NONE";
    case POWER_CONTROL_FAULT_INPUT_OVERCURRENT: return "IIN_OC";
    case POWER_CONTROL_FAULT_OUTPUT_OVERCURRENT: return "IOUT_OC";
    default: return "UNKNOWN";
  }
}
