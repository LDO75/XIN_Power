# V6.0.6 调压命令

| 命令 | 行为 |
| --- | --- |
| PID GET | 返回@PID当前8项RAM参数和rev |
| PID SET kp ki kd period deadband nearstep farstep nearband | 整组应用；前三项为实际增益×1000的整数，Ki实际单位/秒、Kd秒；共同采样/PID周期ms |
| PID RESET | 恢复本版RAM默认值，保留输出及当前DAC，返回ACK和@PID |
| INFO / STATUS / DIAG | 查询版本、状态、链路计数 |
| SET V mV | 设定 3000–32000 mV，设置持续 CV PID 的目标电压（校准模式仍直接 DAC） |
| SET I mA | 设置 100–8000 mA 输出过流关断阈值，无 CC 调码 |
| OUT ON / OUT OFF | 开启/关闭输出 |
| CLEAR | 关闭输出并清除锁存过流故障 |
| CAL POINT GET / GET id | 顺序读取 schema=2、16 点；只读 |
| CAL POINT STATUS | 返回 DAC、设备电压、active、ready；ready 只表示 DAC 已写入 |
| CAL POINT START id | id=0–15；直接选定 DAC 并开启输出，保留用户电流设定，允许从 ON 进入 |
| CAL POINT STEP -5/-1/1/5 | 直接写码；负码升压、正码降压，无稳定窗口、时间及距目标限制 |
| CAL POINT CAPTURE mV | 保存 1–65535 mV 实测值及已写 DAC；先 OFF，再写 Flash 并回读 |
| CAL POINT STOP | 关闭输出、恢复此前设定、不保存未采集数据 |
| CAL GET / CAL RAW | 查看既有测量系数 |
| CAL SET V/I/DAC / CAL SAVE / CAL RESET | 旧参数接口，修改测量系数/旧两点后备/保存/重置；需要 OFF，RESET 后保存将清空曲线 |
| LOG ON/OFF / LOG RATE ms | 回传开关，100–5000 ms |
| FW STATUS / BEGIN/DATA/END/APPLY/ABORT | 沿用原升级接口，由升级页管理 |

校准期间 START 所在端口负责 STEP/CAPTURE；普通 SET/旧 CAL 修改/升级先 STOP，以免两个操作同时修改同一 DAC 或 Flash。ACK 表示命令已执行，5 秒未确认只查询状态，不触发电源关断。保存仅检查数据格式及实际电压区间顺序（不检查 DAC 方向），不检查贴近目标或 INA 一致性。

原 0–11 ID 不变；12=3.6 V、13=3.9 V、14=4 V、15=4.5 V。目标标签不代替实测值。FAULT 仅 IIN_OC 或 IOUT_OC。

PID SET 默认命令：`PID SET 150 1000 1 20 10 1 32 500`。参数范围和物理公式见根目录README。不是旧版每10ms参数的相同单位。

@TEL新增pid、err(mV)、delta(DAC码)、updates、vfb(校准后PID反馈mV)、pidrev、pdt(实际PID间隔ms)、seq(采样序号)、samplet(采样设备ms)。原字段继续兼容；@PID增益字段为千分整数。协议版本仍为4，增量扩展不修改升级协议。
