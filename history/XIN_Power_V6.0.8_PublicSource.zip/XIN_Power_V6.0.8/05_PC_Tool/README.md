# XIN Power Studio V6.0.8

直接DAC调压及实时遥测，固件目标6.0.8。见工程根目录README_下载与校准.md。
