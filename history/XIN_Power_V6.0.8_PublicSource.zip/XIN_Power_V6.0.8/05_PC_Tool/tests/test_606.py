"""PID editing, acknowledgement and exports; no serial device opened."""
from pathlib import Path
import csv
import sys
import tempfile
import unittest
from unittest.mock import Mock, patch
from PySide6.QtCore import QObject, QUrl, QEventLoop, QTimer
from PySide6.QtQml import QQmlApplicationEngine
from PySide6.QtWidgets import QApplication
from PySide6.QtQuickControls2 import QQuickStyle
from PySide6.QtGui import QFontDatabase, QFont
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from xin_power_qt import Bridge
from pid_tuning import encode_config

QQuickStyle.setStyle('Basic')
APP = QApplication.instance() or QApplication([])
QFontDatabase.addApplicationFont('C:/Windows/Fonts/msyh.ttc')
APP.setFont(QFont('Microsoft YaHei'))
PARAMS='@PID,kp=150,ki=1000,kd=1,period=20,deadband=10,nearstep=1,farstep=32,nearband=500,rev=1'
TEL='@TEL,t=1000,vin=27900,vout=3601,iout=0,pout=0,temp=300,setv=3600,seti=100,out=1,dac=3053,pid=1,err=-1,delta=0,updates=49,vfb=3601,pidrev=1,valid=1,vraw=3600,seq=50,samplet=998,pdt=20,fault=NONE'

class PidTests(unittest.TestCase):
    def setUp(self): self.b=Bridge(); self.b._worker=Mock()
    def tearDown(self):
        self.b._log_timer.stop(); self.b.curve._timer.stop(); self.b.deleteLater()
    def connect(self): self.b._on_line('@INFO,fw=6.0.6,hw=PY32F403_V2')
    def test_version_gate_read_and_atomic_command(self):
        self.b.pid.apply('0.150','1.000','0.001','20','10','1','32','500')
        self.b._worker.send.assert_not_called()
        self.b._on_line('@INFO,fw=6.0.5'); self.assertFalse(self.b.pid.supported)
        self.connect(); self.b._worker.send.assert_called_with('PID GET')
        self.b._on_line(PARAMS)
        self.b.pid.apply('0.200','0.500','0.000','50','8','2','16','300')
        self.b._worker.send.assert_called_with('PID SET 200 500 0 50 8 2 16 300')
        self.assertIn('尚未确认',self.b.pid.status)
        self.assertEqual(self.b.pid.parameters['period'],'20')
        self.b._on_line('@ACK,cmd=PID_SET,detail=RAM_APPLIED')
        self.assertIn('等待参数回读',self.b.pid.status)
        self.b._on_line('@PID,kp=200,ki=500,kd=0,period=50,deadband=8,nearstep=2,farstep=16,nearband=300,rev=2')
        self.assertIn('回读确认',self.b.pid.status); self.assertEqual(self.b.pid.parameters['period'],'50')
    def test_bad_values_and_rejection_keep_config(self):
        self.connect(); self.b._on_line(PARAMS)
        for text in ('NaN','Infinity','-0.001','0.0001','1e999999','abc'):
            with self.assertRaises(ValueError):encode_config([text,'1','0','20','10','1','32','500'])
        for period in ('19','2001','20.5'):
            with self.assertRaises(ValueError):encode_config(['0.1','1','0',period,'10','1','32','500'])
        self.b.pid.apply('0.2','0.5','0','50','8','2','16','300')
        self.b._on_line('@ERR,cmd=PID_SET,reason=PARAMETER_RANGE')
        self.assertIn('拒绝',self.b.pid.status);self.assertEqual(self.b.pid.parameters['kp'],'0.150')
    def test_csv_exact_revision_and_complete_raw_log(self):
        self.connect();self.b._on_line(PARAMS);self.b._on_line(TEL)
        self.assertEqual(len(self.b._telemetry_rows[0]),32)
        self.assertEqual(self.b._telemetry_rows[0][11],'3053')
        self.assertEqual(self.b._telemetry_rows[0][-8:],['0.150','1.000','0.001','20','10','1','32','500'])
        self.b._on_line(TEL.replace('pidrev=1','pidrev=2'))
        self.assertEqual(self.b._telemetry_rows[-1][-8:],['']*8)
        for i in range(1100):self.b._log(f'sample {i}')
        self.b.clearLog()
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'out.csv'
            with patch('xin_power_qt.QFileDialog.getSaveFileName',return_value=(str(path),'')):self.b.exportCsv()
            with path.open(encoding='utf-8-sig') as handle:
                records=list(csv.reader(handle))
            self.assertEqual(len(records[0]),len(records[1])); self.assertEqual(len(records),3)
            log=Path(folder)/'out.log'
            with patch('xin_power_qt.QFileDialog.getSaveFileName',return_value=(str(log),'')):self.b.exportLog()
            content=log.read_text(encoding='utf-8')
            self.assertIn(TEL,content);self.assertIn('sample 0',content);self.assertIn('sample 1099',content)
    def test_qml_pid_page_and_draft_survives_telemetry(self):
        self.connect();self.b._on_line(PARAMS)
        warnings=[];engine=QQmlApplicationEngine()
        engine.warnings.connect(lambda ws:warnings.extend(str(w) for w in ws))
        engine.rootContext().setContextProperty('bridge',self.b)
        engine.rootContext().setContextProperty('curve',self.b.curve)
        engine.load(QUrl.fromLocalFile(str(Path(__file__).resolve().parents[1]/'qml/Main.qml')))
        self.assertTrue(engine.rootObjects());root=engine.rootObjects()[0]
        root.setProperty('activePage',5); root.setProperty('width',1050)
        self.b._on_line(PARAMS)
        loop=QEventLoop();QTimer.singleShot(150,loop.quit);loop.exec()
        field=root.findChild(QObject,'pidKp');self.assertEqual(field.property('text'),'0.150')
        field.setProperty('text','0.250');self.b._on_line(TEL);APP.processEvents()
        self.assertEqual(field.property('text'),'0.250')
        apply=root.findChild(QObject,'pidApply');self.assertTrue(apply.property('enabled'))
        apply.clicked.emit();self.b._worker.send.assert_called_with('PID SET 250 1000 1 20 10 1 32 500')
        self.b._on_line(PARAMS);APP.processEvents();self.assertEqual(field.property('text'),'0.150')
        root.grabWindow().save(str(Path(__file__).with_name('pid_page_606.png')))
        self.assertEqual(warnings,[])
        root.close();engine.deleteLater()

if __name__=='__main__':unittest.main()
