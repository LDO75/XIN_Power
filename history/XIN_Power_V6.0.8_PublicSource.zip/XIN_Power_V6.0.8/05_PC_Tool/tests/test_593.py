"""Short checks for the changed Qt log controls; no device or serial port opened."""
from pathlib import Path
import sys
import unittest
from unittest.mock import Mock

from PySide6.QtCore import QEventLoop, QObject, QTimer, QUrl
from PySide6.QtQml import QQmlApplicationEngine
from PySide6.QtQuick import QQuickWindow
from PySide6.QtQuickControls2 import QQuickStyle
from PySide6.QtGui import QFont, QFontDatabase
from PySide6.QtWidgets import QApplication

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from xin_power_qt import Bridge

QQuickStyle.setStyle("Basic")
APP = QApplication.instance() or QApplication([])
# The offscreen platform does not enumerate Windows fonts by itself.
for filename in ("msyh.ttc", "segoeui.ttf", "consola.ttf"):
    QFontDatabase.addApplicationFont(f"C:/Windows/Fonts/{filename}")
APP.setFont(QFont("Microsoft YaHei"))

class LogTests(unittest.TestCase):
    def setUp(self):
        self.bridge = Bridge()

    def tearDown(self):
        self.bridge._log_timer.stop()
        self.bridge.deleteLater()

    def test_pause_keeps_receiving_and_clear_preserves_csv(self):
        b = self.bridge
        b._log("first")
        b.toggleLogPause()
        frozen = b.logText
        b._log("second")
        b._on_line("@TEL,t=1000,vout=16000,iout=10000,vin=27000,pout=160,temp=400,out=0,setv=5000,seti=100,fault=NONE")
        self.assertEqual(b.logText, frozen)
        self.assertEqual(b.pendingLogCount, 1)
        self.assertEqual(len(b._telemetry_rows), 1)
        self.assertEqual(b.voltage, "16.000")
        b.toggleLogPause()
        self.assertIn("second", b.logText)
        b.toggleLogPause()
        b.clearLog()
        self.assertEqual(b.logText, "")
        self.assertTrue(b.logPaused)
        self.assertEqual(len(b._telemetry_rows), 1)
        b._log("third")
        self.assertEqual(b.logText, "")
        b.toggleLogPause()
        self.assertIn("third", b.logText)

    def test_log_batching_and_limit(self):
        b = self.bridge
        updates = []
        b.logsChanged.connect(lambda: updates.append(1))
        for i in range(1200):
            b._log(f"line {i}")
        self.assertEqual(len(b._logs), 1000)
        self.assertEqual(updates, [])
        b._flush_log_view()
        self.assertEqual(len(updates), 1)
        b._flush_log_view()
        self.assertEqual(len(updates), 1)

    def test_calibration_diagnostic_does_not_change_voltage(self):
        b = self.bridge
        b._voltage = "0.016"
        b._on_line("@CAL,valid=1,vraw=11,vgain=999726,voff=5")
        self.assertIn("0.016 V", b.voltageDiagnostic)
        self.assertEqual(b.voltage, "0.016")

    def test_quick_commands_are_safe_and_gated(self):
        b = self.bridge
        b._worker = Mock()
        b.runQuickCommand("PING")
        b._worker.send.assert_not_called()
        b._connected = True
        for command in ("DIAG", "CAL GET", "FW STATUS"):
            b.runQuickCommand(command)
        b.setTelemetryInterval(200)
        self.assertEqual(b._worker.send.call_count, 4)
        b._worker.send.assert_called_with("LOG RATE 200")
        for command in ("CAL RESET", "FW APPLY", "OUT ON", "garbage"):
            b.runQuickCommand(command)
        b.setTelemetryInterval(42)
        b._updating = True
        b.runQuickCommand("PING")
        self.assertEqual(b._worker.send.call_count, 4)

    def test_qml_load_and_log_page(self):
        b = self.bridge
        warnings = []
        engine = QQmlApplicationEngine()
        engine.warnings.connect(lambda items: warnings.extend(str(item) for item in items))
        engine.rootContext().setContextProperty("bridge", b)
        engine.rootContext().setContextProperty("curve", b.curve)
        engine.load(QUrl.fromLocalFile(str(Path(__file__).resolve().parents[1] / "qml" / "Main.qml")))
        self.assertTrue(engine.rootObjects())
        root = engine.rootObjects()[0]
        root.setProperty("activePage", 4)
        for i in range(100):
            b._log(f"RX sample {i} " + "long log " * 20)
        b._flush_log_view()
        loop = QEventLoop()
        QTimer.singleShot(250, loop.quit)
        loop.exec()
        self.assertIsNotNone(root.findChild(QObject, "logArea"))
        # Resize to minimum width to catch narrow-window toolbar/layout problems.
        root.setProperty("width", 1050)
        APP.processEvents()
        scrollbar = root.findChild(QObject, "logVerticalBar")
        scrollview = root.findChild(QObject, "logScroll")
        self.assertGreaterEqual(scrollbar.property("width"), 14)
        self.assertGreater(scrollbar.property("x"), scrollview.property("width") - 25)
        self.assertGreater(scrollbar.property("height"), 100)
        self.assertEqual(warnings, [])
        image = root.grabWindow()
        self.assertFalse(image.isNull())
        image.save(str(Path(__file__).with_name("log_page_593.png")))
        root.close()
        engine.deleteLater()

if __name__ == "__main__":
    unittest.main()
