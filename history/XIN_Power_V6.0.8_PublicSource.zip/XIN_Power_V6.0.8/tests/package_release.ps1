$ErrorActionPreference = 'Stop'
$candidate = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$workspace = (Resolve-Path (Join-Path $candidate '../..')).Path
$destination = Join-Path $workspace 'outputs/V6.0.6_PID_Tuning'
$sourceStage = Join-Path $candidate 'delivery_source/XIN_Power_V6.0.6'
if (Test-Path -LiteralPath $destination) { throw 'Release already exists; inspect it instead of overwriting.' }
if (Test-Path -LiteralPath $sourceStage) { throw 'Staging already exists; inspect it instead of overwriting.' }
[void][IO.Directory]::CreateDirectory($destination)
[void][IO.Directory]::CreateDirectory($sourceStage)
foreach ($folder in @('02_Application', '05_PC_Tool', 'tests')) {
  $from = Join-Path $candidate $folder
  foreach ($file in Get-ChildItem -LiteralPath $from -Recurse -File) {
    $relative = [IO.Path]::GetRelativePath($from, $file.FullName)
    if ($relative -match '(^|[\\/])(Objects|Listings|__pycache__|build|dist)([\\/]|$)') { continue }
    if ($file.Extension -in @('.exe', '.pyc', '.log', '.bak', '.uvguix')) { continue }
    if ($file.Extension -eq '.png') { continue }
    $to = Join-Path $sourceStage (Join-Path $folder $relative)
    [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($to))
    Copy-Item -LiteralPath $file.FullName -Destination $to
  }
}
Copy-Item -LiteralPath (Join-Path $candidate 'README_下载与校准.md') -Destination $sourceStage
Copy-Item -LiteralPath (Join-Path $candidate '修改清单.md') -Destination $sourceStage
Copy-Item -LiteralPath (Join-Path $candidate 'PROJECT_HANDOFF.md') -Destination $sourceStage
$mdk = Join-Path $sourceStage '02_Application/MDK-ARM'
[xml]$project = Get-Content -LiteralPath (Join-Path $mdk 'XIN_Power.uvprojx') -Raw
foreach ($node in $project.SelectNodes('//FilePath')) {
  $sourcePath = Join-Path $mdk $node.InnerText
  if (!(Test-Path -LiteralPath $sourcePath -PathType Leaf)) { throw "Packaged project is missing $($node.InnerText)" }
}
Copy-Item -LiteralPath (Join-Path $candidate '02_Application/MDK-ARM/Objects/XIN_Power.hex') -Destination (Join-Path $destination 'XIN_Power_V6.0.6_APP_USB_BT.hex')
Copy-Item -LiteralPath (Join-Path $candidate '05_PC_Tool/dist/XIN_Power_Studio_V6.0.6.exe') -Destination $destination
Copy-Item -LiteralPath (Join-Path $candidate 'README_下载与校准.md') -Destination $destination
Copy-Item -LiteralPath (Join-Path $candidate '修改清单.md') -Destination $destination
Compress-Archive -LiteralPath $sourceStage -DestinationPath (Join-Path $destination 'XIN_Power_V6.0.6_Source.zip') -CompressionLevel Optimal
Get-ChildItem -LiteralPath $destination -File | Select-Object Name,Length
Get-ChildItem -LiteralPath $destination -File | Get-FileHash -Algorithm SHA256 | Select-Object Path,Hash
