/* Short host checks using the REAL calibration and output-control sources.
 * Fake measurements do not verify physical overshoot or load regulation. */
#include "power_control.h"
#include "calibration.h"
#include "w25q256.h"
#include "i2c.h"
#include "usart.h"
#include "ina226.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define CHECK(c) do { if (!(c)) { fprintf(stderr,"FAIL %u: %s\n",(unsigned)__LINE__,#c); exit(1); } } while(0)
#define BASE 0x01FFE000UL
I2C_HandleTypeDef hi2c1, hi2c2;
UART_HandleTypeDef husart1, husart2;
static uint8_t flash[8192];
static uint32_t tick;
static uint16_t dac;
static GPIO_PinState ce;
static unsigned writes;
static bool fail_dac, fail_commit;
static char last_power[400];
bool W25Q256_Init(void) { return true; }
bool W25Q256_IsReady(void) { return true; }
bool W25Q256_Read(uint32_t a, void *p, uint32_t n)
{ CHECK(a>=BASE && a+n<=BASE+sizeof(flash)); memcpy(p,flash+a-BASE,n); return true; }
bool W25Q256_EraseSector(uint32_t a)
{ CHECK(a>=BASE && a<BASE+sizeof(flash)); memset(flash+((a-BASE)&~4095UL),255,4096); return true; }
bool W25Q256_Write(uint32_t a, const void *p, uint32_t n)
{
  CHECK(a>=BASE && a+n<=BASE+sizeof(flash));
  if (fail_commit && ((a-BASE)%4096==0)) { return false; }
  const uint8_t *q=p; for(uint32_t i=0;i<n;i++) { flash[a-BASE+i]&=q[i]; } return true;
}
uint32_t HAL_GetTick(void) { return tick; }
void HAL_GPIO_WritePin(GPIO_TypeDef *p, uint16_t pin, GPIO_PinState value)
{ (void)p; (void)pin; ce=value; }
HAL_StatusTypeDef HAL_I2C_IsDeviceReady(I2C_HandleTypeDef *i,uint16_t a,uint32_t n,uint32_t t)
{ (void)i; (void)a; (void)n; (void)t; return HAL_OK; }
HAL_StatusTypeDef HAL_I2C_Master_Transmit(I2C_HandleTypeDef *i,uint16_t a,uint8_t *b,uint16_t n,uint32_t t)
{ (void)i; (void)a; (void)t; CHECK(n==3); if(fail_dac) return HAL_ERROR;
  dac=((uint16_t)b[1]<<4)|(b[2]>>4); writes++; return HAL_OK; }
void DebugConsole_Write(const char *p) {
  if(strstr(p,"[FAULT]")) CHECK(ce==GPIO_PIN_SET);
  if(strstr(p,"[POWER]")) snprintf(last_power,sizeof(last_power),"%s",p);
}

static uint16_t mock_sensor_mv = 3400;
static bool fail_sensor;
static unsigned sensor_reads;
void INA226_ResetDevice(INA226_Device_t *d) { memset(d,0,sizeof(*d)); }
bool INA226_Init(INA226_Device_t *d,I2C_HandleTypeDef *bus,uint8_t address,
 uint16_t calibration,uint16_t current_lsb,uint16_t power_lsb)
{ d->i2c=bus; d->address_7bit=address; d->ready=true; (void)calibration; (void)current_lsb; (void)power_lsb; return true; }
bool INA226_ReadMeasurement(INA226_Device_t *d,INA226_Measurement_t *m)
{ sensor_reads++; if(fail_sensor) return false; memset(m,0,sizeof(*m));
  m->bus_voltage_mv=d->address_7bit==INA226_OUTPUT_ADDRESS_7BIT?mock_sensor_mv:27900; return true; }
const char *INA226_GetErrorName(INA226_Error_t e) { (void)e; return "NONE"; }
static Calibration_Data_t Data(void) { Calibration_Data_t d; Calibration_Get(&d); return d; }
static PowerControl_Status_t Status(void) { PowerControl_Status_t s; PowerControl_GetStatus(&s); return s; }
static void Curves(void)
{
  memset(flash,255,sizeof(flash)); Calibration_Init(); CHECK(!Data().loaded_from_flash);
  CHECK(Calibration_SetVoltage(999800,3)); CHECK(Calibration_SetCurrent(1002915,407));
  CHECK(Calibration_SetDac(4637,2937,19251,1377)); CHECK(Calibration_Save());
  /* Read the unchanged legacy record with an erased extension. */
  memset(flash+256,255,256); Calibration_Init(); CHECK(Data().dac_valid && Data().point_mask==0);
  CHECK(Data().voltage_gain_ppm==999800 && Data().current_offset_ua==407);
  CHECK(Calibration_SavePoint(0,2995,3065)); CHECK(Calibration_SavePoint(1,3295,3034));
  Calibration_Init(); CHECK(Data().point_mask==3);
  uint16_t code; CHECK(Calibration_MapDac(2995,&code) && code==3065);
  CHECK(Calibration_MapDac(3295,&code) && code==3034);
  CHECK(Calibration_MapDac(3145,&code) && code==3050); /* ceil: lower voltage side */
  CHECK(Calibration_SavePoint(1,3295,3066)); CHECK(Data().points[1].dac_code==3066);
  CHECK(Calibration_SavePoint(1,3295,3034));
  CHECK(!Calibration_SavePoint(1,2995,3034)); /* duplicate voltage is not an interval */
  CHECK(Calibration_SavePoint(12,3500,3000)); CHECK(Calibration_SavePoint(2,5100,2800));
  CHECK(Calibration_SavePoint(2,4995,2898));
  /* Reset the two added records for the commit/CRC test below. */
  memset(flash,255,sizeof(flash)); Calibration_Init();
  CHECK(Calibration_SetVoltage(999800,3)); CHECK(Calibration_SetCurrent(1002915,407));
  CHECK(Calibration_SetDac(4637,2937,19251,1377)); CHECK(Calibration_Save());
  CHECK(Calibration_SavePoint(0,2995,3065)); CHECK(Calibration_SavePoint(1,3295,3034));
  fail_commit=true; CHECK(!Calibration_SavePoint(2,4995,2898)); fail_commit=false;
  CHECK(Data().point_mask==3); Calibration_Init(); CHECK(Data().point_mask==3);
  CHECK(Calibration_SavePoint(2,4995,2898)); CHECK(Data().point_mask==7);
  /* seq4/current slot1: corrupt its curve CRC and fall back to seq3/slot0. */
  flash[4096+256+20]^=1; Calibration_Init(); CHECK(Data().point_mask==3);
  const uint16_t codes[]={3065,3034,2898,2660,2532,2468,2148,1508,1294,868,441,14,3002,2980,2970,2930};
  for(unsigned i=0;i<16;i++) CHECK(Calibration_SavePoint(i,Calibration_PointTarget(i)-5,codes[i]));
  Calibration_Init(); CHECK(Data().point_mask==65535 && Data().loaded_from_flash);
  for(unsigned i=0;i<16;i++) CHECK(Calibration_MapDac(Calibration_PointTarget(i)-5,&code)&&code==codes[i]);
  uint16_t previous=4095;
  for(unsigned mv=3000;mv<=32000;mv++)
  { CHECK(Calibration_MapDac(mv,&code)); CHECK(code<=previous); previous=code; }
  /* Positive measurement quantum must not cause a preset-boundary jump. */
  CHECK(Calibration_SavePoint(1,3310,3034)); previous=4095;
  for(unsigned mv=3000;mv<=5000;mv++)
  { CHECK(Calibration_MapDac(mv,&code)); CHECK(code<=previous); previous=code; }
  CHECK(Calibration_SavePoint(1,3295,3034));
  CHECK(Data().voltage_gain_ppm==999800 && Data().current_offset_ua==407);
  puts("PASS: 16 points, full-span monotonic interpolation, failed commit, CRC fallback");
}
static void Init(PowerControl_Request_t *r,PowerMonitor_Snapshot_t *m,uint16_t target,uint32_t now)
{
  memset(r,0,sizeof(*r)); memset(m,0,sizeof(*m)); tick=now; ce=GPIO_PIN_SET; dac=0; writes=0; fail_dac=false;
  r->voltage_setpoint_mv=target; r->current_limit_ma=1500; r->temperature_valid=true; r->temperature_decic=300;
  m->input_online=m->output_online=m->data_valid=true; m->input_voltage_raw_mv=27882;
  m->sample_sequence=1; m->last_valid_sample_time_ms=tick;
  CHECK(PowerControl_Init()); PowerControl_Process(tick,r,m);
}
static void Fresh(PowerControl_Request_t *r,PowerMonitor_Snapshot_t *m,uint32_t now,uint16_t actual)
{ tick=now; m->last_valid_sample_time_ms=tick; m->sample_sequence++;
  m->output_voltage_raw_mv=m->output_voltage_uncalibrated_mv=actual; PowerControl_Process(tick,r,m); }
static void Run(PowerControl_Request_t *r,PowerMonitor_Snapshot_t *m,uint16_t actual,unsigned length)
{ uint32_t origin=tick; for(unsigned dt=20;dt<=length;dt+=20) Fresh(r,m,origin+dt,actual); }
static uint32_t Crc(const uint8_t *bytes,unsigned n)
{
  uint32_t crc=UINT32_MAX;
  for(unsigned i=0;i<n;i++) { crc^=bytes[i]; for(unsigned j=0;j<8;j++) crc=(crc>>1)^((crc&1)?0xEDB88320UL:0); }
  return ~crc;
}
static void Migration(void)
{
  for(unsigned slot=0;slot<2;slot++) {
    uint8_t *p=flash+slot*4096+256;
    p[4]=1; p[5]=0; p[6]=68; p[7]=0; p[12]=255; p[13]=15;
    memset(p+64,0,4); uint32_t crc=Crc(p,68); memcpy(p+64,&crc,4);
  }
  Calibration_Init(); CHECK(Data().point_mask==4095);
  CHECK(Data().points[1].dac_code==3034 && Data().current_offset_ua==407);
  CHECK(Calibration_SavePoint(14,3995,2970));
  Calibration_Init(); CHECK(Data().point_mask==(4095|1U<<14));
  CHECK(Data().points[1].dac_code==3034);
  puts("PASS: schema-1 12-point migration, new point persistence, unchanged measurement coefficients");
}



static void ContinuousPid(void)
{
  PowerControl_Request_t r; PowerMonitor_Snapshot_t m;
  Init(&r,&m,3600,0); r.output_requested=true; Fresh(&r,&m,2,3000);
  uint16_t seed=dac; double actual=3000;
  const uint16_t targets[]={3600,5000,3300,3600,12000,32000,3000};
  for(unsigned j=0;j<sizeof(targets)/sizeof(targets[0]);j++) {
    r.voltage_setpoint_mv=targets[j];
    for(unsigned k=0;k<2250;k++) {
      actual+=0.25*(3000.0+((int)seed-(int)dac)*9.612-actual);
      uint16_t previous=dac;
      Fresh(&r,&m,tick+20,(uint16_t)lround(actual));
      unsigned step=(unsigned)abs((int)dac-previous);
      CHECK(step<=32 && (abs((int)targets[j]-(int)lround(actual))>500 || step<=1));
      CHECK(ce==GPIO_PIN_RESET && Status().fault==POWER_CONTROL_FAULT_NONE);
    }
    CHECK(fabs(actual-targets[j])<20);
    printf("PASS: target %umV simulated %.1fmV, bounded DAC\n",targets[j],actual);
  }
  /* Each observed branch is modeled separately; no invented switching rule. */
  for(unsigned branch=0;branch<2;branch++) {
    Init(&r,&m,3300,0); r.output_requested=true; Fresh(&r,&m,2,3000);
    seed=dac; actual=3000;
    r.voltage_setpoint_mv=3600;
    for(unsigned k=0;k<1200;k++) {
      actual+=0.20*(3000.0+((int)seed-(int)dac)*9.612+branch*500.0-actual);
      Fresh(&r,&m,tick+20,(uint16_t)lround(actual));
    }
    CHECK(fabs(actual-3600)<20);
  }
  /* Replay amplitudes from actual CSV as exogenous feedback, not a plant model. */
  const uint16_t observed[]={3344,4024,3195,4082,3506,3263,3927,3546};
  for(unsigned k=0;k<80;k++) {
    uint16_t previous=dac; Fresh(&r,&m,tick+20,observed[k%8]);
    CHECK(abs((int)dac-previous)<=1 && abs(Status().pid_delta)<=1);
  }
  unsigned before=writes; uint32_t updates=Status().pid_updates;
  tick+=20; PowerControl_Process(tick,&r,&m);
  CHECK(writes==before && Status().pid_updates==updates);
  m.data_valid=false; tick+=180000; PowerControl_Process(tick,&r,&m); PowerControl_Process(tick+1,&r,NULL);
  CHECK(ce==GPIO_PIN_RESET && writes==before && Status().fault==POWER_CONTROL_FAULT_NONE);
  PowerControl_ResetVoltageLearning(); m.data_valid=true; PowerControl_Process(tick,&r,&m); CHECK(writes==before);
  fail_dac=true; uint16_t previous=dac; Fresh(&r,&m,tick+20,1000);
  CHECK(dac==previous && Status().dac_code==previous && ce==GPIO_PIN_RESET);
  fail_dac=false; Fresh(&r,&m,tick+20,1000); CHECK(dac<previous);
  r.temperature_valid=false; r.temperature_decic=1200; m.input_voltage_raw_mv=60000; m.output_power_raw_mw=200000;
  Fresh(&r,&m,tick+20,3600); CHECK(Status().fault==POWER_CONTROL_FAULT_NONE && !Status().constant_current);
  r.output_requested=false; PowerControl_Process(tick,&r,&m); CHECK(ce==GPIO_PIN_SET && dac==0);
  r.output_requested=true; Fresh(&r,&m,tick+20,0); CHECK(dac==seed && ce==GPIO_PIN_RESET);
  Init(&r,&m,3600,UINT32_MAX-30); r.output_requested=true; Fresh(&r,&m,UINT32_MAX-28,3000);
  previous=dac; Fresh(&r,&m,UINT32_MAX-8,3000); Fresh(&r,&m,12,3000);
  CHECK(dac<previous && ce==GPIO_PIN_RESET);
  for(unsigned k=0;k<600;k++) Fresh(&r,&m,tick+20,0);
  CHECK(dac==0); Fresh(&r,&m,tick+20,60000); CHECK(dac>0);
  for(unsigned k=0;k<600;k++) Fresh(&r,&m,tick+20,60000);
  CHECK(dac==4095); Fresh(&r,&m,tick+20,0); CHECK(dac<4095);
  puts("PASS: trace-amplitude step bound, fresh frame, data hold, failed write, reset, rails and wrap");
}

static void SharedSamplingAndTuning(void)
{
  PowerControl_Request_t r; PowerMonitor_Snapshot_t m;
  Calibration_ResetDefaults(); Init(&r,&m,3600,0);
  PowerControl_PidConfig_t config; uint32_t rev;
  PowerControl_GetPidConfig(&config,&rev); CHECK(config.period_ms==20 && rev==1);
  PowerControl_PidConfig_t bad=config; bad.period_ms=19;
  CHECK(!PowerControl_SetPidConfig(&bad)); PowerControl_GetPidConfig(&bad,&rev); CHECK(rev==1 && bad.period_ms==20);
  bad=config; bad.far_step_codes=0; CHECK(!PowerControl_SetPidConfig(&bad));
  r.output_requested=true; Fresh(&r,&m,2,3500); uint16_t before=dac;
  config.kp_milli=500; config.ki_milli=500; config.kd_milli=0; config.period_ms=100;
  CHECK(PowerControl_SetPidConfig(&config)); CHECK(dac==before && ce==GPIO_PIN_RESET);
  CHECK(PowerMonitor_GetSamplePeriod()==100 && Status().pid_revision==2);
  /* Production power_monitor and power_control, with sensor/I2C hardware faked. */
  const uint32_t periods[]={20,50,100};
  for(unsigned j=0;j<3;j++) {
    config.period_ms=periods[j]; CHECK(PowerControl_SetPidConfig(&config));
    CHECK(PowerMonitor_Init()); mock_sensor_mv=3400; fail_sensor=false;
    uint32_t first=tick; uint32_t update_start=Status().pid_updates;
    PowerMonitor_GetSnapshot(&m); uint32_t sequence_start=m.sample_sequence;
    for(unsigned dt=1;dt<=periods[j]*10;dt++) {
      tick=first+dt; PowerMonitor_Process(tick); PowerMonitor_GetSnapshot(&m);
      PowerControl_Process(tick,&r,&m);
    }
    CHECK(m.sample_sequence-sequence_start==10);
    CHECK(Status().pid_updates-update_start==10);
    printf("PASS: shared %ums INA226/PID period, 10 new frames = 10 PID updates\n",periods[j]);
    uint32_t prior=Status().pid_updates; before=dac; fail_sensor=true;
    for(unsigned k=0;k<3;k++) { tick+=periods[j]; PowerMonitor_Process(tick); PowerMonitor_GetSnapshot(&m); PowerControl_Process(tick,&r,&m); }
    CHECK(Status().pid_updates==prior && dac==before && ce==GPIO_PIN_RESET); fail_sensor=false;
  }
  PowerControl_DefaultPidConfig(); CHECK(dac==before && ce==GPIO_PIN_RESET && PowerMonitor_GetSamplePeriod()==20);
  puts("PASS: atomic config, period sync, live changes retain DAC, missing samples hold without fault");
}
static void Manual(void)
{
  PowerControl_Request_t r; PowerMonitor_Snapshot_t m; Init(&r,&m,3600,0);
  r.output_requested=true; Fresh(&r,&m,2,3002);
  CHECK(PowerControl_BeginDacCalibration(3600)); Fresh(&r,&m,3,3002);
  CHECK(PowerControl_DacCalibrationReady(&m)); uint16_t selected=dac;
  CHECK(!PowerControl_StepDacCalibration(-20,&m));
  CHECK(PowerControl_StepDacCalibration(-5,&m) && dac==selected-5);
  CHECK(PowerControl_DacCalibrationReady(&m));
  CHECK(PowerControl_StepDacCalibration(-1,&m) && dac==selected-6);
  CHECK(PowerControl_StepDacCalibration(5,&m)); CHECK(PowerControl_StepDacCalibration(1,&m));
  CHECK(dac==selected);
  /* Reproduce 6.0.2's 3002 -> 2975 mV fall at unchanged DAC without a false trip. */
  unsigned origin=tick; unsigned before=writes;
  for(unsigned dt=20;dt<=12000;dt+=20) {
    Fresh(&r,&m,origin+dt,3002-dt*27/12000);
    CHECK(PowerControl_DacCalibrationReady(&m) && Status().fault==POWER_CONTROL_FAULT_NONE);
  }
  CHECK(writes==before);
  m.data_valid=false; tick+=180000; PowerControl_Process(tick,&r,&m);
  CHECK(PowerControl_DacCalibrationReady(NULL));
  CHECK(PowerControl_StepDacCalibration(-5,NULL));
  uint16_t held=dac; fail_dac=true;
  CHECK(!PowerControl_StepDacCalibration(1,NULL));
  CHECK(dac==held && ce==GPIO_PIN_RESET && Status().fault==POWER_CONTROL_FAULT_NONE);
  fail_dac=false; CHECK(PowerControl_StepDacCalibration(1,NULL));
  CHECK(PowerControl_DacCalibrationReady(NULL));
  PowerControl_EndDacCalibration(); CHECK(ce==GPIO_PIN_SET && dac==0);
  CHECK(!PowerControl_IsDacCalibrationActive());
  puts("PASS: start while ON, immediate +/-1/5, drift/age no gate, manual STOP, applied DAC retained on failed step");
}
static void Overcurrent(void)
{
  PowerControl_Request_t r; PowerMonitor_Snapshot_t m;
  Init(&r,&m,5000,0); r.output_requested=true;
  m.output_current_raw_ua=m.output_current_uncalibrated_ua=1500000;
  Fresh(&r,&m,2,5000); CHECK(ce==GPIO_PIN_RESET);
  m.output_current_raw_ua=m.output_current_uncalibrated_ua=1500001;
  Fresh(&r,&m,3,5000); CHECK(ce==GPIO_PIN_SET && dac==0);
  CHECK(Status().fault==POWER_CONTROL_FAULT_OUTPUT_OVERCURRENT && !Status().constant_current);
  CHECK(strstr(PowerControl_GetFaultContext(),"reason=IOUT_OC")!=NULL);
  m.output_current_raw_ua=m.output_current_uncalibrated_ua=0;
  Fresh(&r,&m,4,0); CHECK(ce==GPIO_PIN_SET); /* latched */
  CHECK(PowerControl_ClearFault()); CHECK(ce==GPIO_PIN_SET);
  r.output_requested=false; Fresh(&r,&m,5,0); CHECK(Status().fault==POWER_CONTROL_FAULT_NONE);
  Init(&r,&m,5000,0); r.output_requested=true; m.input_current_raw_ua=4800001;
  Fresh(&r,&m,2,5000); CHECK(Status().fault==POWER_CONTROL_FAULT_INPUT_OVERCURRENT && ce==GPIO_PIN_SET);
  Init(&r,&m,5000,0); r.output_requested=true; r.current_limit_ma=8000;
  m.output_current_raw_ua=0; m.output_current_uncalibrated_ua=8000001;
  Fresh(&r,&m,2,5000); CHECK(Status().fault==POWER_CONTROL_FAULT_OUTPUT_OVERCURRENT);
  Init(&r,&m,3600,UINT32_MAX-100); r.output_requested=true;
  CHECK(PowerControl_BeginDacCalibration(3600)); Fresh(&r,&m,UINT32_MAX-98,3002);
  CHECK(PowerControl_StepDacCalibration(-5,&m)); Run(&r,&m,2975,12000);
  CHECK(ce==GPIO_PIN_RESET && PowerControl_DacCalibrationReady(&m));
  m.output_current_uncalibrated_ua=1500001; Fresh(&r,&m,tick+1,2975);
  CHECK(ce==GPIO_PIN_SET && !PowerControl_IsDacCalibrationActive());
  puts("PASS: only IIN/IOUT overcurrent, setting boundary, raw/corrected current, fault latch, calibration OCP and tick wrap");
}
static void DacBounds(void)
{
  Calibration_ResetDefaults(); CHECK(Calibration_SetDac(3000,4095,32000,0));
  CHECK(Calibration_SavePoint(0,3000,4095)); CHECK(Calibration_SavePoint(11,32000,0));
  uint16_t code; CHECK(Calibration_MapDac(32000,&code) && code==0);
  PowerControl_Request_t r; PowerMonitor_Snapshot_t m; Init(&r,&m,32000,0);
  CHECK(PowerControl_BeginDacCalibration(32000)); r.output_requested=true;
  Fresh(&r,&m,2,32000); CHECK(dac==0 && ce==GPIO_PIN_RESET);
  CHECK(PowerControl_DacCalibrationReady(&m)); CHECK(!PowerControl_StepDacCalibration(-1,&m));
  CHECK(PowerControl_StepDacCalibration(5,&m) && dac==5); PowerControl_EndDacCalibration();
  Init(&r,&m,3000,0); CHECK(PowerControl_BeginDacCalibration(3000));
  r.output_requested=true; Fresh(&r,&m,2,3000); CHECK(dac==4095);
  CHECK(!PowerControl_StepDacCalibration(1,&m)); CHECK(PowerControl_StepDacCalibration(-5,&m));
  PowerControl_EndDacCalibration(); CHECK(ce==GPIO_PIN_SET && dac==0);
  puts("PASS: full 12-bit DAC including 0/4095; only numeric bounds reject a step");
}

static void User3600Capture(void)
{
  /* Exact 15 stored pairs and new capture from the 19:14-19:16 user log. */
  const uint16_t mv[16]={2998,3298,5003,7209,8405,8999,11999,17998,
    20002,23997,27998,31996,0,3904,3993,4505};
  const uint16_t codes[16]={3068,3038,2905,2668,2541,2478,2157,1516,
    1300,873,441,13,0,3021,3011,2955};
  memset(flash,255,sizeof(flash)); Calibration_Init();
  CHECK(Calibration_SetVoltage(999800,3)); CHECK(Calibration_SetCurrent(1002915,407));
  for(unsigned i=0;i<16;i++) if(i!=12) CHECK(Calibration_SavePoint(i,mv[i],codes[i]));
  Calibration_Data_t before=Data(); CHECK(before.point_mask==61439);
  CHECK(Calibration_SavePoint(12,3597,3052));
  Calibration_Init(); Calibration_Data_t after=Data();
  CHECK(after.point_mask==65535 && after.points[12].actual_mv==3597 && after.points[12].dac_code==3052);
  for(unsigned i=0;i<16;i++) if(i!=12) CHECK(memcmp(&after.points[i],&before.points[i],sizeof(after.points[i]))==0);
  CHECK(after.voltage_gain_ppm==999800 && after.current_offset_ua==407);
  uint16_t code;
  CHECK(Calibration_MapDac(3298,&code) && code==3038);
  CHECK(Calibration_MapDac(3447,&code) && code==3045); /* positive DAC slope */
  CHECK(Calibration_MapDac(3597,&code) && code==3052);
  CHECK(Calibration_MapDac(3750,&code) && code==3037); /* negative DAC slope */
  CHECK(Calibration_MapDac(3904,&code) && code==3021);
  CHECK(Calibration_SavePoint(12,3597,3038)); /* a flat DAC segment is representable */
  CHECK(Calibration_MapDac(3447,&code) && code==3038);
  CHECK(Calibration_SavePoint(12,3597,3052));
  puts("PASS: user 3597mV/DAC3052 saves and reloads, all other points unchanged; positive/negative/flat interval slopes");
}

int main(void) { Curves(); Migration(); ContinuousPid(); SharedSamplingAndTuning(); Manual(); Overcurrent(); DacBounds(); User3600Capture(); puts("V6.0.6 PID tuning host checks passed (not hardware tests)."); return 0; }
