/* Real PID command parser / telemetry formatter with UART and controller fakes. */
#define main UnusedUartChecksMain
#define DEBUG_CONSOLE_COMMAND_HOST_TEST
#include "test_uart_recovery.c"
#undef main
static PowerControl_PidConfig_t mock_pid={150,1000,1,20,10,1,32,500};
static uint32_t mock_revision=1, mock_commits;
void PowerControl_GetPidConfig(PowerControl_PidConfig_t *p,uint32_t *r)
{ *p=mock_pid; *r=mock_revision; }
bool PowerControl_SetPidConfig(const PowerControl_PidConfig_t *p)
{ if(p->period_ms<20) return false; mock_pid=*p; mock_revision++; mock_commits++; return true; }
void PowerControl_DefaultPidConfig(void)
{ mock_pid=(PowerControl_PidConfig_t){150,1000,1,20,10,1,32,500};mock_revision++;mock_commits++; }
const char *PowerControl_GetFaultName(PowerControl_Fault_t f) { (void)f; return "NONE"; }
const char *PowerControl_GetFaultContext(void) { return ""; }
static DebugConsole_Channel_t channel;
static char reply[1024];
static const char *Command(const char *command)
{
  memset(&channel,0,sizeof(channel));channel.uart=&husart1;channel.tx_active=true;
  DebugConsole_HandlePid(&channel,command);
  memcpy(reply,channel.tx_buffer,channel.tx_head);reply[channel.tx_head]=0;
  assert(channel.tx_overflow_count==0);return reply;
}
int main(void)
{
  assert(strstr(Command("PID GET"),"@PID,kp=150,ki=1000,kd=1,period=20")!=NULL);
  assert(strstr(Command("PID SET 200 500 0 50 8 2 16 300"),"@ACK,cmd=PID_SET")!=NULL);
  assert(mock_commits==1 && mock_pid.period_ms==50 && strstr(reply,"rev=2")!=NULL);
  const char *bad[]={"PID SET 1 2 3","PID SET -1 2 3 20 10 1 32 500",
    "PID SET 1.5 2 3 20 10 1 32 500","PID SET 1 2 3 20 10 1 32 500 9",
    "PID SET 4294967296 2 3 20 10 1 32 500","PID SET 999999999999999999 2 3 20 10 1 32 500",
    "PID SET 1 2 3 19 10 1 32 500"};
  for(unsigned i=0;i<sizeof(bad)/sizeof(bad[0]);i++) {
    assert(strstr(Command(bad[i]),"@ERR,cmd=PID_SET")!=NULL);
    assert(mock_commits==1 && mock_pid.period_ms==50);
  }
  assert(strstr(Command("PID RESET"),"@ACK,cmd=PID_RESET")!=NULL);
  assert(mock_pid.period_ms==20 && mock_commits==2);
  PowerMonitor_Snapshot_t m;memset(&m,255,sizeof(m));
  PowerControl_Status_t status;memset(&status,0,sizeof(status));
  TemperatureSensor_Snapshot_t temp;memset(&temp,0,sizeof(temp));
  memset(&channel,0,sizeof(channel));channel.uart=&husart1;channel.tx_active=true;
  channel.rx_overflow_count=channel.tx_overflow_count=UINT32_MAX;
  DebugConsole_SendStatus(&channel,UINT32_MAX,&m,&status,&temp,false);
  memcpy(reply,channel.tx_buffer,channel.tx_head);reply[channel.tx_head]=0;
  assert(strstr(reply,"pid=0,err=0,delta=0,updates=0,vfb=0,pidrev=0,pdt=0,seq=4294967295,samplet=4294967295")!=NULL);
  assert(strstr(reply,"txdrop=4294967295\r\n")!=NULL);
  printf("PID parser overflow/syntax/atomic response and full telemetry (%u bytes): PASS\n",channel.tx_head);
  return 0;
}
