$ErrorActionPreference = 'Stop'
$appRoot = (Resolve-Path (Join-Path $PSScriptRoot '../02_Application')).Path
$testExe = Join-Path $PSScriptRoot 'test_608.exe'
$sources = @((Join-Path $PSScriptRoot 'test_608.c'), "$appRoot/Core/SRC/calibration.c", "$appRoot/Core/SRC/power_control.c", "$appRoot/Core/SRC/mcp4725.c")
& gcc -std=c11 -Wno-int-to-pointer-cast -Wno-pointer-to-int-cast -DPY32F403xD -DUSE_HAL_DRIVER "-I$appRoot/Core/INC" "-I$appRoot/Drivers/PY32F403_HAL_Driver/Inc" "-I$appRoot/Drivers/CMSIS/Include" "-I$appRoot/Drivers/CMSIS/Device/PY32F403/Include" @sources -lm -o $testExe
if ($LASTEXITCODE -ne 0) { throw 'Host compilation failed' }
& $testExe
if ($LASTEXITCODE -ne 0) { throw 'Host test failed' }
foreach ($check in @('test_uart_recovery', 'test_settings_background')) {
  $testExe = Join-Path $PSScriptRoot "$check.exe"
  $sources = @((Join-Path $PSScriptRoot "$check.c"))
  if ($check -eq 'test_settings_background') { $sources += "$appRoot/Core/SRC/user_settings.c" }
  & gcc -std=c11 -ffunction-sections -fdata-sections -Wno-int-to-pointer-cast -Wno-pointer-to-int-cast -DPY32F403xD -DUSE_HAL_DRIVER "-I$appRoot/Core/INC" "-I$appRoot/Drivers/PY32F403_HAL_Driver/Inc" "-I$appRoot/Drivers/CMSIS/Include" "-I$appRoot/Drivers/CMSIS/Device/PY32F403/Include" @sources '-Wl,--gc-sections' -o $testExe
  if ($LASTEXITCODE -ne 0) { throw "$check compilation failed" }
  & $testExe
  if ($LASTEXITCODE -ne 0) { throw "$check failed" }
}
