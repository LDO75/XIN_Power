/**
  ******************************************************************************
  * @file    power_config.h
  * @brief   数控电源量程、保护阈值和FB调压参数集中配置。
  ******************************************************************************
  */

#ifndef __POWER_CONFIG_H__
#define __POWER_CONFIG_H__

/* 用户可调范围。 */
#define POWER_CFG_VOLTAGE_MIN_MV              3000U
#define POWER_CFG_VOLTAGE_MAX_MV             32000U
#define POWER_CFG_CURRENT_MIN_MA                100U
#define POWER_CFG_CURRENT_MAX_MA               8000U

/* Only software overcurrent shutdown remains. */
#define POWER_CFG_INPUT_TRIP_MA                 4800U
#define POWER_CFG_OUTPUT_TRIP_MA                8500U

/* 功率区NTC与风扇。 */
#define POWER_CFG_FAN_START_DEFAULT_C                40U
#define POWER_CFG_FAN_STOP_C                         35U
#define POWER_CFG_OUTPUT_BLEEDER_OHM               1800U
#define POWER_CFG_FAN_START_MIN_C                    30U
#define POWER_CFG_FAN_START_MAX_C                    65U
#define POWER_CFG_FAN_START_STEP_C                    1U

/* SC8701 FB网络和MCP4725参考电压。 */
#define POWER_CFG_FB_REFERENCE_UV            1220000UL
#define POWER_CFG_DAC_REFERENCE_UV           3000000UL
#define POWER_CFG_FB_UPPER_OHM                100000UL
#define POWER_CFG_FB_LOWER_OHM                  7620UL

/* R274=100k, R314+R315=7.62k, R316+R317=4.99k+120=5.11k. */
#define POWER_CFG_FB_INJECTION_OHM              5110UL
#define POWER_CFG_DAC_SCALE_CODES               4096UL
#define POWER_CFG_SAMPLE_PERIOD_MS               20U
#define POWER_CFG_DAC_HARDWARE_TAG               5110U

#endif /* __POWER_CONFIG_H__ */
