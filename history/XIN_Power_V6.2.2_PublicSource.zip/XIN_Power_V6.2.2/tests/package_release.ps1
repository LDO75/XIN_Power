param([string]$Python = 'python', [string]$Destination = '')
$ErrorActionPreference = 'Stop'
$candidate = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
if (!$Destination) {
  $workspace = (Resolve-Path (Join-Path $candidate '../..')).Path
  $Destination = Join-Path $workspace 'outputs/V6.2.2_ScreenSleep_25Hz_USBRecovery'
}
& $Python -X utf8 (Join-Path $PSScriptRoot 'package_622.py') $Destination
if ($LASTEXITCODE -ne 0) { throw 'Release checks or packaging failed' }
